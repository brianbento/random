import argparse
import base64
import json
import os
from concurrent.futures import ThreadPoolExecutor
from typing import Any, Dict, List

import requests
import toml
import yaml

API_URL = "https://capability-advisor-e2e.api.intuit.com/v1/agent/env/qal/ingestAll"
AUTH_HEADER = "Intuit_IAM_Authentication intuit_appid=Intuit.intlgntsys.cui.genstudiotestclient,intuit_app_secret=preprdw92z72L2EJgrTE6Sirvy1kZS9B9ztLKRmx"
BATCH_SIZE = 25


def process_repositories(repo_dir: str, log_level: str = "main") -> None:
    """
    Process all repositories in the given directory.

    Args:
        repo_dir (str): Directory containing the cloned repositories
        log_level (str): The log level for logging messages
    """
    print(f"[{log_level}] Processing repositories in {repo_dir}")

    # Get all repositories (directories) in the repo_dir
    repos = [
        os.path.join(repo_dir, d)
        for d in os.listdir(repo_dir)
        if os.path.isdir(os.path.join(repo_dir, d))
    ]

    print(f"[{log_level}] Found {len(repos)} repositories to process")

    # Process each repository to extract prompt-response pairs
    all_data = []
    global_id_counter = 1

    for repo_path in repos:
        repo_name = os.path.basename(repo_path)
        print(f"[{log_level}] Processing repository: {repo_name}")

        # Get capability info from .ai_config.toml
        capability_info = get_capability_info(repo_path, log_level)
        if not capability_info:
            print(f"[{log_level}] No capability info found for {repo_name}, skipping")
            continue

        # Process validations directory for prompt-response pairs
        prompt_responses, global_id_counter = process_validation_dir(
            repo_path, log_level, global_id_counter
        )
        if not prompt_responses:
            print(f"[{log_level}] No valid prompt-responses found for {repo_name}")
            continue

        # Combine capability info with prompt-responses
        data = {
            "capabilityId": capability_info["capabilityId"],
            "capabilityName": capability_info["capabilityName"],
            "promptResponses": prompt_responses,
        }
        all_data.append(data)

    # Send the data to the API in batches
    send_data_in_batches(all_data, log_level)


def get_capability_info(repo_path: str, log_level: str) -> Dict[str, str]:
    """
    Extract capability information from .ai_config.toml file.

    Args:
        repo_path (str): Path to the repository
        log_level (str): The log level for logging messages

    Returns:
        Dict[str, str]: Dictionary with capability_id and capability_name or empty dict if not found
    """
    config_path = os.path.join(repo_path, ".ai_config.toml")

    if not os.path.exists(config_path):
        print(f"[{log_level}] No .ai_config.toml found in {repo_path}")
        return {}

    try:
        config = toml.load(config_path)
        if (
            "tags" in config
            and "capability_id" in config["tags"]
            and "capability_name" in config["tags"]
        ):
            return {
                "capabilityId": config["tags"]["capability_id"],
                "capabilityName": config["tags"]["capability_name"],
            }
        else:
            print(f"[{log_level}] Missing capability info in {config_path}")
            return {}
    except Exception as e:
        print(f"[{log_level}] Error reading {config_path}: {str(e)}")
        return {}


def process_validation_dir(
    repo_path: str, log_level: str, id_counter: int
) -> tuple[List[Dict[str, str]], int]:
    """
    Process the validations directory to extract prompt-response pairs.

    Args:
        repo_path (str): Path to the repository
        log_level (str): The log level for logging messages
        id_counter (int): Global ID counter for unique identification

    Returns:
        tuple[List[Dict[str, str]], int]: List of prompt-response pairs and updated ID counter
    """
    validations_dir = os.path.join(repo_path, "validations")

    if not os.path.exists(validations_dir) or not os.path.isdir(validations_dir):
        print(f"[{log_level}] No validations directory found in {repo_path}")
        return [], id_counter

    test_suite_path = os.path.join(validations_dir, "test-suite.yaml")

    if not os.path.exists(test_suite_path):
        print(f"[{log_level}] No test-suite.yaml found in {validations_dir}")
        return [], id_counter

    prompt_responses = []

    try:
        with open(test_suite_path, "r") as f:
            test_suite = yaml.safe_load(f)

        if (
            not test_suite
            or not isinstance(test_suite, dict)
            or "testCases" not in test_suite
        ):
            print(f"[{log_level}] Invalid test-suite.yaml format in {test_suite_path}")
            return [], id_counter

        test_cases = test_suite["testCases"]
        if not test_cases or not isinstance(test_cases, list):
            print(f"[{log_level}] No test cases found in {test_suite_path}")
            return [], id_counter

        for test_case in test_cases:
            if (
                "prompt" not in test_case
                or "responses" not in test_case
                or not test_case["responses"]
            ):
                print(f"[{log_level}] Missing prompt or responses in test case")
                continue

            prompt = test_case["prompt"]
            response_file = test_case["responses"][0]  # Take only the first response

            # Check if the response file exists
            response_path = validations_dir + response_file
            if not os.path.exists(response_path):
                print(f"[{log_level}] Response file {response_path} not found")
                continue

            # Read the response file
            try:
                with open(response_path, "r") as f:
                    response = f.read()

                # Encode response in base64
                response_base64 = base64.b64encode(response.encode()).decode()

                prompt_responses.append(
                    {"id": id_counter, "prompt": prompt, "response": response_base64}
                )
                id_counter += 1

            except Exception as e:
                print(
                    f"[{log_level}] Error reading response file {response_path}: {str(e)}"
                )

    except Exception as e:
        print(f"[{log_level}] Error processing {test_suite_path}: {str(e)}")

    return prompt_responses, id_counter


def send_data_in_batches(all_data: List[Dict[str, Any]], log_level: str) -> None:
    """
    Send prompt-response data to the API in batches.

    Args:
        all_data (List[Dict[str, Any]]): List of data with capability info and prompt-responses
        log_level (str): The log level for logging messages
    """
    total_items = len(all_data)
    if total_items == 0:
        print(f"[{log_level}] No data to send to API")
        return

    print(f"[{log_level}] Sending data for {total_items} capabilities to API")

    for item in all_data:
        capability_id = item["capabilityId"]
        capability_name = item["capabilityName"]
        prompt_responses = item["promptResponses"]

        # Process in batches of BATCH_SIZE
        for i in range(0, len(prompt_responses), BATCH_SIZE):
            batch = prompt_responses[i : i + BATCH_SIZE]

            payload = {
                "capabilityId": capability_id,
                "capabilityName": capability_name,
                "promptResponses": batch,
            }

            try:
                headers = {
                    "Authorization": AUTH_HEADER,
                    "Content-Type": "application/json",
                }

                response = requests.post(API_URL, headers=headers, json=payload)

                if response.status_code == 200:
                    print(
                        f"[{log_level}] Successfully sent batch of {len(batch)} prompt-responses for capability {capability_name}"
                    )
                else:
                    print(
                        f"[{log_level}] API request failed with status {response.status_code}: {response.text}"
                    )

            except Exception as e:
                print(f"[{log_level}] Error sending data to API: {str(e)}")


def main():
    """
    Main function to run the script from the command line.
    """
    parser = argparse.ArgumentParser(
        description="Process repository data and send to API"
    )
    parser.add_argument(
        "--repo-dir",
        default="/tmp/GoldenRepoOrg-prd",
        help="Directory containing the cloned repositories",
    )
    parser.add_argument("--log-level", default="main", help="Log level")

    args = parser.parse_args()

    process_repositories(args.repo_dir, args.log_level)


if __name__ == "__main__":
    main()
