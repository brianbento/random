import argparse
import concurrent.futures
import os
import shutil

from git import Repo
from github import Github

from codegencli.scripts.constants.constants import GITHUB_API_BASE_URL


def fetch_org_repos(
    github_token,
    org_name="GoldenRepoOrg-prd",
    output_dir="/tmp/GoldenRepoOrg-prd",
    branch=None,
    max_workers=5,
    log_level="main",
):
    """
    Fetches all repositories from a GitHub organization and saves them locally.

    Args:
        github_token (str): The GitHub token for authentication.
        org_name (str): The name of the GitHub organization.
        output_dir (str): The directory where repositories will be saved.
        branch (str): Optional specific branch to clone (defaults to default branch if None).
        max_workers (int): Maximum number of parallel workers for cloning repositories.
        log_level (str): The log level for logging messages.

    Returns:
        list: A list of dictionaries containing information about the cloned repositories.
    """
    # Initialize GitHub API client
    g = Github(base_url=GITHUB_API_BASE_URL, login_or_token=github_token)

    try:
        # Get the organization object
        org = g.get_organization(org_name)
        print(f"[{log_level}] Found organization: {org_name}")

        # Get all repositories in the organization
        repos = list(org.get_repos())
        print(f"[{log_level}] Found {len(repos)} repositories in {org_name}")

        # Create the output directory if it doesn't exist
        if not os.path.exists(output_dir):
            os.makedirs(output_dir)
            print(f"[{log_level}] Created output directory: {output_dir}")

        # Clone repositories in parallel
        cloned_repos = []
        with concurrent.futures.ThreadPoolExecutor(max_workers=max_workers) as executor:
            future_to_repo = {
                executor.submit(
                    clone_repository, repo, github_token, output_dir, branch, log_level
                ): repo
                for repo in repos
            }

            for future in concurrent.futures.as_completed(future_to_repo):
                repo = future_to_repo[future]
                try:
                    result = future.result()
                    if result:
                        cloned_repos.append(result)
                except Exception as e:
                    print(
                        f"[{log_level}] Error cloning repository {repo.name}: {str(e)}"
                    )

        print(
            f"[{log_level}] Successfully cloned {len(cloned_repos)} repositories to {output_dir}"
        )
        return cloned_repos

    except Exception as e:
        print(f"[{log_level}] Error accessing organization {org_name}: {str(e)}")
        return []


def clone_repository(repo, github_token, output_dir, branch=None, log_level="main"):
    """
    Clones a single repository to the specified directory.

    Args:
        repo (github.Repository): The GitHub repository object.
        github_token (str): The GitHub token for authentication.
        output_dir (str): The directory where the repository will be saved.
        branch (str): Optional specific branch to clone (defaults to default branch if None).
        log_level (str): The log level for logging messages.

    Returns:
        dict: Information about the cloned repository.
    """
    repo_name = repo.name
    repo_path = os.path.join(output_dir, repo_name)

    # Remove existing repository if it exists
    if os.path.exists(repo_path):
        shutil.rmtree(repo_path)
        print(f"[{log_level}] Deleted existing directory {repo_path}")

    # Construct the remote URL for cloning
    remote_url = f"https://{github_token}@github.intuit.com/{repo.organization.login}/{repo_name}.git"

    try:
        # Clone the repository
        clone_args = {"url": remote_url, "to_path": repo_path}

        # Specify branch if provided
        if branch:
            clone_args["branch"] = branch

        Repo.clone_from(**clone_args)

        print(
            f"[{log_level}] Successfully cloned repository {repo_name} to {repo_path}"
        )

        return {
            "name": repo_name,
            "path": repo_path,
            "url": repo.html_url,
            "description": repo.description,
            "default_branch": repo.default_branch,
        }

    except Exception as e:
        print(f"[{log_level}] Failed to clone repository {repo_name}: {str(e)}")
        return None


def main():
    """
    Main function to run the script from the command line.
    """
    parser = argparse.ArgumentParser(
        description="Fetch repositories from a GitHub organization"
    )
    parser.add_argument(
        "--token", required=True, help="GitHub token for authentication"
    )
    parser.add_argument(
        "--org", default="GoldenRepoOrg-prd", help="GitHub organization name"
    )
    parser.add_argument(
        "--output",
        default="/tmp/GoldenRepoOrg-prd",
        help="Output directory for repositories",
    )
    parser.add_argument(
        "--branch",
        help="Specific branch to clone (defaults to default branch if not specified)",
    )
    parser.add_argument(
        "--workers", type=int, default=5, help="Maximum number of parallel workers"
    )
    parser.add_argument("--log-level", default="main", help="Log level")

    args = parser.parse_args()

    fetch_org_repos(
        github_token=args.token,
        org_name=args.org,
        output_dir=args.output,
        branch=args.branch,
        max_workers=args.workers,
        log_level=args.log_level,
    )


if __name__ == "__main__":
    main()
