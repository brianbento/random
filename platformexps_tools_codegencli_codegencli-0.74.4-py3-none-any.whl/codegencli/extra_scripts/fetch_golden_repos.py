# mypy: ignore-errors
"""
Script to fetch all repositories from GoldenRepoOrg-prd organization
and save them under /tmp/GoldenRepoOrg-prd
"""

import argparse

from codegencli.extra_scripts.repo_fetcher import fetch_org_repos


def main():
    """
    Main function to fetch all repositories from GoldenRepoOrg-prd.
    """
    parser = argparse.ArgumentParser(
        description="Fetch repositories from GoldenRepoOrg-prd"
    )
    parser.add_argument(
        "--token", required=True, help="GitHub token for authentication"
    )
    parser.add_argument(
        "--output",
        default="/tmp/GoldenRepoOrg-prd",
        help="Output directory (default: /tmp/GoldenRepoOrg-prd)",
    )
    parser.add_argument(
        "--branch", help="Specific branch to clone (defaults to default branch)"
    )
    parser.add_argument(
        "--workers",
        type=int,
        default=5,
        help="Maximum number of parallel workers (default: 5)",
    )
    args = parser.parse_args()

    # Fetch repositories
    repos = fetch_org_repos(
        github_token=args.token,
        org_name="GoldenRepoOrg-prd",
        output_dir=args.output,
        branch=args.branch,
        max_workers=args.workers,
    )

    # Print summary
    if repos:
        print(f"\nSuccessfully cloned {len(repos)} repositories to {args.output}")
        print("Repository list:")
        for repo in repos:
            print(f"  - {repo['name']} ({repo['default_branch']})")
    else:
        print("No repositories were cloned. Check the logs for errors.")


if __name__ == "__main__":
    main()
