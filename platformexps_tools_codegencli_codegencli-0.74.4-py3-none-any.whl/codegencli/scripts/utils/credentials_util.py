import click

from codegencli.scripts.commands.get_credentials import (
    get_and_store_credentials,
    load_credentials,
)


def get_stored_credentials(require=True, auto_request=True):
    """
    Get stored credentials or request new ones if not available.

    Args:
        require (bool): If True, raise an error when credentials can't be found or obtained.
        auto_request (bool): If True, automatically request new credentials when not found.

    Returns:
        dict: The credentials or None if no credentials are available and require is False.

    Raises:
        click.ClickException: If credentials are required but not available.
    """
    credentials = load_credentials()

    if credentials:
        return credentials

    if auto_request:
        click.echo("No credentials found. Requesting new credentials...")
        credentials = get_and_store_credentials()
        if credentials:
            return credentials

    if require:
        raise click.ClickException(
            "Authentication credentials are required but not available. "
            "Please run 'codegencli login' to obtain credentials."
        )

    return None
