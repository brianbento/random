"""
Secure storage service for MCP credentials.

This module provides functionality to securely store and retrieve MCP credentials
using the system keychain (macOS Keychain, Windows Credential Manager, or Linux Secret Service).
"""

import json

# Import keyring with proper error handling for mypy
from typing import TYPE_CHECKING, Any, Dict, List, Optional, Union, cast

if TYPE_CHECKING:
    import keyring
    from keyring.errors import PasswordDeleteError

try:
    import keyring
    from keyring.errors import PasswordDeleteError
except ImportError:
    print("Warning: keyring package not available. Secure storage will not work.")
    print("Install with: pip install keyring")
    keyring = cast("keyring", None)  # type: ignore

# Keychain service name prefix
SERVICE_PREFIX = "intuit-mcp-marketplace"


def get_service_name(
    mcp_name: str,
    key_type: Optional[str] = None,
    key_name: Optional[str] = None,
    version: Optional[str] = None,
) -> str:
    """
    Generate a keychain service name for a specific MCP.

    Args:
        mcp_name: Name of the MCP
        key_type: Type of key (env, arg, or metadata)
        key_name: Name of the specific environment variable or argument
        version: Version of the MCP (optional)

    Returns:
        A keychain service name string
    """
    service = f"{SERVICE_PREFIX}:{mcp_name}"
    if version:
        service = f"{service}:{version}"
    if key_type and key_name:
        service = f"{service}.{key_type}.{key_name}"
    elif key_type:
        service = f"{service}.{key_type}"
    return service


def store_env_var(
    mcp_name: str, env_name: str, env_value: str, version: str = "latest"
) -> bool:
    """
    Store an environment variable for an MCP in the keychain.

    Args:
        mcp_name: Name of the MCP
        env_name: Name of the environment variable
        env_value: Value of the environment variable
        version: Version of the MCP (default: "latest")

    Returns:
        True if successful, False otherwise
    """
    try:
        service = get_service_name(mcp_name, "env", env_name, version)
        keyring.set_password(service, "", env_value)
        return True
    except Exception as e:
        print(f"Error storing environment variable: {e}")
        return False


def store_arg(
    mcp_name: str, arg_name: str, arg_value: str, version: str = "latest"
) -> bool:
    """
    Store a command argument for an MCP in the keychain.

    Args:
        mcp_name: Name of the MCP
        arg_name: Name of the argument
        arg_value: Value of the argument
        version: Version of the MCP (default: "latest")

    Returns:
        True if successful, False otherwise
    """
    try:
        service = get_service_name(mcp_name, "arg", arg_name, version)
        keyring.set_password(service, "", arg_value)
        return True
    except Exception as e:
        print(f"Error storing argument: {e}")
        return False


def get_env_var(mcp_name: str, env_name: str, version: str = "latest") -> Optional[str]:
    """
    Retrieve an environment variable for an MCP from the keychain.

    Args:
        mcp_name: Name of the MCP
        env_name: Name of the environment variable
        version: Version of the MCP (default: "latest")

    Returns:
        The value of the environment variable, or None if not found
    """
    try:
        service = get_service_name(mcp_name, "env", env_name, version)
        return keyring.get_password(service, "")
    except Exception:
        return None


def get_arg(mcp_name: str, arg_name: str, version: str = "latest") -> Optional[str]:
    """
    Retrieve a command argument for an MCP from the keychain.

    Args:
        mcp_name: Name of the MCP
        arg_name: Name of the argument
        version: Version of the MCP (default: "latest")

    Returns:
        The value of the argument, or None if not found
    """
    try:
        service = get_service_name(mcp_name, "arg", arg_name, version)
        return keyring.get_password(service, "")
    except Exception:
        return None


def store_mcp_metadata(
    mcp_name: str,
    command_path: str,
    script_path: str,
    env_vars: Dict[str, str],
    args: List[str],
    version: str = "latest",
) -> bool:
    """
    Store MCP metadata in the keychain.

    Args:
        mcp_name: Name of the MCP
        command_path: Path to the command executable (python/node)
        script_path: Path to the script file
        env_vars: Dictionary of environment variables
        args: List of command arguments
        version: Version of the MCP

    Returns:
        True if successful, False otherwise
    """
    metadata = {
        "command_path": command_path,
        "script_path": script_path,
        "env_var_names": list(env_vars.keys()),
        "arg_names": [
            arg.split("=")[0].lstrip("--") if "=" in arg else arg.lstrip("--")
            for arg in args
            if arg.startswith("--")
        ],
    }

    try:
        service = get_service_name(mcp_name, "metadata", version=version)
        keyring.set_password(service, "", json.dumps(metadata))
        return True
    except Exception as e:
        print(f"Error storing metadata: {e}")
        return False


def get_mcp_metadata(
    mcp_name: str, version: str = "latest"
) -> Optional[Dict[str, Any]]:
    """
    Retrieve MCP metadata from the keychain.

    Args:
        mcp_name: Name of the MCP
        version: Version of the MCP (default: "latest")

    Returns:
        Dictionary with MCP metadata, or None if not found
    """
    try:
        service = get_service_name(mcp_name, "metadata", version=version)
        data = keyring.get_password(service, "")
        return json.loads(data) if data else None
    except Exception:
        return None


def get_all_env_vars(mcp_name: str, version: str = "latest") -> Dict[str, str]:
    """
    Retrieve all environment variables for an MCP from the keychain.

    Args:
        mcp_name: Name of the MCP
        version: Version of the MCP (default: "latest")

    Returns:
        Dictionary of environment variables
    """
    env_vars = {}
    metadata = get_mcp_metadata(mcp_name, version)

    if metadata and "env_var_names" in metadata:
        for env_name in metadata["env_var_names"]:
            value = get_env_var(mcp_name, env_name, version)
            if value:
                env_vars[env_name] = value

    return env_vars


def get_all_args(mcp_name: str, version: str = "latest") -> List[str]:
    """
    Retrieve all arguments for an MCP from the keychain.

    Args:
        mcp_name: Name of the MCP
        version: Version of the MCP (default: "latest")

    Returns:
        List of formatted argument strings
    """
    args = []
    metadata = get_mcp_metadata(mcp_name, version)

    if metadata and "arg_names" in metadata:
        for arg_name in metadata["arg_names"]:
            value = get_arg(mcp_name, arg_name, version)
            if value:
                args.append(f"--{arg_name}={value}")

    return args


def list_installed_mcps() -> List[str]:
    """
    List all installed MCPs with credentials in the keychain.

    Returns:
        List of MCP names
    """
    # For now, we'll check if we can get metadata for known MCPs
    # This is a simplified approach - a full implementation would
    # need to enumerate keychain entries, which varies by platform
    mcp_names = []

    # Check common MCP names or use a different approach
    # For now, try to detect from the marketplace directory
    import os

    marketplace_dir = os.path.expanduser("~/.intuit-mcp-marketplace")

    if os.path.exists(marketplace_dir):
        for item in os.listdir(marketplace_dir):
            item_path = os.path.join(marketplace_dir, item)
            if os.path.isdir(item_path) and not item.startswith("."):
                # Check if this MCP has metadata in keychain
                if get_mcp_metadata(item):
                    mcp_names.append(item)

    return mcp_names


def delete_mcp_credentials(mcp_name: str) -> bool:
    """
    Delete all stored credentials for an MCP from the keychain.

    Args:
        mcp_name: Name of the MCP

    Returns:
        True if successful, False otherwise
    """
    try:
        # Get metadata to find all keys to delete
        metadata = get_mcp_metadata(mcp_name)

        if metadata:
            # Delete environment variables
            if "env_var_names" in metadata:
                for env_name in metadata["env_var_names"]:
                    service = get_service_name(mcp_name, "env", env_name)
                    try:
                        keyring.delete_password(service, "")
                    except PasswordDeleteError:
                        pass  # Ignore if already deleted

            # Delete arguments
            if "arg_names" in metadata:
                for arg_name in metadata["arg_names"]:
                    service = get_service_name(mcp_name, "arg", arg_name)
                    try:
                        keyring.delete_password(service, "")
                    except PasswordDeleteError:
                        pass  # Ignore if already deleted

            # Delete metadata itself
            service = get_service_name(mcp_name, "metadata")
            try:
                keyring.delete_password(service, "")
            except keyring.errors.PasswordDeleteError:
                pass  # Ignore if already deleted

        return True
    except Exception as e:
        print(f"Error deleting credentials: {e}")
        return False


def store_mcp_v2_metadata(
    mcp_name: str,
    image_name: str,
    env_vars: Dict[str, str],
    version: str = "latest",
    mcp_id: Optional[str] = None,
    commit_id: Optional[str] = None,
) -> bool:
    """
    Store v2 MCP metadata in the keychain.

    Args:
        mcp_name: Name of the MCP
        image_name: Docker image name
        env_vars: Dictionary of environment variables
        version: Version of the MCP
        mcp_id: MCP ID from the v2 API
        commit_id: Commit ID from the version details

    Returns:
        True if successful, False otherwise
    """
    import base64

    metadata = {
        "image_name": image_name + ":" + version,
        "env": env_vars,
        "mcp_id": mcp_id,
        "commit_id": commit_id,
    }

    try:
        service = get_service_name(mcp_name, version=version)
        # Store as base64 encoded JSON
        encoded_data = base64.b64encode(json.dumps(metadata).encode()).decode()
        keyring.set_password(service, "", encoded_data)
        return True
    except Exception as e:
        print(f"Error storing v2 metadata: {e}")
        return False


def get_mcp_v2_metadata(
    mcp_name: str, version: str = "latest"
) -> Optional[Dict[str, Any]]:
    """
    Retrieve v2 MCP metadata from the keychain.

    Args:
        mcp_name: Name of the MCP
        version: Version of the MCP (default: "latest")

    Returns:
        Dictionary with v2 MCP metadata, or None if not found
    """
    import base64

    try:
        service = get_service_name(mcp_name, version=version)
        data = keyring.get_password(service, "")
        if data:
            # Decode base64 and parse JSON
            decoded_data = base64.b64decode(data.encode()).decode()
            return json.loads(decoded_data)
        return None
    except Exception:
        return None
