import json
import os
import uuid

import requests
from requests import RequestException

# Lambda endpoint for authenticated API calls
LAMBDA_ENDPOINT = "https://tgmu28tvmh.execute-api.us-east-1.amazonaws.com"


def refresh_metadata_tags(
    env, codium_metadata_service_url, intuit_tid, log_level="main"
):
    """
    Refreshes metadata tags for a given environment and metadata service URL.

    Args:
        env (str): The environment for which to refresh metadata tags.
        codium_metadata_service_url (str): The URL of the metadata service.
        intuit_tid (str): The transaction ID for tracking requests.
        log_level (str): The log level for logging messages. Default is "main".

    Raises:
        Exception: If the request to refresh metadata tags fails.
    """
    try:
        # Use Lambda endpoint for authenticated API call (secrets handled server-side)
        refresh_url = f"{LAMBDA_ENDPOINT}/v1/metadata/cap/refresh-tag"

        # Prepare the request body with environment and metadata service URL
        request_body = {"env": env, "metadataServiceUrl": codium_metadata_service_url}

        # Set the headers with target service and transaction ID
        headers = {
            "Content-Type": "application/json",
            "intuit_tid": intuit_tid,
            "x-target-service": "metadata-catalog",
            "x-corp-id": os.getenv("USER", "cli-user"),
        }

        # Send a POST request to refresh metadata tags
        response = requests.post(
            refresh_url, headers=headers, data=json.dumps(request_body)
        )

        # Check if the response status is 202 (Accepted)
        if response.status_code == 202:
            print(
                f"[{log_level}] Refreshing metadata tags successful for env {env} with tid: {intuit_tid}."
            )
        else:
            # Log the failure and raise an exception
            print(
                f"[{log_level}] Failed to refresh metadata tags for env {env} with response status: {response.status_code} and tid: {intuit_tid}"
            )
            print(f"[{log_level}] Got response: {response.text} with tid: {intuit_tid}")
            raise Exception(
                f"An error occurred while refreshing metadata tags for env {env} with tid: {intuit_tid}."
            )
    except RequestException as e:
        # Handle request exceptions and log the error
        print(
            f"[{log_level}] An unexpected error occurred while refreshing metadata tags for env {env} with tid: {intuit_tid}. Error: {str(e)}"
        )
        raise Exception(
            f"An unexpected error occurred during the metadata tag refresh with tid: {intuit_tid}."
        ) from e


def get_metadata_record(capability_id, intuit_tid, log_level="main"):
    """
    Retrieves metadata for a given capability ID.

    Args:
        capability_id (str): The ID of the capability to fetch metadata for.
        intuit_tid (str): The transaction ID for tracking requests.
        log_level (str): The log level for logging messages. Default is "main".

    Returns:
        dict: The metadata record for the specified capability ID.

    Raises:
        Exception: If the request to get metadata fails or the capability ID does not exist.
    """
    try:
        print(f"[{log_level}] Fetching Metadata for capability ID: {capability_id}")

        # Use Lambda endpoint for authenticated API call (secrets handled server-side)
        url = f"{LAMBDA_ENDPOINT}/v1/metadata/cap/{capability_id}"

        # Set the headers with target service and transaction ID
        headers = {
            "Content-Type": "application/json",
            "intuit_tid": intuit_tid,
            "x-target-service": "metadata-catalog",
            "x-corp-id": os.getenv("USER", "cli-user"),
        }

        # Send a GET request to retrieve metadata through Lambda
        response = requests.get(url, headers=headers)

        # Check if the response status is 200 (OK)
        if response.status_code == 200:
            metadata = response.json()
            print(
                f"[{log_level}] Successfully fetched the metadata for capability ID {capability_id}"
            )
            return metadata
        elif response.status_code == 404:
            # Log the non-existence of the capability ID and raise an exception
            print(f"[{log_level}] Capability ID {capability_id} does not exist.")
            raise Exception(f"Capability ID {capability_id} does not exist.")
        else:
            # Log the failure and raise an exception
            print(
                f"[{log_level}] Failed to get metadata for capability ID {capability_id} with response status code: {response.status_code} and tid: {intuit_tid}."
            )
            print(f"[{log_level}] Got response: {response.text}")
            raise Exception(
                f"An error occurred while getting metadata for capability ID {capability_id}."
            )
    except requests.exceptions.RequestException as e:
        # Handle request exceptions and log the error
        print(
            f"[{log_level}] An unexpected error occurred while getting metadata from the catalog: {str(e)}"
        )
        raise Exception(f"An unexpected error occurred: {str(e)}")


def create_metadata_record(
    repo_url, capability_id, commit_hash, intuit_tid, log_level="main"
):
    """
    Creates a metadata record for a given capability ID.

    Args:
        repo_url (str): The URL of the repository.
        capability_id (str): The ID of the capability to create metadata for.
        commit_hash (str): The commit hash for the current state.
        intuit_tid (str): The transaction ID for tracking requests.
        log_level (str): The log level for logging messages. Default is "main".

    Returns:
        dict: The response from the metadata creation request.

    Raises:
        Exception: If the request to create metadata fails.
    """
    try:
        print(f"[{log_level}] Creating Metadata for capability ID: {capability_id}")

        # Use Lambda endpoint for authenticated API call (secrets handled server-side)
        url = f"{LAMBDA_ENDPOINT}/v1/metadata/env/cli/cap/{capability_id}"

        # Prepare the metadata payload with repository URL and commit hash
        metadata_payload = {"repo": repo_url, "current_commit": commit_hash}

        # Set the headers with target service and transaction ID
        headers = {
            "Content-Type": "application/json",
            "intuit_tid": intuit_tid,
            "x-target-service": "metadata-catalog",
            "x-corp-id": os.getenv("USER", "cli-user"),
        }

        # Send a POST request to create metadata through Lambda
        response = requests.post(url, headers=headers, json=metadata_payload)

        # Check if the response status is 200 (OK)
        if response.status_code == 200:
            print(
                f"[{log_level}] Successfully created the metadata for capability ID {capability_id}."
            )
            return response.json()
        else:
            # Log the failure and raise an exception
            print(
                f"[{log_level}] Failed to create metadata for capability ID {capability_id} with response status code: {response.status_code} and tid: {intuit_tid}."
            )
            print(f"[{log_level}] Got response: {response.text}")
            raise Exception(
                f"An error occurred while creating metadata for capability ID {capability_id}."
            )
    except RequestException as e:
        # Handle request exceptions and log the error
        print(
            f"[{log_level}] An unexpected error occurred while creating metadata: {str(e)}"
        )
        raise Exception(f"An unexpected error occurred: {str(e)}")
