import os
import shutil
import time
import zipfile

import requests

from codegencli.scripts.constants.constants import GITHUB_ORG_NAME


def upload_validation_data_to_s3(capability_id, api_key, log_level="main"):
    """
    Uploads validation data to an S3 bucket.

    Args:
        capability_id (str): The capability identifier.
        api_key (str): The API key for authentication.
        log_level (str): The log level for logging messages.

    Returns:
        bool: True if the upload was successful, otherwise raises an exception.
    """
    # Construct the upload URL
    upload_url = f"https://code-gen-eval.api.intuit.com/v1/validation-data/upload-to-s3?intuit_apikey={api_key}"
    headers = {
        "Content-Type": "application/json",
    }
    # Prepare the data payload
    data = {
        "repo": f"https://github.intuit.com/{GITHUB_ORG_NAME}/{capability_id}",
        "env": "cli",
        "capabilityId": capability_id,
    }

    try:
        # Send a POST request to upload the data
        response = requests.post(upload_url, headers=headers, json=data)
        if response.status_code == 200:
            print(f"[{log_level}] Validation data uploaded to S3 successfully.")
            return True
        else:
            # Handle upload failure
            error_message = (
                f"[{log_level}] Failed to upload validation data to S3. "
                f"Status code: {response.status_code}, "
                f"Response: {response.text}, "
                f"Headers: {response.headers}"
            )
            print(error_message)
            raise Exception(error_message)
    except requests.RequestException as e:
        raise Exception(f"[{log_level}] An error occurred while uploading to S3: {e}")


def run_remote_validation_test(
    build_id, capability_id, commit_id, api_key, log_level="main"
):
    """
    Initiates a remote validation test.

    Args:
        build_id (str): The build identifier.
        capability_id (str): The capability identifier.
        commit_id (str): The commit identifier.
        api_key (str): The API key for authentication.
        log_level (str): The log level for logging messages.
    """
    # Construct the URL for running the validation test
    url = (
        f"https://code-gen-eval.api.intuit.com/v1/evaluate/task?intuit_apikey={api_key}"
    )
    headers = {
        "Content-Type": "application/json",
    }
    # Prepare the data payload
    data = {
        "buildId": build_id,
        "env": "cli",
        "capabilityId": capability_id,
        "commitId": commit_id,
        "codeGenServiceUrl": "https://codiumaicodiumate-qal.api.intuit.com/cli-qodo/v2/chats/chat",
        "repo": f"https://github.intuit.com/{GITHUB_ORG_NAME}/{capability_id}",
    }

    # Send a POST request to run the validation test
    response = requests.post(url, headers=headers, json=data)

    if response.status_code == 202:
        print(f"[{log_level}] Validation test ran successfully.")
    else:
        print(
            f"[{log_level}] Failed to run validation test. Status code: {response.status_code}"
        )
        print(f"[{log_level}] Response: {response.text}")


def wait_for_validation_report(intuit_tid, api_key, log_level="main"):
    """
    Waits for the validation report to be ready.

    Args:
        intuit_tid (str): The transaction ID for tracking.
        api_key (str): The API key for authentication.
        log_level (str): The log level for logging messages.
    """
    # Construct the URL to fetch the validation report
    url = f"https://code-gen-eval.api.intuit.com/v1/validation-report/environment/cli/build/{intuit_tid}?intuit_apikey={api_key}"

    headers = {"Content-Type": "application/json"}

    while True:
        # Send a GET request to check the report status
        response = requests.get(url, headers=headers)

        if response.status_code == 200:
            try:
                report_data = response.json()

                if report_data:
                    print(f"[{log_level}] Validation report is ready")
                    break
                else:
                    print(
                        f"[{log_level}] Validation report is not ready yet. Retrying in 15 seconds..."
                    )
                    time.sleep(15)
            except (IndexError, KeyError, ValueError) as e:
                print(f"[{log_level}] Error processing the response: {e}")
                return None
        else:
            print(
                f"[{log_level}] Unexpected error occurred. Status code: {response.status_code}"
            )
            print(f"[{log_level}] Response: {response.text}")
            time.sleep(15)


def download_and_extract_report(working_dir, build_id, api_key):
    """
    Downloads and extracts the validation report.

    Args:
        working_dir (str): The working directory to save the report.
        build_id (str): The build identifier.
        api_key (str): The API key for authentication.
        log_level (str): The log level for logging messages.
    """
    # Construct the URL to download the report
    url = f"https://code-gen-eval.api.intuit.com/v1/validation-report/download/environment/cli/build/{build_id}?intuit_apikey={api_key}"

    # Define the local directory and file name for the report
    local_dir = os.path.join(working_dir, "logs")
    local_filename = "report.zip"

    # Remove existing directory and create a new one
    if os.path.exists(local_dir):
        shutil.rmtree(local_dir)
    os.makedirs(local_dir)

    # Define the local file path for the downloaded report
    local_file_path = os.path.join(local_dir, local_filename)

    # Send a POST request to download the report
    response = requests.post(url, stream=True)
    response.raise_for_status()

    # Write the downloaded content to a file
    with open(local_file_path, "wb") as f:
        for chunk in response.iter_content(chunk_size=8192):
            f.write(chunk)

    # Extract the contents of the zip file
    with zipfile.ZipFile(local_file_path, "r") as zip_ref:
        zip_ref.extractall(local_dir)

    # Remove the zip file after extraction
    os.remove(local_file_path)
