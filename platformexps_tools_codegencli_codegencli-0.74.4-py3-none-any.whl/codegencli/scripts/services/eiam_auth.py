"""
EIAM authentication service for handling user authentication via eiamcli
"""

import json
import os
import subprocess
import time
from typing import Dict, Optional, Tuple

from rich import print as rprint

from ..commands.mcp.constants import AUTH_ENV, ERROR_ICON, INFO_ICON, SUCCESS_ICON
from ..commands.mcp.logging_helper import get_mcp_logger


class EIAMAuthService:
    """Service for handling EIAM authentication via eiamcli"""

    def __init__(self):
        self.logger = get_mcp_logger()
        # Memory cache for IAM ticket with TTL
        self._cached_ticket = None
        self._cache_timestamp = None
        self._cache_ttl = 3600  # 1 hour in seconds
        # Check if we should use pre-prod environment
        self._use_preprod = self._should_use_preprod()

    def _should_use_preprod(self) -> bool:
        """Determine if we should use pre-prod environment"""
        if AUTH_ENV != "prod":
            self.logger.info(f"Using pre-prod environment (AUTH_ENV={AUTH_ENV})")
            return True
        return False

    def _run_eiamcli_command(self, command: str) -> Tuple[bool, str]:
        """
        Run an eiamcli command and return success status and output

        Args:
            command: The eiamcli command to run

        Returns:
            Tuple of (success, output)
        """
        try:
            # Build command
            cmd = ["eiamcli"]

            # Add environment flag if using pre-prod
            if self._use_preprod:
                cmd.extend(["--env", "pre-prod"])

            # Add the actual command (e.g., "iamticket" or "login")
            cmd.append(command)

            # Build command string for logging
            cmd_str = " ".join(cmd)
            self.logger.debug(f"Running eiamcli command: {cmd_str}")
            result = subprocess.run(cmd, capture_output=True, text=True, timeout=30)

            return result.returncode == 0, result.stdout.strip()
        except subprocess.TimeoutExpired:
            self.logger.error(f"eiamcli {command} command timed out")
            return False, "Command timed out"
        except FileNotFoundError:
            self.logger.error("eiamcli command not found")
            return False, "eiamcli not found"
        except Exception as e:
            self.logger.error(f"Error running eiamcli {command}: {str(e)}")
            return False, str(e)

    def _get_iam_ticket(self) -> Optional[Dict[str, str]]:
        """
        Get IAM ticket from eiamcli with memory caching

        Returns:
            Dictionary with userId and ticket, or None if failed
        """
        # Check if we have a valid cached ticket
        if self._is_cache_valid():
            self.logger.debug("Using cached IAM ticket")
            return self._cached_ticket

        success, output = self._run_eiamcli_command("iamticket")

        if not success:
            self.logger.debug(f"Failed to get IAM ticket: {output}")
            return None

        try:
            # Parse JSON response
            ticket_data = json.loads(output)
            user_id = ticket_data.get("userId")
            ticket = ticket_data.get("ticket")

            if user_id and ticket:
                ticket_dict = {"userId": user_id, "ticket": ticket}
                # Cache the ticket
                self._cache_ticket(ticket_dict)
                return ticket_dict
            else:
                self.logger.error("Invalid ticket response format")
                return None

        except json.JSONDecodeError as e:
            self.logger.error(f"Failed to parse ticket response: {str(e)}")
            return None

    def _is_cache_valid(self) -> bool:
        """Check if cached ticket is still valid"""
        if self._cached_ticket is None or self._cache_timestamp is None:
            return False

        current_time = time.time()
        return (current_time - self._cache_timestamp) < self._cache_ttl

    def _cache_ticket(self, ticket_data: Dict[str, str]) -> None:
        """Cache the ticket data with current timestamp"""
        self._cached_ticket = ticket_data
        self._cache_timestamp = time.time()
        self.logger.debug("IAM ticket cached successfully")

    def _clear_cache(self) -> None:
        """Clear the cached ticket"""
        self._cached_ticket = None
        self._cache_timestamp = None
        self.logger.debug("IAM ticket cache cleared")

    def _perform_login(self) -> bool:
        """
        Perform EIAM login via eiamcli

        Returns:
            True if login successful, False otherwise
        """
        rprint(
            f"{INFO_ICON} [yellow]Authentication required. Starting EIAM login...[/]"
        )

        success, output = self._run_eiamcli_command("login")

        if success:
            rprint(f"{SUCCESS_ICON} [green]EIAM login completed successfully[/]")
            self.logger.info("EIAM login successful")
            return True
        else:
            rprint(f"{ERROR_ICON} [red]EIAM login failed: {output}[/]")
            self.logger.error(f"EIAM login failed: {output}")
            return False

    def get_auth_credentials(self) -> Optional[Dict[str, str]]:
        """
        Get authentication credentials (userId, ticket)

        This method will:
        1. Try to get existing IAM ticket (from cache or eiamcli)
        2. If expired/invalid, perform login and retry
        3. Return credentials or None if failed

        Returns:
            Dictionary with userId and ticket, or None if failed
        """
        # First, try to get existing ticket (will use cache if valid)
        ticket_data = self._get_iam_ticket()

        if ticket_data:
            self.logger.info("Using IAM ticket (cached or fresh)")
            return {
                "userId": ticket_data["userId"],
                "ticket": ticket_data["ticket"],
            }

        # If no valid ticket, clear cache and perform login
        self.logger.info("No valid IAM ticket found, performing login")
        self._clear_cache()

        if not self._perform_login():
            return None

        # Wait a moment for login to complete
        time.sleep(2)

        # Try to get ticket again after login (will cache if successful)
        ticket_data = self._get_iam_ticket()

        if ticket_data:
            self.logger.info("Successfully obtained IAM ticket after login")
            return {
                "userId": ticket_data["userId"],
                "ticket": ticket_data["ticket"],
            }
        else:
            self.logger.error("Failed to obtain IAM ticket after login")
            return None


# Global instance for reuse
_eiam_service = None


def get_eiam_auth_service() -> EIAMAuthService:
    """Get singleton instance of EIAM auth service"""
    global _eiam_service
    if _eiam_service is None:
        _eiam_service = EIAMAuthService()
    return _eiam_service
