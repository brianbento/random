import json
import time
import uuid
import webbrowser

import requests
from requests import RequestException


def call_web_service(
    random_key,
    intuit_tid,
    service_url="https://codegen-pr-feedback.app.intuit.com/codegen-pr-feedback-ui/codegencli",
    log_level="main",
):
    """
    Opens a browser with the service endpoint URL for the user to authenticate.

    Args:
        random_key (str): A random key to be sent with the request.
        intuit_tid (str): The transaction ID for tracking.
        service_url (str): The URL of the web service to call. Defaults to the CodeGen PR Feedback service.
        log_level (str): The log level for logging messages.

    Returns:
        str: A placeholder request ID.
    """

    try:
        # Log the start of the process
        print(
            f"[{log_level}] Initiating browser authentication with random key: {random_key}, TID: {intuit_tid}"
        )
        # Construct the service URL
        total_endpoint = f"{service_url}?caller_id={random_key}"
        # Open the URL in a browser
        webbrowser.open(total_endpoint)
        return
    except Exception as ex:
        # Handle any exceptions that occur during the process
        print(
            f"[{log_level}] Error occurred while opening browser: {str(ex)}, TID: {intuit_tid}"
        )
        raise Exception(
            f"An error occurred while opening browser, TID: {intuit_tid}."
        ) from ex


def poll_for_credentials(
    credentials_url="https://pr-feedback-collector.api.intuit.com/v2/credentials",
    random_key=None,
    intuit_tid=None,
    interval_seconds=5,
    timeout_minutes=2,
    log_level="main",
):
    """
    Polls a service for credentials until they are received or the operation times out.

    Args:
        credentials_url (str): The URL of the credentials service. Defaults to a PR Feedback Collector service.
        random_key (str): A random key to be included in the request as callerId parameter.
        intuit_tid (str): The transaction ID for tracking. If None, a random UUID is generated.
        interval_seconds (int): The interval in seconds between status checks.
        timeout_minutes (int): The maximum time in minutes to wait for credentials.
        log_level (str): The log level for logging messages.

    Returns:
        dict: The credentials received from the service.

    Raises:
        Exception: If the polling times out or an error occurs.
    """
    start_time = time.time()
    timeout_seconds = timeout_minutes * 60
    credentials_received = False
    credentials = None

    try:
        while time.time() - start_time < timeout_seconds:
            # Construct headers for the request
            headers = {"Content-Type": "application/json", "intuit_tid": intuit_tid}

            # Send a GET request with callerId as query parameter
            try:
                response = requests.get(
                    credentials_url,
                    headers=headers,
                    params={
                        "callerId": random_key,
                        "intuit_apikey": "prdakyres6qiDvvpcxlNNsJOUQO8WEpQ5H6aenmX",
                    },
                )

                if response.status_code == 200:
                    result = response.json()

                    # Extract userId, token, and corpId directly from the result
                    parsed_credentials = {
                        "userId": result.get("userId"),
                        "token": result.get("token"),
                        "corpId": result.get("corpId"),
                        "retrievedAt": time.time(),
                    }

                    if all(parsed_credentials.values()):
                        credentials_received = True
                        credentials = parsed_credentials
                        break
            except RequestException:
                pass

            # Wait for the specified interval before checking again
            time.sleep(interval_seconds)

        if credentials_received:
            print(f"[{log_level}] Successfully received credentials, TID: {intuit_tid}")
            return credentials
        else:
            error_message = f"Timed out waiting for credentials after {timeout_minutes} minutes, TID: {intuit_tid}"
            print(f"[{log_level}] {error_message}")
            raise Exception(error_message)

    except RequestException as ex:
        error_message = f"Error occurred while polling for credentials: {str(ex)}, TID: {intuit_tid}"
        print(f"[{log_level}] {error_message}")
        raise Exception(error_message) from ex


def request_credentials(
    random_key=None,
    intuit_tid=None,
    credentials_url="https://pr-feedback-collector.api.intuit.com/v2/credentials",
    service_url="https://codegen-pr-feedback.app.intuit.com/codegen-pr-feedback-ui/codegencli",
    poll_interval_seconds=5,
    poll_timeout_minutes=30,
    log_level="main",
):
    """
    Requests credentials by calling a web service with a random key and then polling
    for the credentials until they are received.

    Args:
        random_key (str): A random key to be sent with the request. If None, a random number is generated.
        intuit_tid (str): The transaction ID for tracking. If None, a random UUID is generated.
        credentials_url (str): The URL of the credentials service. Defaults to a PR Feedback Collector service.
        service_url (str): The URL of the web service to call. Defaults to the CodeGen PR Feedback service.
        poll_interval_seconds (int): The interval in seconds between status checks.
        poll_timeout_minutes (int): The maximum time in minutes to wait for credentials.
        log_level (str): The log level for logging messages.

    Returns:
        dict: The credentials received from the service.

    Raises:
        Exception: If an error occurs during the process.
    """
    # Generate random values if not provided
    if random_key is None:
        random_key = str(uuid.uuid4())

    if intuit_tid is None:
        intuit_tid = str(uuid.uuid4())

    try:
        # Call the web service with the random key
        call_web_service(random_key, intuit_tid, service_url, log_level)
        time.sleep(5)
        # Poll for credentials
        credentials = poll_for_credentials(
            credentials_url,
            random_key,
            intuit_tid,
            poll_interval_seconds,
            poll_timeout_minutes,
            log_level,
        )

        return credentials

    except Exception as e:
        print(
            f"[{log_level}] An error occurred during the credential request process with tid: {intuit_tid}. Error: {e}"
        )
        raise Exception(
            f"An error occurred during the credential request process with tid: {intuit_tid}. Error: {e}"
        )
