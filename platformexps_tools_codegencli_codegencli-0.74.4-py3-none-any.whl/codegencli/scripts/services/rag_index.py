import json
import time

import requests
from requests import RequestException

from codegencli.scripts.services.catalog import (
    create_metadata_record,
    get_metadata_record,
    refresh_metadata_tags,
)

# Lambda endpoint for authenticated API calls
LAMBDA_ENDPOINT = "https://tgmu28tvmh.execute-api.us-east-1.amazonaws.com"


def reindex(env, codium_rag_indexer_url, intuit_tid, log_level="main"):
    """
    Initiates the re-indexing process for a given environment.

    Args:
        env (str): The environment for which re-indexing is to be performed.
        codium_rag_indexer_url (str): The URL for the RAG indexer.
        intuit_tid (str): The transaction ID for tracking.
        log_level (str): The log level for logging messages.

    Raises:
        Exception: If an error occurs during the re-indexing process.
    """
    try:
        # Trigger RAG Re-indexing
        job_id = trigger_rag_reindexing(
            env, codium_rag_indexer_url, intuit_tid, log_level
        )

        # Fetch RAG Re-indexing Status
        fetch_rag_reindexing_job_status(job_id, intuit_tid, log_level=log_level)

    except Exception as e:
        print(
            f"[{log_level}] An error occurred during the re-indexing process for env {env} with tid: {intuit_tid}. Error: {e}"
        )
        raise Exception(
            f"[{log_level}] An error occurred during the re-indexing process for env {env} with tid: {intuit_tid}. Error: {e}"
        )


def refresh_metadata(
    codium_metadata_service_url,
    repo_url,
    capability,
    commit_hash,
    intuit_tid,
    log_level="main",
):
    """
    Refreshes metadata for a given capability.

    Args:
        codium_metadata_service_url (str): The URL for the metadata service.
        repo_url (str): The repository URL.
        capability (str): The capability identifier.
        commit_hash (str): The current commit hash.
        intuit_tid (str): The transaction ID for tracking.
        log_level (str): The log level for logging messages.

    Returns:
        str: The tag ID extracted from the metadata.

    Raises:
        Exception: If the tag ID is not found in the metadata.
    """
    # Publish current commit hash to the metadata catalog
    create_metadata_record(repo_url, capability, commit_hash, intuit_tid)

    # Refresh Metadata Tags
    refresh_metadata_tags("cli", codium_metadata_service_url, intuit_tid)

    # Get Metadata Record
    metadata = get_metadata_record(capability, intuit_tid)

    # Extract and return the tag_id
    tag_id = metadata.get("envs", {}).get("cli", {}).get("tag_id")
    if tag_id is None:
        raise Exception(
            f"[{log_level}]Tag ID not found in metadata for capability {capability}."
        )

    return tag_id


def trigger_rag_reindexing(env, codium_rag_indexer_url, intuit_tid, log_level="main"):
    """
    Triggers the RAG re-indexing process for a given environment.

    Args:
        env (str): The environment for which re-indexing is to be triggered.
        codium_rag_indexer_url (str): The URL for the RAG indexer.
        intuit_tid (str): The transaction ID for tracking.
        log_level (str): The log level for logging messages.

    Returns:
        str: The job ID of the triggered re-indexing job.

    Raises:
        Exception: If an error occurs while triggering the re-indexing job.
    """
    try:
        # Log the start of the process
        print(
            f"[{log_level}] Starting the re-indexing process for environment: {env} , TID: {intuit_tid}"
        )

        # Use Lambda endpoint for authenticated API call (secrets handled server-side)
        re_indexing_url = f"{LAMBDA_ENDPOINT}/v1/job/re-index"
        request_body = {"env": env, "ragIndexerUrl": codium_rag_indexer_url}
        headers = {
            "Content-Type": "application/json",
            "intuit_tid": intuit_tid,
            "x-target-service": "rag-ingestion-svc",
        }

        # Send a POST request to trigger re-indexing
        response = requests.post(
            re_indexing_url, headers=headers, data=json.dumps(request_body)
        )

        if response.status_code == 200:
            # Successfully triggered re-indexing job
            job = response.json()
            print(
                f"[{log_level}] Successfully triggered a job with id: {job['id']} for re-indexing for the env {env}, TID: {intuit_tid}"
            )
            return job["id"]
        else:
            # Failed to trigger re-indexing
            print(
                f"[{log_level}] Failed to trigger re-indexing for env {env} with response status: {response.status_code}, TID: {intuit_tid}"
            )
            print(f"[{log_level}] Got response: {response.text}, TID: {intuit_tid}")
            raise Exception(
                f"An error occurred while triggering re-indexing job for env {env}, TID: {intuit_tid}."
            )
    except RequestException as ex:
        # Handle any exceptions that occur during the process
        print(
            f"[{log_level}] Error occurred while triggering re-indexing: {str(ex)}, TID: {intuit_tid}"
        )
        raise Exception(
            f"An error occurred while triggering re-indexing job, TID: {intuit_tid}."
        ) from ex


def fetch_rag_reindexing_job_status(
    job_id,
    intuit_tid,
    interval_seconds=15,
    timeout_hours=24,
    log_level="main",
):
    """
    Fetches the status of a RAG re-indexing job until it completes or times out.

    Args:
        job_id (str): The job ID of the re-indexing job.
        intuit_tid (str): The transaction ID for tracking.
        interval_seconds (int): The interval in seconds between status checks.
        timeout_hours (int): The maximum time in hours to wait for job completion.
        log_level (str): The log level for logging messages.

    Raises:
        Exception: If the job fails or does not complete within the timeout period.
    """
    start_time = time.time()
    timeout_seconds = timeout_hours * 60 * 60
    indexing_completed = False

    try:
        while time.time() - start_time < timeout_seconds:
            # Construct the URL to fetch job status
            rag_indexer_get_job_by_id_url = f"{LAMBDA_ENDPOINT}/v1/job/{job_id}"
            headers = {
                "intuit_tid": intuit_tid,
                "x-target-service": "rag-ingestion-svc",
            }

            # Send a GET request to fetch job status
            response = requests.get(rag_indexer_get_job_by_id_url, headers=headers)

            if response.status_code != 200:
                print(
                    f"[{log_level}] Received non-200 response from RAG Ingestion service: {response.status_code} with tid: {intuit_tid}"
                )
                raise Exception(
                    f"Received non-200 response from RAG Ingestion service: {response.status_code}"
                )

            job = response.json()
            status = job.get("status")

            if status == "ERROR":
                print(
                    f"[{log_level}] Re-indexing job failed with status: ERROR with tid: {intuit_tid}"
                )
                raise Exception(
                    f"Re-indexing job failed with status: ERROR with tid: {intuit_tid}"
                )
            elif status == "COMPLETED":
                print(
                    f"[{log_level}] Re-indexing job completed successfully with tid: {intuit_tid}"
                )
                indexing_completed = True
                break
            else:
                print(
                    f"[{log_level}] Waiting for completion of Re-indexing job with tid: {intuit_tid}"
                )

            # Wait for the specified interval before checking again
            time.sleep(interval_seconds)

        if indexing_completed:
            print(
                f"[{log_level}] Successfully completed re-indexing for the golden repository with tid: {intuit_tid}."
            )
        else:
            print(
                f"[{log_level}] Re-indexing job did not complete within {timeout_hours} hours with tid: {intuit_tid}"
            )
            raise Exception(
                f"Re-indexing job did not complete within {timeout_hours} hours with tid: {intuit_tid}"
            )

    except RequestException as e:
        print(
            f"[{log_level}] An unexpected error occurred: {str(e)} with tid: {intuit_tid}"
        )
        raise Exception(
            f"An unexpected error occurred during the re-indexing job with tid: {intuit_tid}"
        ) from e
