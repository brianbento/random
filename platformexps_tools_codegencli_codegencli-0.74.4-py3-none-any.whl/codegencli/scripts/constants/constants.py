APP_INSTALLATION_ID = "5699"
GITHUB_ORG_NAME = "GoldenRepoOrg-cli"
GITHUB_API_BASE_URL = "https://github.intuit.com/api/v3"
RAG_INGESTION_SVC_BASE_URL = "https://rag-ingestion-svc.api.intuit.com"
METADATA_CATALOG_SVC_BASE_URL = "https://metadata-catalog.api.intuit.com"
CODIUM_RAG_INDEXER_URL = (
    "https://codiumaicodiumate-qal.api.intuit.com/cli-rag/api/v1/reindex"
)
CODIUM_METADATA_SVC_URL = "https://codiumaicodiumate-qal.api.intuit.com/cli-metadata/api/v1/tags/advanced_search"
ENV = "cli"
