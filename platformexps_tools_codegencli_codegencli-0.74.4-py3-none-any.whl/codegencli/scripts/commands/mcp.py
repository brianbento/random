# mypy: ignore-errors
"""
MCP Command Module for managing MCP (Model Context Protocol) services
"""

# Import the main MCP command from the modular structure
from .mcp.main import mcp

# Export the mcp command for use by cli.py
__all__ = ["mcp"]
