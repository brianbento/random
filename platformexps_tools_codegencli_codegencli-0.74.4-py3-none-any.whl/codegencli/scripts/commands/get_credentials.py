import json
import os
import pathlib
import time

import click

from codegencli.scripts.services.credentials_service import request_credentials


def get_credentials_dir():
    """
    Get the directory for storing credentials.

    Returns:
        pathlib.Path: Path to the credentials directory.
    """
    home_dir = pathlib.Path.home()
    creds_dir = home_dir / ".codegencli"
    creds_dir.mkdir(exist_ok=True)
    return creds_dir


def store_credentials(credentials):
    """
    Store credentials locally for future use.

    Args:
        credentials (dict): Credentials to store.

    Returns:
        pathlib.Path: Path to the stored credentials file.
    """
    creds_dir = get_credentials_dir()
    creds_file = creds_dir / "credentials.json"

    with open(creds_file, "w") as f:
        json.dump(credentials, f)

    # Set file permissions to be readable only by the owner
    os.chmod(creds_file, 0o600)

    return creds_file


def load_credentials():
    """
    Load stored credentials.

    Returns:
        dict: Loaded credentials or None if no credentials are found.
    """
    creds_dir = get_credentials_dir()
    creds_file = creds_dir / "credentials.json"

    if not creds_file.exists():
        return None

    with open(creds_file, "r") as f:
        return json.load(f)


def get_and_store_credentials(force=False):
    """
    Request credentials and store them locally.

    Args:
        force (bool): Whether to force requesting new credentials even if they already exist.

    Returns:
        dict: The credentials.
    """
    if not force:
        existing_credentials = load_credentials()
        if existing_credentials:
            # Check if credentials are more than 2 hours old
            current_time = time.time()
            credentials_age = current_time - existing_credentials.get("retrievedAt", 0)

            if credentials_age < 7200:  # 2 hours in seconds
                click.echo("Using existing credentials from local storage.")
                return existing_credentials
            else:
                click.echo(
                    "Existing credentials are more than 2 hours old. Requesting new ones..."
                )
                force = True

    click.echo("Requesting new credentials...")
    credentials = request_credentials()

    if credentials:
        creds_file = store_credentials(credentials)
        click.echo(f"Credentials stored at: {creds_file}")
        return credentials
    else:
        click.echo("Failed to get credentials.")
        return None
