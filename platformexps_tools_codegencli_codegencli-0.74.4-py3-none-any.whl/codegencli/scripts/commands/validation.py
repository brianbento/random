import concurrent.futures
import getpass
import os
import threading
import uuid

from codegencli.scripts.constants.constants import (
    CODIUM_METADATA_SVC_URL,
    CODIUM_RAG_INDEXER_URL,
    ENV,
)
from codegencli.scripts.services.ai import get_processed_response
from codegencli.scripts.services.file import (
    read_key_from_toml,
    read_yaml_file,
    save_response_to_file,
    save_yaml_file,
)
from codegencli.scripts.services.git import prepare_repo
from codegencli.scripts.services.http import find_available_port, start_server
from codegencli.scripts.services.rag_index import refresh_metadata, reindex
from codegencli.scripts.services.validation import (
    download_and_extract_report,
    run_remote_validation_test,
    upload_validation_data_to_s3,
    wait_for_validation_report,
)
from codegencli.scripts.utils.structural_validation import structural_validation

# DataUtils removed - secrets now managed by Lambda


def get_tmp_capability(directory):
    """
    Generates a temporary capability identifier based on the user's username and the capability ID from the TOML file.

    Args:
        directory (str): The directory path where the .ai_config.toml file is located.

    Returns:
        str: A string combining the capability ID and the user's username.
    """
    # Construct the path to the TOML file
    toml_file_path = os.path.join(directory, ".ai_config.toml")
    # Read the capability ID from the TOML file
    capability_id = read_key_from_toml(toml_file_path, ["tags", "capability_id"])
    # Get the current user's username
    username = getpass.getuser()
    # Replace spaces in the username with hyphens
    username_suffix = username.replace(" ", "-")
    # Return the combined capability ID and username
    return f"{capability_id}_{username_suffix}"


def run_missing_validation_tests(test_case, tag, log_level="main"):
    """
    Processes a test case by generating a response if none exists and updating the test case with the response.

    Args:
        test_case (dict): The test case data containing the prompt and responses.
        test_case_id (int): The unique identifier for the test case.
        tag (str): A tag to include in the request payload.
        log_level (str): The log level for logging messages.
    """
    # Extract the prompt and responses from the test case
    prompt = test_case.get("prompt")
    responses = test_case.get("responses")

    # Skip processing if responses already exist
    if responses:
        print(
            f"[{log_level}] Skipping test case with prompt as responses already present: {prompt}"
        )
        return

    # Skip processing if the prompt is empty
    if not prompt:
        print(f"[{log_level}] Skipping test case with empty prompt.")
        return

    # Process the test case and generate a response
    print(f"[{log_level}] Processing test case with prompt: {prompt}")
    response_content = get_processed_response(prompt, log_level, tag)
    file_path = save_response_to_file(prompt, response_content, log_level)
    update_yaml_with_response(test_case, file_path, log_level)
    print(f"[{log_level}] Test case processed and response saved to: {file_path}")


def update_yaml_with_response(test_case, file_path, log_level="main"):
    """
    Updates the test case with the file path of the generated response.

    Args:
        test_case (dict): The test case data to update.
        file_path (str): The file path of the generated response.
        test_case_id (int): The unique identifier for the test case.
        log_level (str): The log level for logging messages.
    """
    print(f"[{log_level}] Updating YAML with response file path: {file_path}")
    # Ensure the 'responses' key exists and is a list
    if "responses" not in test_case or not isinstance(test_case["responses"], list):
        test_case["responses"] = []
    # Append the file path to the responses
    test_case["responses"].append(file_path)


def concurrent_test_case_handler(test_suite, process_function, tag):
    """
    Handles the concurrent processing of test cases using a thread pool.

    Args:
        test_suite (dict): The test suite containing test cases.
        process_function (function): The function to process each test case.
        tag (str): A tag to include in the request payload.
        log_level (str): The log level for logging messages.
    """
    # Use a thread pool to process test cases concurrently
    with concurrent.futures.ThreadPoolExecutor(max_workers=15) as executor:
        futures = [
            executor.submit(process_function, test_case, tag, idx + 1)
            for idx, test_case in enumerate(test_suite.get("testCases", []))
        ]
        # Wait for all futures to complete
        concurrent.futures.wait(futures)


def validate_test(test_case, tag, log_level="main"):
    """
    Validates a test case by refreshing the response if it exists or skipping if it doesn't.

    Args:
        test_case (dict): The test case data containing the prompt and responses.
        tag (str): A tag to include in the request payload.
        log_level (str): The log level for logging messages.
    """
    # Extract the prompt and responses from the test case
    prompt = test_case.get("prompt")
    responses = test_case.get("responses")

    # Skip processing if the prompt is empty
    if not prompt:
        print(f"[{log_level}] Skipping test case with empty prompt.")
        return

    # Check if there is exactly one response file
    if responses and isinstance(responses, list) and len(responses) == 1:
        # Construct the path to the response file
        response_file_path = os.path.join(
            os.getcwd(), "validations", responses[0].split("/")[-1]
        )

        # Refresh the response if the file exists
        if os.path.exists(response_file_path):
            print(
                f"[{log_level}] Refreshing response in file: {response_file_path} for prompt: {prompt}"
            )
            response_content = get_processed_response(prompt, log_level, tag)
            with open(response_file_path, "w") as response_file:
                response_file.write(response_content)
            print(f"[{log_level}] Response file updated: {response_file_path}")
        else:
            print(
                f"[{log_level}] Skipping refresh. File does not exist: {response_file_path}"
            )
    else:
        print(f"[{log_level}] Skipping test case with no existing responses.")


def add_missing_validations(working_dir=os.getcwd(), log_level="main"):
    """
    Adds missing validations by processing test cases that lack responses.

    Args:
        working_dir (str): The working directory containing the test suite.
        log_level (str): The log level for logging messages.
    """
    print(f"[{log_level}] Working Directory: {working_dir}")
    # Generate a unique transaction ID
    intuit_tid = str(uuid.uuid4())
    print(f"[{log_level}] intuit_tid: {intuit_tid}")

    # Perform structural validation on the working directory
    structural_validation(working_dir)

    # Generate a temporary capability identifier
    tmp_capability = get_tmp_capability(working_dir)
    print(f"[{log_level}] capability: {tmp_capability}")

    # Prepare the repository and get the commit hash
    # Note: Requires SSH to be configured on the host system
    # Note: api_key is now obtained through Lambda - placeholder for backwards compatibility
    tmp_dir, remote_repo, commit_hash = prepare_repo(
        working_dir,
        tmp_capability,
        None,  # api_key obtained from Lambda (see services)
        log_level,
    )
    # Reindex and refresh metadata
    reindex(
        ENV,
        CODIUM_RAG_INDEXER_URL,
        intuit_tid,
        log_level,
    )
    tag = refresh_metadata(
        CODIUM_METADATA_SVC_URL,
        remote_repo,
        tmp_capability,
        commit_hash,
        intuit_tid,
        log_level,
    )

    # Read the test suite from the YAML file
    test_suite = read_yaml_file(
        os.path.join(working_dir, "validations", "test-suite.yaml"), log_level
    )
    # Process missing validation tests concurrently
    concurrent_test_case_handler(test_suite, run_missing_validation_tests, tag)
    # Save the updated test suite back to the YAML file
    save_yaml_file(
        os.path.join(working_dir, "validations", "test-suite.yaml"),
        test_suite,
        log_level,
    )


def refresh_existing_validations(working_dir=os.getcwd(), log_level="main"):
    """
    Refreshes existing validations by updating responses for test cases.

    Args:
        working_dir (str): The working directory containing the test suite.
        log_level (str): The log level for logging messages.
    """
    print(f"[{log_level}] Working Directory: {working_dir}")
    # Generate a unique transaction ID
    intuit_tid = str(uuid.uuid4())
    print(f"[{log_level}] intuit_tid: {intuit_tid}")

    # Perform structural validation on the working directory
    structural_validation(working_dir)

    # Generate a temporary capability identifier
    tmp_capability = get_tmp_capability(working_dir)
    print(f"[{log_level}] capability: {tmp_capability}")

    # Prepare the repository and get the commit hash
    # Note: Requires SSH to be configured on the host system
    # Note: api_key is now obtained through Lambda - placeholder for backwards compatibility
    tmp_dir, remote_repo, commit_hash = prepare_repo(
        working_dir,
        tmp_capability,
        None,  # api_key obtained from Lambda
        log_level,
    )

    # Reindex and refresh metadata
    reindex(
        ENV,
        CODIUM_RAG_INDEXER_URL,
        intuit_tid,
        log_level,
    )
    tag = refresh_metadata(
        CODIUM_METADATA_SVC_URL,
        remote_repo,
        tmp_capability,
        commit_hash,
        intuit_tid,
        log_level,
    )

    # Read the test suite from the YAML file
    test_suite = read_yaml_file(
        os.path.join(working_dir, "validations", "test-suite.yaml"), log_level
    )

    # Process existing validation tests concurrently
    concurrent_test_case_handler(test_suite, validate_test, tag)

    # Save the updated test suite back to the YAML file
    save_yaml_file(
        os.path.join(working_dir, "validations", "test-suite.yaml"),
        test_suite,
        log_level,
    )


def run_validation_tests(working_dir=os.getcwd(), log_level="main"):
    """
    Runs the validation tests by preparing the environment, uploading data, and executing remote tests.

    Args:
        working_dir (str): The working directory containing the test suite.
        log_level (str): The log level for logging messages.
    """
    print(f"[{log_level}] Working Directory: {working_dir}")
    # Generate a unique transaction ID
    intuit_tid = str(uuid.uuid4())
    print(f"[{log_level}] intuit_tid: {intuit_tid}")

    # Perform structural validation on the working directory
    structural_validation(working_dir)

    # Generate a temporary capability identifier
    tmp_capability = get_tmp_capability(working_dir)
    print(f"[{log_level}] capability: {tmp_capability}")

    # Prepare the repository and get the commit hash
    # Note: Requires SSH to be configured on the host system
    # Note: api_key is now obtained through Lambda - placeholder for backwards compatibility
    tmp_dir, remote_repo, commit_hash = prepare_repo(
        working_dir,
        tmp_capability,
        None,  # api_key obtained from Lambda
        log_level,
    )
    # Reindex the environment
    reindex(
        ENV,
        CODIUM_RAG_INDEXER_URL,
        intuit_tid,
        log_level,
    )

    refresh_metadata(
        CODIUM_METADATA_SVC_URL,
        remote_repo,
        tmp_capability,
        commit_hash,
        intuit_tid,
        log_level,
    )

    # Upload validation data to S3
    upload_validation_data_to_s3(
        tmp_capability,
        None,  # api_key obtained from Lambda
        log_level,
    )

    # Run the remote validation test
    run_remote_validation_test(
        intuit_tid,
        tmp_capability,
        commit_hash,
        None,  # api_key obtained from Lambda
        log_level,
    )

    # Wait for the validation report to be ready
    wait_for_validation_report(
        intuit_tid,
        None,  # api_key obtained from Lambda
        log_level,
    )

    # Download and extract the validation report
    download_and_extract_report(
        working_dir,
        intuit_tid,
        None,  # api_key obtained from Lambda
    )

    def start_server_thread(port):
        # Start the HTTP server to serve the logs directory
        start_server(os.path.join(working_dir, "logs"), port)

    # Find an available port starting from 8000
    port = find_available_port(8000)

    # Start the server in a separate thread
    server_thread = threading.Thread(target=start_server_thread, args=(port,))
    server_thread.start()

    print(
        f"[{log_level}] To access test report, go to http://127.0.0.1:{port}/test_report"
    )
    print(
        f"[{log_level}] To access coverage report, go to http://127.0.0.1:{port}/coverage_report"
    )

    # Wait for the server thread to complete
    server_thread.join()
