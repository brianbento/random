# mypy: ignore-errors
"""
Utility functions for MCP operations
"""

import getpass
import hashlib
import importlib.metadata
import json
import os
import re
import subprocess
import typing
from typing import Any, Dict, Optional, Tuple

import inquirer
import requests
from inquirer import Text
from rich import print as rprint

from .constants import (
    ENV_ARGS,
    ENV_ENV_VARS,
    ENV_TOKEN,
    ENV_VERSION_TYPE,
    ERROR_ICON,
    INFO_ICON,
    MARKETPLACE_API_KEY,
    MCP_API_BASE_URL,
    MCP_API_V2_BASE_URL,
    SUCCESS_ICON,
    WARNING_ICON,
)


def get_cli_version() -> str:
    """Get the current CLI version"""
    try:
        return importlib.metadata.version("platformexps-tools.codegencli.codegencli")
    except importlib.metadata.PackageNotFoundError:
        return "unknown"


def get_headers():
    """Get the authorization headers for API calls"""
    from ...services.eiam_auth import EIAMAuthService
    from .logging_helper import get_mcp_logger

    username = getpass.getuser()

    # Get the current execution ID for tracing
    logger = get_mcp_logger()
    execution_id = logger.execution_id

    # Get IAM ticket for authentication
    auth_service = EIAMAuthService()
    credentials = auth_service.get_auth_credentials()

    if not credentials:
        raise RuntimeError("Failed to obtain authentication credentials")

    user_id = credentials["userId"]
    iam_ticket = credentials["ticket"]

    return {
        "Authorization": f"Intuit_APIKey intuit_apikey={MARKETPLACE_API_KEY}, intuit_userid={user_id}, intuit_token={iam_ticket}, intuit_token_type=IAM-Ticket; intuit_apikey_version=1.0",
        "x-corp-id": username,
        "X-Forwarded-Port": "8090",
        "x-cli-version": get_cli_version(),
        "intuit_tid": execution_id,  # Add execution ID as intuit_tid for tracing
    }


def get_env_var_or_prompt(
    env_var_name: str, prompt_message: str, default: str = "", headless: bool = False
) -> Optional[str]:
    """Get value from environment variable or prompt user if not in headless mode

    Args:
        env_var_name: Name of the environment variable to check
        prompt_message: Message to show when prompting user
        default: Default value for the prompt
        headless: If True, only check environment variables, don't prompt

    Returns:
        The value from environment variable or user input, or None if cancelled
    """
    # Check environment variable first
    env_value = os.environ.get(env_var_name)
    if env_value:
        rprint(
            f"{INFO_ICON} Using environment variable {env_var_name}: [bold cyan]{env_value}[/]"
        )
        return env_value

    # If headless mode and no environment variable, fail
    if headless:
        rprint(
            f"{ERROR_ICON} [bold red]Environment variable {env_var_name} is required for headless mode[/]"
        )
        return None

    # Prompt user for input
    question = [Text("value", message=prompt_message, default=default)]
    answer = inquirer.prompt(question)
    if not answer:
        rprint(f"\n{WARNING_ICON} [yellow]Operation cancelled by user[/]")
        return None

    return answer["value"]


def get_env_vars_from_json(
    env_json: str, manifest_env: list, headless: bool = False
) -> Dict[str, str]:
    """Parse environment variables from JSON string or prompt user

    Args:
        env_json: JSON string containing environment variables
        manifest_env: List of environment variable definitions from manifest
        headless: If True, only use environment variables, don't prompt

    Returns:
        Dictionary of environment variable names and values
    """
    env_vars = {}

    # Try to parse JSON from environment variable
    if env_json:
        try:
            env_vars = json.loads(env_json)
            rprint(f"{INFO_ICON} Using environment variables from {ENV_ENV_VARS}")
            return env_vars
        except json.JSONDecodeError as e:
            rprint(f"{WARNING_ICON} [yellow]Invalid JSON in {ENV_ENV_VARS}: {e}[/]")
            if headless:
                rprint(
                    f"{ERROR_ICON} [bold red]Environment variable {ENV_ENV_VARS} contains invalid JSON[/]"
                )
                return {}

    # If headless mode and no valid environment variables, fail
    if headless and manifest_env:
        rprint(
            f"{ERROR_ICON} [bold red]Environment variable {ENV_ENV_VARS} is required for headless mode[/]"
        )
        return {}

    return env_vars


def get_args_from_json(
    args_json: str, manifest_args: list, headless: bool = False
) -> typing.List[str]:
    """Parse arguments from JSON string or prompt user

    Args:
        args_json: JSON string containing arguments
        manifest_args: List of argument definitions from manifest
        headless: If True, only use environment variables, don't prompt

    Returns:
        List of argument strings in format --name=value
    """
    args = []

    # Try to parse JSON from environment variable
    if args_json:
        try:
            args_dict = json.loads(args_json)
            rprint(f"{INFO_ICON} Using arguments from {ENV_ARGS}")
            # Convert dictionary to list of --name=value strings
            for name, value in args_dict.items():
                args.append(f"--{name}={value}")
            return args
        except json.JSONDecodeError as e:
            rprint(f"{WARNING_ICON} [yellow]Invalid JSON in {ENV_ARGS}: {e}[/]")
            if headless:
                rprint(
                    f"{ERROR_ICON} [bold red]Environment variable {ENV_ARGS} contains invalid JSON[/]"
                )
                return []

    # If headless mode and no valid arguments, fail
    if headless and manifest_args:
        rprint(
            f"{ERROR_ICON} [bold red]Environment variable {ENV_ARGS} is required for headless mode[/]"
        )
        return []

    return args


def get_version_type_from_env(headless: bool = False) -> Optional[str]:
    """Get version type from environment variable or prompt user

    Args:
        headless: If True, only check environment variables, don't prompt

    Returns:
        Version type ('major', 'minor', 'patch') or None if cancelled
    """
    env_value = os.environ.get(ENV_VERSION_TYPE)
    if env_value:
        if env_value.lower() in ["major", "minor", "patch"]:
            rprint(
                f"{INFO_ICON} Using version type from environment: [bold cyan]{env_value}[/]"
            )
            return env_value.lower()
        else:
            rprint(
                f"{WARNING_ICON} [yellow]Invalid version type in {ENV_VERSION_TYPE}: {env_value}[/]"
            )
            if headless:
                rprint(
                    f"{ERROR_ICON} [bold red]Environment variable {ENV_VERSION_TYPE} must be 'major', 'minor', or 'patch'[/]"
                )
                return None

    # If headless mode and no environment variable, fail
    if headless:
        rprint(
            f"{ERROR_ICON} [bold red]Environment variable {ENV_VERSION_TYPE} is required for headless mode[/]"
        )
        return None

    return None  # Will prompt user in the calling function


def validate_headless_requirements(
    manifest: Dict[str, Any], headless: bool = False
) -> bool:
    """Validate that all required environment variables are present for headless mode

    Args:
        manifest: The manifest dictionary
        headless: If True, validate headless requirements

    Returns:
        True if all requirements are met, False otherwise
    """
    if not headless:
        return True

    missing_vars = []

    # Check if MCP exists and token is required
    name = manifest.get("name", "")
    if name and check_mcp_exists(name):
        if not os.environ.get(ENV_TOKEN):
            missing_vars.append(ENV_TOKEN)

    # Check if environment variables are required
    if manifest.get("env") and not os.environ.get(ENV_ENV_VARS):
        missing_vars.append(ENV_ENV_VARS)

    # Check if arguments are required
    if manifest.get("args") and not os.environ.get(ENV_ARGS):
        missing_vars.append(ENV_ARGS)

    if missing_vars:
        rprint(
            f"{ERROR_ICON} [bold red]Missing required environment variables for headless mode:[/]"
        )
        for var in missing_vars:
            rprint(f"  [red]•[/] {var}")
        rprint(
            f"\n{INFO_ICON} Set these environment variables or run without --headless flag"
        )
        return False

    return True


def check_mcp_exists(name: str) -> Optional[Dict[str, Any]]:
    """Check if an MCP with the given name already exists"""
    from .logging_helper import get_mcp_logger

    logger = get_mcp_logger()

    try:
        logger.debug(f"Checking if MCP exists: {name}")
        headers = get_headers()
        response = logger.make_api_call("GET", MCP_API_BASE_URL, headers=headers)

        if response.status_code == 200:
            mcps = response.json().get("items", [])
            for mcp in mcps:
                if mcp.get("name") == name:
                    logger.info(f"Found existing MCP: {name}")
                    return mcp
            logger.info(f"MCP not found: {name}")
        else:
            logger.warning(f"API call failed with status {response.status_code}")
    except Exception as e:
        logger.exception(f"Error checking if MCP exists: {str(e)}")
        rprint(f"Error checking if MCP exists: {str(e)}")
    return None


def validate_name(name: str) -> bool:
    """Validate MCP name - lowercase alphanumeric with hyphens, no spaces or special characters"""
    # Check if name is lowercase
    if name != name.lower():
        rprint(
            f"{ERROR_ICON} [bold red]Invalid name.[/] MCP name must be all lowercase."
        )
        return False

    # Check if name already exists
    if check_mcp_exists(name):
        rprint(f"{ERROR_ICON} [bold red]MCP with name '{name}' already exists.[/]")
        return False

    return True


def verify_token(mcp_id: str, token: str) -> bool:
    """Verify the token for an MCP service"""
    try:
        response = requests.post(
            f"{MCP_API_BASE_URL}/{mcp_id}/validate/{token}", headers=get_headers()
        )
        if response.status_code == 200:
            result = response.json()
            return result.get("valid", False)
        return False
    except Exception as e:
        rprint(f"Error verifying token: {str(e)}")
        return False


def get_mcp_by_name(name: str) -> Optional[Dict[str, Any]]:
    """Get MCP by name"""
    mcp = check_mcp_exists(name)
    if mcp:
        try:
            mcp_id = mcp.get("id")
            response = requests.get(
                f"{MCP_API_BASE_URL}/{mcp_id}", headers=get_headers()
            )
            if response.status_code == 200:
                return response.json()
        except Exception as e:
            rprint(f"Error getting MCP details: {str(e)}")
    return None


def get_latest_version(
    mcp_id: str, published_only: bool = True
) -> Optional[Dict[str, Any]]:
    """Get the latest version of an MCP

    Args:
        mcp_id: The ID of the MCP
        published_only: If True, only consider PUBLISHED versions; otherwise consider all versions
    """
    try:
        response = requests.get(
            f"{MCP_API_BASE_URL}/{mcp_id}/versions", headers=get_headers()
        )
        if response.status_code == 200:
            versions = response.json().get("items", [])
            if versions:
                # Sort versions by semantic versioning
                def parse_version(version_str):
                    try:
                        return [int(x) for x in version_str.split(".")]
                    except (ValueError, AttributeError):
                        return [0, 0, 0]  # Default for invalid versions

                # Filter versions by state if needed
                if published_only:
                    filtered_versions = [
                        v for v in versions if v.get("state") == "PUBLISHED"
                    ]
                else:
                    filtered_versions = versions

                if filtered_versions:
                    # Sort by semantic version (major, minor, patch) in descending order
                    sorted_versions = sorted(
                        filtered_versions,
                        key=lambda v: parse_version(v.get("version", "0.0.0")),
                        reverse=True,
                    )
                    return sorted_versions[0]

                # If no filtered versions exist, return None instead of falling back
                return None
    except Exception as e:
        rprint(f"Error getting versions: {str(e)}")
    return None


def get_venv_path(marketplace_base_dir: str, python_path: str, mcp_name: str) -> str:
    """
    Generate a venv path based on Python runtime and MCP name

    Args:
        marketplace_base_dir: Base directory for MCP installations
        python_path: Path to the Python executable
        mcp_name: Name of the MCP

    Returns:
        Path to the virtual environment
    """
    # Create a hash of the python path to ensure uniqueness
    python_hash = hashlib.md5(python_path.encode()).hexdigest()[:8]
    venv_name = f"venv_{mcp_name}_{python_hash}"
    venv_path = os.path.join(marketplace_base_dir, ".venvs", venv_name)
    return venv_path


def display_manual_installation_configs(
    mcp_name: str,
    proxy_command: str,
    proxy_args: typing.List[str],
    proxy_env_vars: Dict[str, str],
):
    """Display manual installation configurations for different IDEs

    Args:
        mcp_name: Name of the MCP
        proxy_command: Command to run the MCP proxy
        proxy_args: Arguments for the proxy command
        proxy_env_vars: Environment variables for the proxy command
    """
    rprint(f"\n{INFO_ICON} [bold cyan]Manual Installation Configurations[/]")
    rprint(
        "If your IDE or CLI is not in the above list you can manually install by using the following details e.g. 'mcpServers' section in MCP configuration file:"
    )

    # Standard MCP JSON format
    standard_config = {
        mcp_name: {"command": proxy_command, "args": proxy_args, "env": proxy_env_vars}
    }

    rprint(f"[green]{json.dumps(standard_config, indent=2)}[/]")


def check_mcp_exists_v2(name: str) -> Optional[Dict[str, Any]]:
    """Check if an MCP with the given name exists in v2 API"""
    from .logging_helper import get_mcp_logger

    logger = get_mcp_logger()

    try:
        logger.debug(f"Checking if MCP exists in v2: {name}")
        headers = get_headers()
        response = logger.make_api_call("GET", MCP_API_V2_BASE_URL, headers=headers)

        if response.status_code == 200:
            response_data = response.json()
            # v2 API returns a list directly, not wrapped in "items"
            mcps = (
                response_data
                if isinstance(response_data, list)
                else response_data.get("items", [])
            )
            for mcp in mcps:
                if mcp.get("name") == name:
                    logger.info(f"Found existing MCP in v2: {name}")
                    return mcp
            logger.info(f"MCP not found in v2: {name}")
        else:
            logger.warning(f"V2 API call failed with status {response.status_code}")
    except Exception as e:
        logger.debug(f"V2 API not available: {str(e)}")
        # Don't print error to user - v2 API might not be available yet
    return None


def get_mcp_by_name_v2(name: str) -> Optional[Dict[str, Any]]:
    """Get MCP by name from v2 API"""
    mcp = check_mcp_exists_v2(name)
    if mcp:
        try:
            mcp_id = mcp.get("id")
            response = requests.get(
                f"{MCP_API_V2_BASE_URL}/{mcp_id}", headers=get_headers()
            )
            if response.status_code == 200:
                return response.json()
        except Exception:
            # Silently fail if v2 API is not available
            pass
    return None


def get_mcp_versions_v2(mcp_id: str) -> Optional[Dict[str, Any]]:
    """Get version details for a v2 MCP"""
    try:
        response = requests.get(
            f"{MCP_API_V2_BASE_URL}/{mcp_id}", headers=get_headers()
        )
        if response.status_code == 200:
            return response.json()
    except Exception:
        # Silently fail if v2 API is not available
        pass
    return None


def find_mcp_in_both_versions(
    name: str,
) -> Tuple[Optional[Dict[str, Any]], Optional[Dict[str, Any]]]:
    """Find MCP in both v1 and v2 APIs

    Returns:
        Tuple of (v1_mcp, v2_mcp) where each can be None if not found
    """
    v1_mcp = get_mcp_by_name(name)
    v2_mcp = get_mcp_by_name_v2(name)
    return v1_mcp, v2_mcp


def generate_nano_id(size: int = 8) -> str:
    """Generate a random nano ID for container naming"""
    import random
    import string

    return "".join(random.choices(string.ascii_lowercase + string.digits, k=size))


def detect_container_runtime() -> Optional[str]:
    """
    Detect available container runtime (docker or podman)

    Returns:
        'docker', 'podman', or None if neither is available
    """
    for runtime in ["docker", "podman"]:
        try:
            result = subprocess.run(
                [runtime, "--version"], capture_output=True, text=True, timeout=10
            )
            if result.returncode == 0:
                return runtime
        except (FileNotFoundError, subprocess.TimeoutExpired):
            continue
    return None


def verify_container_runtime(
    silent: bool = False, prefer_runtime: Optional[str] = None
) -> Tuple[bool, Optional[str]]:
    """
    Verify if a container runtime (Docker or Podman) is available and running.

    Attempts to find and verify availability of container runtimes in this order:
    1. Preferred runtime (if specified)
    2. Docker
    3. Podman

    Args:
        silent: If True, don't print any messages
        prefer_runtime: Preferred runtime ('docker' or 'podman'). If not available, falls back to other runtimes

    Returns:
        Tuple of (success: bool, runtime: Optional[str])
        - (True, 'docker'/'podman') if a runtime is available
        - (False, None) if no runtime is available
    """
    runtimes_to_check = []

    # Add preferred runtime first if specified
    if prefer_runtime and prefer_runtime.lower() in ["docker", "podman"]:
        runtimes_to_check.append(prefer_runtime.lower())
        # Add other runtimes as fallback
        for runtime in ["docker", "podman"]:
            if runtime != prefer_runtime.lower():
                runtimes_to_check.append(runtime)
    else:
        # Default order: docker first, then podman
        runtimes_to_check = ["docker", "podman"]

    for runtime in runtimes_to_check:
        try:
            # Check if command exists
            result = subprocess.run(
                [runtime, "--version"], capture_output=True, text=True, timeout=10
            )
            if result.returncode != 0:
                continue

            # Check if daemon/service is running
            result = subprocess.run(
                [runtime, "info"], capture_output=True, text=True, timeout=10
            )
            if result.returncode != 0:
                if not silent:
                    rprint(
                        f"{ERROR_ICON} [bold red]{runtime.capitalize()} is installed but not running[/]"
                    )
                continue

            if not silent:
                rprint(
                    f"{SUCCESS_ICON} {runtime.capitalize()} runtime is available and running"
                )
            return (True, runtime)

        except subprocess.TimeoutExpired:
            if not silent:
                rprint(
                    f"{ERROR_ICON} [bold red]{runtime.capitalize()} command timed out[/]"
                )
            continue
        except FileNotFoundError:
            continue
        except Exception as e:
            if not silent:
                rprint(f"{ERROR_ICON} [bold red]Error checking {runtime}: {str(e)}[/]")
            continue

    # No runtime found
    if not silent:
        rprint(
            f"{ERROR_ICON} [bold red]No container runtime found (Docker or Podman required)[/]"
        )
    return (False, None)


def verify_docker_runtime(silent: bool = False) -> bool:
    """
    Deprecated: Use verify_container_runtime instead.

    Verify if Docker runtime is available and running.
    Kept for backward compatibility, but now checks for either docker or podman.

    Args:
        silent: If True, don't print any messages (for proxy operations)

    Returns:
        True if a container runtime is available, False otherwise
    """
    success, _ = verify_container_runtime(silent=silent, prefer_runtime="docker")
    return success
