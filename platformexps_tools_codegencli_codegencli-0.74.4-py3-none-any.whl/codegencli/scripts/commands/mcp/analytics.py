# mypy: ignore-errors
"""
Analytics and API functions for MCP operations
"""

import getpass
import subprocess
import time
import uuid
from datetime import datetime
from typing import Optional

from rich import print as rprint

from .constants import (
    ANALYTICS_API_URL,
    EVENTBUS_API_KEY,
    EVENTBUS_MCP_DATA_USAGE_URL,
    WARNING_ICON,
)
from .utils import get_cli_version, get_headers


def send_analytics_event(
    event_type: str, mcp_id: str, mcp_version_id: Optional[str] = None
):
    """Send analytics event to the API

    Args:
        event_type: Type of the event (see EventType class)
        mcp_id: ID of the MCP
        mcp_version_id: Optional ID of the MCP version
    """
    try:
        username = getpass.getuser()

        # Prepare the event data
        event_data = {
            "event_type": event_type,
            "mcp_id": mcp_id,
            "user_id": username,
            "timestamp": int(time.time() * 1000),  # Current time in milliseconds
            "additional_data": {},  # Always empty per requirements
        }

        # Add version ID if provided
        if mcp_version_id:
            event_data["mcp_version_id"] = mcp_version_id

        # Send the event
        from .logging_helper import get_mcp_logger

        logger = get_mcp_logger()
        response = logger.make_api_call(
            "POST", ANALYTICS_API_URL, headers=get_headers(), json_data=event_data
        )

        if response.status_code != 200:
            rprint(
                f"{WARNING_ICON} [yellow]Failed to log analytics event: {response.status_code}[/]"
            )
    except Exception as e:
        # Don't let analytics failure break the main functionality
        rprint(f"{WARNING_ICON} [yellow]Error logging analytics: {str(e)}[/]")


def send_mcp_install_analytics(mcp_name: str, version: str, success_count: int):
    """Send MCP installation analytics to the script.sh API endpoint

    Args:
        mcp_name: Name of the MCP that was installed
        version: Version of the MCP that was installed
        success_count: Number of IDEs successfully configured
    """
    try:
        # Get username using whoami command (same as script.sh)
        try:
            result = subprocess.run(
                ["whoami"], capture_output=True, text=True, check=True
            )
            username = result.stdout.strip()
        except (subprocess.CalledProcessError, FileNotFoundError):
            # Fallback to getpass.getuser() if whoami fails
            username = getpass.getuser()

        timestamp = datetime.utcnow().isoformat() + "Z"
        event_id = str(uuid.uuid4())

        # Prepare the event data matching the script.sh format
        event_data = {
            "assetId": mcp_name,
            "assetAlias": mcp_name,
            "mcpVersion": version,
            "ide": "cli",
            "ideVersion": "unknown",
            "userId": username,  # Use whoami command output as userId
            "id": event_id,
            "tool": "mcp_install",
            "origin": "terminal",
            "error": "no-error",
            "userParams": [
                {"key": "installation_type", "value": "mcp_install"},
                {"key": "success_count", "value": str(success_count)},
            ],
            "timestamp": timestamp,
            "message": f"MCP '{mcp_name}' version {version} successfully installed for {success_count} IDE(s)",
        }

        # Get the current execution ID for tracing
        from .logging_helper import get_mcp_logger

        logger = get_mcp_logger()
        execution_id = logger.execution_id

        # Eventbus endpoint uses simple API key authentication (no IAM ticket needed)
        headers = {
            "Authorization": f"Intuit_APIKey intuit_apikey={EVENTBUS_API_KEY}, intuit_apikey_version=1.0",
            "Content-Type": "application/json",
            "x-cli-version": get_cli_version(),
            "intuit_tid": execution_id,  # Add execution ID as intuit_tid for tracing
        }
        response = logger.make_api_call(
            "POST",
            EVENTBUS_MCP_DATA_USAGE_URL,
            headers=headers,
            json_data=event_data,
            timeout=5,  # Add timeout to prevent hanging
        )

        if response.status_code not in [200, 202]:
            rprint(
                f"{WARNING_ICON} [yellow]Failed to log MCP install analytics: {response.status_code}[/]"
            )
    except Exception as e:
        # Don't let analytics failure break the main functionality
        rprint(
            f"{WARNING_ICON} [yellow]Error logging MCP install analytics: {str(e)}[/]"
        )
