# mypy: ignore-errors
"""
Remote MCP proxy server that forwards MCP requests to remote services
"""

from __future__ import annotations

import asyncio
import csv
import json
import os
import socket
import subprocess
import sys
from typing import TYPE_CHECKING, Dict, Optional

from rich import print as rprint

from codegencli.scripts.services.eiam_auth import get_eiam_auth_service

from .constants import ERROR_ICON, INFO_ICON, REMOTE_MCP_API_KEY, SUCCESS_ICON
from .logging_helper import get_mcp_logger

try:
    import aiohttp
    from aiohttp import web

    HAS_AIOHTTP = True
except ImportError:
    HAS_AIOHTTP = False
    web = None

if TYPE_CHECKING:
    from aiohttp import web as web_type


class RemoteMCPProxy:
    """
    A proxy server that forwards MCP requests to remote services
    based on the path and CSV configuration.
    """

    def __init__(self, port: int = 8098):
        """
        Initialize the remote MCP proxy server.

        Args:
            port: Local port to listen on (default: 8098)
        """
        if not HAS_AIOHTTP:
            raise ImportError("aiohttp is required for remote MCP proxy functionality")

        self.port = port
        self.logger = get_mcp_logger()
        self.app = web.Application()
        self.mcp_services: Dict[str, str] = {}
        self._setup_routes()
        self._load_remote_csv()

    def _load_remote_csv(self):
        """Load MCP services from remote.csv file"""
        marketplace_dir = os.path.expanduser("~/.intuit-mcp-marketplace")
        csv_path = os.path.join(marketplace_dir, "remote.csv")

        if not os.path.exists(csv_path):
            self.logger.warning(f"Remote CSV file not found: {csv_path}")
            return

        try:
            with open(csv_path, "r", newline="") as csvfile:
                reader = csv.DictReader(csvfile)
                for row in reader:
                    mcp_name = row.get("mcp_name")
                    service_url = row.get("service_url")
                    if mcp_name and service_url:
                        # Use service_url as-is from CSV
                        self.mcp_services[mcp_name] = service_url

            self.logger.info(f"Loaded {len(self.mcp_services)} MCP services from CSV")

        except Exception as e:
            self.logger.error(f"Failed to load remote CSV: {str(e)}")

    def _setup_routes(self):
        """Setup proxy routes"""
        # Route for MCP services: /{mcp_name}/*
        self.app.router.add_route(
            "*", "/{mcp_name}/{path_info:.*}", self._proxy_handler
        )
        self.app.router.add_route("*", "/{mcp_name}", self._proxy_handler)

    def _get_auth_headers(self) -> Dict[str, str]:
        """Generate the required headers for remote MCP requests"""
        auth_service = get_eiam_auth_service()
        credentials = auth_service.get_auth_credentials()

        if not credentials:
            self.logger.error("Failed to obtain authentication credentials")
            rprint(
                f"{ERROR_ICON} [bold red]Authentication failed. Unable to obtain credentials.[/]"
            )
            sys.exit(1)

        return {
            "Authorization": f"Intuit_APIKey intuit_apikey={REMOTE_MCP_API_KEY}, intuit_apikey_version=1.0",
            "Cookie": f"qbn.authid={credentials['userId']}; qbn.parentid=50000000; qbn.ticket={credentials['ticket']}",
        }

    async def _proxy_handler(self, request: "web.Request") -> "web.StreamResponse":
        """
        Handle incoming requests and proxy them to the appropriate remote MCP service.

        Args:
            request: The incoming HTTP request

        Returns:
            The response from the remote MCP service
        """
        try:
            mcp_name = request.match_info.get("mcp_name")
            path_info = request.match_info.get("path_info", "")

            if not mcp_name:
                return web.json_response(
                    {"error": "MCP name is required in path"},
                    status=400,
                )

            # Check if MCP service exists in our registry
            if mcp_name not in self.mcp_services:
                return web.json_response(
                    {"error": f"MCP service '{mcp_name}' not found"},
                    status=404,
                )

            # Build the remote URL
            service_url = self.mcp_services[mcp_name]
            if path_info:
                # Add path with appropriate separator
                separator = "" if service_url.endswith("/") else "/"
                remote_url = f"{service_url}{separator}{path_info}"
            else:
                remote_url = service_url

            # Add query string if present
            if request.query_string:
                remote_url += f"?{request.query_string}"

            self.logger.info(
                f"Proxying MCP request - mcp={mcp_name}, method={request.method}, path={path_info}, remote_url={remote_url}"
            )

            # Prepare headers
            headers = dict(request.headers)
            # Remove host header to let aiohttp set it
            headers.pop("Host", None)
            # Add required authentication headers
            headers.update(self._get_auth_headers())

            # Read request body if present
            body = None
            if request.method in ["POST", "PUT", "PATCH"]:
                body = await request.read()

            # Make the request to the remote MCP service
            async with aiohttp.ClientSession() as session:
                async with session.request(
                    method=request.method,
                    url=remote_url,
                    headers=headers,
                    data=body,
                    ssl=False,  # For testing with self-signed certs
                ) as remote_response:
                    # Create response
                    response = web.StreamResponse(
                        status=remote_response.status,
                        headers=remote_response.headers,
                    )

                    # Remove content-encoding to avoid double encoding
                    response.headers.pop("Content-Encoding", None)

                    await response.prepare(request)

                    # Stream the response body
                    async for chunk in remote_response.content.iter_chunked(8192):
                        await response.write(chunk)

                    self.logger.info(
                        f"Proxied MCP response - mcp={mcp_name}, method={request.method}, path={path_info}, status={remote_response.status}"
                    )

                    return response

        except Exception as e:
            self.logger.error(f"MCP proxy error: {str(e)}")
            return web.json_response(
                {"error": str(e)},
                status=500,
            )

    def _kill_process_on_port(self, port: int) -> bool:
        """Try to kill process using the specified port (without sudo)"""
        try:
            # Find process using the port
            result = subprocess.run(
                ["lsof", "-ti", f":{port}"], capture_output=True, text=True, timeout=5
            )

            if result.returncode == 0 and result.stdout.strip():
                pids = result.stdout.strip().split("\n")
                killed_any = False

                for pid in pids:
                    if pid.strip():
                        try:
                            # Try to kill the process
                            kill_result = subprocess.run(
                                ["kill", pid.strip()], capture_output=True, timeout=5
                            )
                            if kill_result.returncode == 0:
                                self.logger.info(
                                    f"Killed process {pid} using port {port}"
                                )
                                killed_any = True
                            else:
                                self.logger.warning(f"Failed to kill process {pid}")
                        except Exception as e:
                            self.logger.warning(
                                f"Error killing process {pid}: {str(e)}"
                            )
                            # Don't send RPC error for process kill failures
                            pass

                if killed_any:
                    # Wait a moment for the port to be released
                    import time

                    time.sleep(1)
                    return True

            return False

        except subprocess.TimeoutExpired:
            self.logger.warning("Timeout while trying to find/kill process on port")
            return False
        except FileNotFoundError:
            self.logger.warning("lsof command not found")
            return False
        except Exception as e:
            self.logger.warning(
                f"Error trying to kill process on port {port}: {str(e)}"
            )
            return False

    def _is_port_available(self, port: int) -> bool:
        """Check if a port is available"""
        try:
            with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
                s.bind(("127.0.0.1", port))
                return True
        except OSError:
            self.logger.info(f"Port {port} is occupied, skipping proxy startup")
            return False

    async def start(self):
        """Start the proxy server"""
        # Check if port is available - exit silently if busy
        if not self._is_port_available(self.port):
            self.logger.info(f"Port {self.port} is busy, exiting silently")
            return 0  # Exit silently with success code

        runner = web.AppRunner(self.app)
        await runner.setup()
        site = web.TCPSite(runner, "localhost", self.port)
        await site.start()

        self.logger.info(
            f"Remote MCP proxy server started - port={self.port}, services={len(self.mcp_services)}"
        )

        output = (
            f"{SUCCESS_ICON} [bold green]Remote MCP proxy server started[/]\n"
            f"  Local:  http://localhost:{self.port}\n"
            f"  Services: {len(self.mcp_services)} MCP services loaded\n"
        )

        if self.mcp_services:
            output += "  Available MCPs:\n"
            for mcp_name, service_url in self.mcp_services.items():
                output += f"    • {mcp_name} → {service_url}\n"

        rprint(output)

        # Keep the server running
        try:
            await asyncio.Event().wait()
        except KeyboardInterrupt:
            self.logger.info("Remote MCP proxy server stopped by user")
            rprint(f"\n{INFO_ICON} [yellow]Remote MCP proxy server stopped[/]")
        finally:
            await runner.cleanup()

        return 0


def run_remote_mcp_proxy(port: int = 8098):
    """
    Run the remote MCP proxy server.

    Args:
        port: Local port to listen on (default: 8098)
    """
    logger = get_mcp_logger()
    logger.info(f"Starting remote MCP proxy - port={port}")

    # Check if aiohttp is available
    if not HAS_AIOHTTP:
        rprint(
            f"{ERROR_ICON} [bold red]aiohttp is required for remote MCP proxy functionality[/]\n"
            f"Please install it with: pip install aiohttp"
        )
        logger.error("aiohttp is not installed")
        return 1

    # Validate port
    if port < 1 or port > 65535:
        error_response = {
            "jsonrpc": "2.0",
            "id": 1,
            "error": {
                "code": -32602,
                "message": "Invalid params",
                "data": {
                    "details": f"Invalid port: {port}. Port must be between 1 and 65535"
                },
            },
        }
        print(json.dumps(error_response))
        return 1

    try:
        # Create and start the proxy server
        proxy = RemoteMCPProxy(port=port)

        # Run the async server
        return asyncio.run(proxy.start())

    except ImportError as e:
        rprint(
            f"{ERROR_ICON} [bold red]Missing dependency: {str(e)}[/]\n"
            f"Please install aiohttp: pip install aiohttp"
        )
        logger.error(f"Import error: {str(e)}")
        return 1
    except Exception as e:
        logger.error(f"Failed to start remote MCP proxy: {str(e)}")
        rprint(f"{ERROR_ICON} [bold red]Failed to start remote MCP proxy: {str(e)}[/]")
        return 1


def start_remote_proxy_background(port: int = 8098):
    """
    Start the remote MCP proxy server as a background process and act as MCP server.

    Args:
        port: Local port to listen on (default: 8098)
    """
    logger = get_mcp_logger()
    logger.info(f"Starting remote MCP proxy in background - port={port}")

    # Start the background proxy process (fire and forget)
    try:
        cmd = ["codegen", "mcp", "remote-proxy", "--port", str(port)]
        subprocess.Popen(
            cmd,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            stdin=subprocess.DEVNULL,
            start_new_session=True,
        )
        logger.info(f"Remote MCP proxy started in background - port: {port}")
    except Exception as e:
        logger.error(f"Failed to start remote MCP proxy in background: {str(e)}")
        # Continue anyway - we can still act as MCP server

    # Handle MCP protocol over STDIO immediately
    try:
        while True:
            try:
                # Read JSON-RPC request from stdin
                line = sys.stdin.readline()
                if not line:
                    break

                line = line.strip()
                if not line:
                    continue

                logger.info(f"Received request: {line}")
                request = json.loads(line)
                request_id = request.get("id")
                method = request.get("method")

                logger.info(f"Processing method: {method}, id: {request_id}")

                # Check if this is a notification (no id field)
                is_notification = "id" not in request

                if method == "initialize":
                    # Respond to initialize request
                    response = {
                        "jsonrpc": "2.0",
                        "id": request_id,
                        "result": {
                            "protocolVersion": "2024-11-05",
                            "capabilities": {"tools": {}},
                            "serverInfo": {
                                "name": "intuit-remote-mcp-proxy",
                                "version": "1.0.0",
                            },
                        },
                    }
                    logger.info(f"Sending initialize response: {json.dumps(response)}")
                    print(json.dumps(response), flush=True)

                elif method == "notifications/initialized":
                    # This is a notification - no response needed
                    logger.info(
                        "Received initialized notification - no response needed"
                    )

                elif method == "tools/list":
                    # Respond to tools list request
                    response = {
                        "jsonrpc": "2.0",
                        "id": request_id,
                        "result": {"tools": []},
                    }
                    logger.info(f"Sending tools/list response: {json.dumps(response)}")
                    print(json.dumps(response), flush=True)

                else:
                    # Unknown method - only send error response if it's not a notification
                    if not is_notification:
                        error_response = {
                            "jsonrpc": "2.0",
                            "id": request_id if request_id is not None else 0,
                            "error": {
                                "code": -32601,
                                "message": "Method not found",
                                "data": {
                                    "details": f"The method '{method}' is not supported"
                                },
                            },
                        }
                        logger.info(
                            f"Sending error response: {json.dumps(error_response)}"
                        )
                        print(json.dumps(error_response), flush=True)
                    else:
                        logger.info(f"Ignoring unknown notification: {method}")

            except json.JSONDecodeError as e:
                # Invalid JSON received
                logger.error(f"JSON decode error: {e}, line: {line}")
                error_response = {
                    "jsonrpc": "2.0",
                    "id": 0,
                    "error": {
                        "code": -32700,
                        "message": "Parse error",
                        "data": {"details": "Invalid JSON received"},
                    },
                }
                print(json.dumps(error_response), flush=True)

    except KeyboardInterrupt:
        logger.info("Remote-init stopped by user")
        return 0

    return 0
