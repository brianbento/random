# mypy: ignore-errors
"""
MCP release operation
"""

import asyncio
import os
import subprocess
import typing
from typing import Any, Dict, Optional

import click
import inquirer
import requests
import yaml
from git import Repo
from inquirer import List, Text
from rich import print as rprint
from rich.panel import Panel
from rich.progress import Progress, SpinnerColumn, TextColumn

from .client_helper import MCPClientHelper
from .constants import (
    ENV_ARGS,
    ENV_ENV_VARS,
    ENV_TOKEN,
    ERROR_ICON,
    INFO_ICON,
    MCP_API_BASE_URL,
    NODE_ICON,
    PYTHON_ICON,
    RELEASE_ICON,
    SUCCESS_ICON,
    VERSION_ICON,
    WARNING_ICON,
    EventType,
)
from .git_helpers import get_current_commit, get_repo_url, is_git_repo
from .logging_helper import get_mcp_logger
from .runtime_helpers import (
    create_or_reuse_venv,
    get_node_package_manager,
    install_in_venv,
    select_runtime,
)
from .utils import (
    get_args_from_json,
    get_env_var_or_prompt,
    get_env_vars_from_json,
    get_headers,
    get_latest_version,
    get_venv_path,
    get_version_type_from_env,
    validate_headless_requirements,
    verify_token,
)


def release_mcp(headless: bool = False):
    """Release an MCP service to the registry

    Args:
        headless: If True, use environment variables instead of prompting for user input
    """
    logger = get_mcp_logger()
    logger.info(f"Starting MCP release process, headless mode: {headless}")

    # Display a nice header
    if headless:
        rprint(f"{RELEASE_ICON} [bold]Releasing MCP service (headless mode)[/]\n")
    else:
        rprint(f"{RELEASE_ICON} [bold]Releasing MCP service[/]\n")

    # 1. Check for valid git setup
    if not is_git_repo("."):
        rprint(
            f"{ERROR_ICON} [bold red]Error: Current directory is not a git repository[/]"
        )
        return

    # 1.1 Check for uncommitted changes
    try:
        repo = Repo(".")
        if repo.is_dirty() or len(repo.untracked_files) > 0:
            rprint(
                f"{ERROR_ICON} [bold red]Error: There are uncommitted changes in the repository[/]"
            )
            rprint(f"{INFO_ICON} Please commit or stash your changes before releasing")

            # Show status details
            if repo.is_dirty():
                rprint("\n[yellow]Modified files:[/]")
                for item in repo.index.diff(None):
                    rprint(f"  [yellow]•[/] {item.a_path}")

            if len(repo.untracked_files) > 0:
                rprint("\n[yellow]Untracked files:[/]")
                for item in repo.untracked_files:
                    rprint(f"  [yellow]•[/] {item}")

            return

        # 1.2 Check if branch is in sync with remote
        try:
            current_branch = repo.active_branch
            tracking_branch = current_branch.tracking_branch()

            if tracking_branch:
                # Get commit counts ahead and behind
                commits_ahead = list(
                    repo.iter_commits(f"{tracking_branch}..{current_branch}")
                )
                commits_behind = list(
                    repo.iter_commits(f"{current_branch}..{tracking_branch}")
                )

                if commits_ahead or commits_behind:
                    rprint(
                        f"{ERROR_ICON} [bold red]Error: Your branch is not in sync with remote[/]"
                    )

                    if commits_ahead:
                        rprint(
                            f"  [yellow]•[/] Your branch is ahead by {len(commits_ahead)} commit(s)"
                        )

                    if commits_behind:
                        rprint(
                            f"  [yellow]•[/] Your branch is behind by {len(commits_behind)} commit(s)"
                        )

                    rprint(f"{INFO_ICON} Please sync with remote before releasing:")

                    if commits_behind and not commits_ahead:
                        rprint(f"  [cyan]•[/] Run: git pull")
                    elif commits_ahead and not commits_behind:
                        rprint(f"  [cyan]•[/] Run: git push")
                    else:
                        rprint(f"  [cyan]•[/] Run: git pull --rebase && git push")

                    return
            else:
                rprint(
                    f"{ERROR_ICON} [bold red]Error: Current branch has no upstream branch[/]"
                )
                rprint(f"{INFO_ICON} Please set an upstream branch before releasing:")
                rprint(f"  [cyan]•[/] Run: git push -u origin {current_branch.name}")
                return
        except Exception as e:
            rprint(
                f"{WARNING_ICON} [yellow]Warning: Unable to check remote sync: {str(e)}[/]"
            )

    except Exception as e:
        rprint(f"{ERROR_ICON} [bold red]Error checking git status: {str(e)}[/]")
        return

    # 2. Check for manifest.yaml
    if not os.path.exists("manifest.yaml"):
        rprint(f"{ERROR_ICON} [bold red]Error: manifest.yaml not found[/]")
        return

    try:
        with open("manifest.yaml", "r") as f:
            manifest = yaml.safe_load(f)

        if not manifest or not all(
            key in manifest for key in ["name", "description", "language"]
        ):
            rprint(
                f"{ERROR_ICON} [bold red]Error: manifest.yaml must contain name, description, and language fields[/]"
            )
            return

        name = manifest["name"]
        description = manifest["description"]
        language = manifest["language"].lower()
        language_icon = PYTHON_ICON if language == "python" else NODE_ICON

        # Validate headless requirements
        if not validate_headless_requirements(manifest, headless=headless):
            return

    except Exception as e:
        rprint(f"{ERROR_ICON} [bold red]Error reading manifest.yaml: {str(e)}[/]")
        return

    # 3. Check if MCP already exists
    with Progress(
        SpinnerColumn(),
        TextColumn(f"[bold blue]Checking if MCP '{name}' exists..."),
        transient=True,
    ) as progress:
        progress.add_task("check", total=None)
        from .utils import check_mcp_exists

        existing_mcp = check_mcp_exists(name)

    mcp_id = None

    if existing_mcp:
        rprint(f"{INFO_ICON} MCP '[bold]{name}[/]' already exists")
        mcp_id = existing_mcp.get("id")

        # 4. Verify token if MCP exists
        if mcp_id is None:
            rprint(
                f"{ERROR_ICON} [bold red]Error: Failed to get MCP ID from the existing MCP[/]"
            )
            return

        token = get_env_var_or_prompt(
            ENV_TOKEN, "Enter verification token from portal", headless=headless
        )
        if not token:
            return

        with Progress(
            SpinnerColumn(),
            TextColumn("[bold blue]Verifying token..."),
            transient=True,
        ) as progress:
            progress.add_task("verify", total=None)
            token_valid = verify_token(mcp_id, token)

        if not token_valid:
            rprint(f"{ERROR_ICON} [bold red]Error: Invalid verification token[/]")
            return

    # 5. Find appropriate runtime command
    command_path = select_runtime(language, headless=headless)

    if not command_path:
        rprint(
            f"{ERROR_ICON} [bold red]Error: Could not find a suitable {language} runtime on your system[/]"
        )
        return

    rprint(f"{language_icon} Using {language} runtime: [bold cyan]{command_path}[/]")

    # Install dependencies based on project language
    if language == "python":
        requirements_file = "requirements.txt"
        if os.path.exists(requirements_file):
            rprint(f"{INFO_ICON} Found requirements.txt, installing dependencies...")
            try:
                # Setup centralized MCP marketplace directory structure under user's home
                marketplace_base_dir = os.path.join(
                    os.path.expanduser("~"), ".intuit-mcp-marketplace"
                )
                os.makedirs(marketplace_base_dir, exist_ok=True)

                # Get or create virtual environment
                venv_path = get_venv_path(marketplace_base_dir, command_path, name)
                venv_bin_dir = create_or_reuse_venv(venv_path, command_path)

                if venv_bin_dir:
                    # Install requirements in the virtual environment
                    install_success = install_in_venv(venv_bin_dir, requirements_file)

                    # Update command_path to use the venv's Python
                    if install_success:
                        venv_python = os.path.join(venv_bin_dir, "python")
                        rprint(
                            f"{INFO_ICON} Using Python from virtual environment: [bold cyan]{venv_python}[/]"
                        )
                        command_path = venv_python
                else:
                    # Fallback to installing globally if venv creation fails
                    rprint(
                        f"{WARNING_ICON} [yellow]Falling back to global Python installation[/]"
                    )

                    # Show manual venv setup instructions
                    rprint(
                        Panel.fit(
                            f"To manually set up a virtual environment:\n\n"
                            f"1. Create a virtual environment:\n"
                            f"   [bold cyan]python3 -m venv {venv_path}[/]\n\n"
                            f"2. Activate the virtual environment:\n"
                            f"   [bold cyan]source {venv_path}/bin/activate[/]\n\n"
                            f"3. Install dependencies:\n"
                            f"   [bold cyan]pip3 install -r {requirements_file}[/]\n\n"
                            f"4. Run the MCP with the virtual environment's Python:\n"
                            f"   [bold cyan]{venv_path}/bin/python <script.py> <args>[/]",
                            title="[bold yellow]Manual Virtual Environment Setup[/]",
                            border_style="yellow",
                        )
                    )

                    with Progress(
                        SpinnerColumn(),
                        TextColumn("[bold blue]Installing Python dependencies..."),
                        transient=True,
                    ) as progress:
                        progress.add_task("install", total=None)
                        subprocess.run(
                            [
                                command_path,
                                "-m",
                                "pip",
                                "install",
                                "-r",
                                requirements_file,
                            ],
                            check=True,
                            capture_output=True,
                        )
                rprint(
                    f"{SUCCESS_ICON} [bold green]Dependencies installed successfully[/]"
                )
            except subprocess.CalledProcessError as e:
                rprint(f"{WARNING_ICON} [yellow]Error installing dependencies: {e}[/]")
                rprint(
                    f"{INFO_ICON} Continuing with release, but some dependencies may be missing"
                )
        else:
            rprint(
                f"{WARNING_ICON} [yellow]No requirements.txt found, skipping dependency installation[/]"
            )

    elif language == "node":
        package_file = "package.json"
        if os.path.exists(package_file):
            rprint(f"{INFO_ICON} Found package.json, installing dependencies...")
            try:
                # Determine which package manager to use
                package_manager, package_manager_path = get_node_package_manager(".")
                if package_manager and package_manager_path:
                    with Progress(
                        SpinnerColumn(),
                        TextColumn(
                            f"[bold blue]Installing Node.js dependencies with {package_manager}..."
                        ),
                        transient=True,
                    ) as progress:
                        progress.add_task("install", total=None)
                        # Set PATH to include the selected node path only for yarn install
                        if package_manager == "yarn" and command_path:
                            env = os.environ.copy()
                            node_dir = os.path.dirname(command_path)
                            env["PATH"] = f"{node_dir}:{env.get('PATH', '')}"
                            try:
                                subprocess.run(
                                    [package_manager_path, "install"],
                                    check=True,
                                    capture_output=True,
                                    env=env,
                                )
                            except FileNotFoundError:
                                rprint(
                                    f"{ERROR_ICON} [bold red]Error: yarn is not installed on your system. Please install yarn to use this project.[/]"
                                )
                                return
                            except subprocess.CalledProcessError as e:
                                rprint(
                                    f"{ERROR_ICON} [bold red]Error: yarn install failed with exit status {e.returncode}. Please check your dependencies and try again.[/]"
                                )
                                return
                        else:
                            try:
                                subprocess.run(
                                    [package_manager_path, "install"],
                                    check=True,
                                    capture_output=True,
                                )
                            except FileNotFoundError:
                                rprint(
                                    f"{ERROR_ICON} [bold red]Error: {package_manager} is not installed on your system. Please install {package_manager} to use this project.[/]"
                                )
                                return
                            except subprocess.CalledProcessError as e:
                                rprint(
                                    f"{ERROR_ICON} [bold red]Error: {package_manager} install failed with exit status {e.returncode}. Please check your dependencies and try again.[/]"
                                )
                                return
                    rprint(
                        f"{SUCCESS_ICON} [bold green]Dependencies installed successfully with {package_manager}[/]"
                    )
                else:
                    rprint(
                        f"{WARNING_ICON} [yellow]No package manager (npm/yarn) found in PATH, skipping dependency installation[/]"
                    )
            except subprocess.CalledProcessError as e:
                rprint(f"{WARNING_ICON} [yellow]Error installing dependencies: {e}[/]")
                rprint(
                    f"{INFO_ICON} Continuing with release, but some dependencies may be missing"
                )
        else:
            rprint(
                f"{WARNING_ICON} [yellow]No package.json found, skipping dependency installation[/]"
            )

    # Process manifest for args and env vars
    env_vars = {}
    cli_args = []

    # Get index file path
    if "index" not in manifest:
        rprint(
            f"{ERROR_ICON} [bold red]Error: manifest.yaml must contain an 'index' field pointing to the server entry point[/]"
        )
        return

    server_script_path = os.path.abspath(manifest["index"])

    # Add an explanation about server health check
    rprint(
        Panel.fit(
            f"The MCP server will now be started to verify it's working correctly before release.\n"
            f"This health check ensures your MCP is functional and can connect properly.\n"
            f"You'll need to provide any required environment variables and command arguments.",
            title="[bold]Server Health Check Required[/]",
            border_style="blue",
        )
    )

    # Environment variables
    if (
        "env" in manifest
        and hasattr(manifest["env"], "__iter__")
        and not isinstance(manifest["env"], str)
    ):
        if manifest["env"]:
            if not headless:
                rprint(
                    "\n[bold]Configure Environment Variables for Server Health Check:[/]"
                )

        # Try to get environment variables from JSON first
        env_json = os.environ.get(ENV_ENV_VARS)
        env_vars = get_env_vars_from_json(env_json, manifest["env"], headless=headless)

        # If no environment variables from JSON, prompt for each one
        if not env_vars:
            for env in manifest["env"]:
                if isinstance(env, dict) and "name" in env:
                    default = env.get("default", "")
                    desc = env.get("description", "")

                    # Print highlighted description and default value before the prompt
                    if desc:
                        rprint(f"  [bold cyan]Description:[/] [italic]{desc}[/]")
                    if default:
                        rprint(f"  [bold yellow]Default:[/] {default}")

                    env_question = [
                        Text(
                            "value",
                            message=f"Environment variable '{env['name']}' for server check",
                            default=default,
                        )
                    ]
                    env_answer = inquirer.prompt(env_question)
                    if not env_answer:
                        rprint(
                            f"\n{WARNING_ICON} [yellow]Operation cancelled by user[/]"
                        )
                        return
                    env_vars[env["name"]] = env_answer["value"]
                    rprint("")  # Add empty line for better readability

    # Arguments
    if (
        "args" in manifest
        and hasattr(manifest["args"], "__iter__")
        and not isinstance(manifest["args"], str)
    ):
        if manifest["args"]:
            if not headless:
                rprint(
                    "\n[bold]Configure Command Arguments for Server Health Check:[/]"
                )

        # Try to get arguments from JSON first
        args_json = os.environ.get(ENV_ARGS)
        cli_args = get_args_from_json(args_json, manifest["args"], headless=headless)

        # If no arguments from JSON, prompt for each one
        if not cli_args:
            for arg in manifest["args"]:
                if isinstance(arg, dict) and "name" in arg:
                    default = arg.get("default", "")
                    desc = arg.get("description", "")

                    # Print highlighted description and default value before the prompt
                    if desc:
                        rprint(f"  [bold cyan]Description:[/] [italic]{desc}[/]")
                    if default:
                        rprint(f"  [bold yellow]Default:[/] {default}")

                    arg_question = [
                        Text(
                            "value",
                            message=f"Argument '{arg['name']}' for server check",
                            default=default,
                        )
                    ]
                    arg_answer = inquirer.prompt(arg_question)
                    if not arg_answer:
                        rprint(
                            f"\n{WARNING_ICON} [yellow]Operation cancelled by user[/]"
                        )
                        return
                    cli_args.append(f"--{arg['name']}={arg_answer['value']}")
                    rprint("")  # Add empty line for better readability

    # Prepare formatted arguments for API with default_value
    args = []
    if (
        "args" in manifest
        and hasattr(manifest["args"], "__iter__")
        and not isinstance(manifest["args"], str)
    ):
        for arg in manifest["args"]:
            if isinstance(arg, dict) and "name" in arg:
                # Find the user-provided value or use the default
                arg_value = ""
                for cli_arg in cli_args:
                    if cli_arg.startswith(f"--{arg['name']}="):
                        arg_value = cli_arg.split("=", 1)[1]
                        break

                args.append(
                    {
                        "arg_name": arg["name"],
                        "arg_desc": arg.get("description", ""),
                        "default_value": arg_value,
                    }
                )

    # Log the parameters
    rprint("\n[bold]Server Connection Parameters:[/]")
    rprint(f"Command: [cyan]{command_path}[/]")
    rprint(f"Script: [cyan]{server_script_path}[/]")

    # Connect to MCP server and extract info
    rprint(
        "\n[bold]Connecting to MCP server to extract tools, prompts, and resources...[/]"
    )

    try:
        # Create and run the client with asyncio
        client = MCPClientHelper()

        async def run_client():
            try:
                # Pass the command details to the helper
                await client.connect_to_server(
                    server_script_path, env_vars, cli_args, command_path
                )
                return client.get_info()
            finally:
                await client.disconnect()

        # Run the async function in the event loop
        mcp_info = asyncio.run(run_client())

        rprint(f"{SUCCESS_ICON} [bold green]Successfully extracted MCP info[/]")

    except ImportError as e:
        rprint(f"{ERROR_ICON} [bold red]Error: {str(e)}[/]")
        return
    except Exception as e:
        rprint(f"{ERROR_ICON} [bold red]Error connecting to MCP server: {str(e)}[/]")
        return

    # 9-13. Create or update MCP and version
    git_repo_url = get_repo_url()
    commit_id = get_current_commit()

    if not git_repo_url or not commit_id:
        rprint(
            f"{ERROR_ICON} [bold red]Error: Could not determine git repository URL or commit ID[/]"
        )
        return

    # Prepare MCP data
    mcp_data = {
        "name": name,
        "description": description,
        "language": language,
        "git_repository_url": git_repo_url,
        "arguments": args or [],  # Include formatted arguments, empty array if none
        "environment_variables": (
            [
                {
                    "var_name": key,
                    "var_desc": "Environment variable",
                    "default_value": env_vars.get(
                        key, ""
                    ),  # Include default_value field
                }
                for key in env_vars.keys()
            ]
            if env_vars
            else []
        ),  # Include environment variables, empty array if none
    }

    if mcp_id:
        # Skip updating existing MCP - only create a new version
        rprint(
            f"{INFO_ICON} Using existing MCP '[bold]{name}[/]', creating a new version only"
        )
    else:
        # Create new MCP
        try:
            with Progress(
                SpinnerColumn(),
                TextColumn(f"[bold blue]Creating MCP '{name}'..."),
                transient=True,
            ) as progress:
                progress.add_task("create", total=None)
                response = logger.make_api_call(
                    "POST",
                    MCP_API_BASE_URL,
                    headers=get_headers(),
                    json_data=mcp_data,
                )

            if response.status_code != 200:
                rprint(f"{ERROR_ICON} [bold red]Error creating MCP: {response.text}[/]")
                return

            mcp_id = response.json().get("id")

            # Get and store token from MCP creation response
            token = response.json().get("token", "unknown")
        except Exception as e:
            rprint(f"{ERROR_ICON} [bold red]Error creating MCP: {str(e)}[/]")
            return

    # Get previous version if any
    with Progress(
        SpinnerColumn(),
        TextColumn("[bold blue]Fetching version information..."),
        transient=True,
    ) as progress:
        progress.add_task("version", total=None)
        latest_version = get_latest_version(mcp_id, published_only=False)

    version_number = "1.0.0"

    if latest_version:
        current_version = latest_version.get("version", "1.0.0")
        parts = current_version.split(".")

        # Try to get version type from environment variable first
        version_type = get_version_type_from_env(headless=headless)

        # If no version type from environment, prompt user
        if not version_type:
            # Select version type with inquirer
            version_choices = [
                {
                    "name": "Major (breaking changes) - v" + f"{int(parts[0]) + 1}.0.0",
                    "value": "major",
                },
                {
                    "name": "Minor (new features) - v"
                    + f"{parts[0]}.{int(parts[1]) + 1}.0",
                    "value": "minor",
                },
                {
                    "name": "Patch (bug fixes) - v"
                    + f"{parts[0]}.{parts[1]}.{int(parts[2]) + 1}",
                    "value": "patch",
                },
            ]

            version_question = [
                List(
                    "version_type",
                    message="Select release type",
                    choices=[choice["name"] for choice in version_choices],
                ),
            ]

            version_answer = inquirer.prompt(version_question)
            if not version_answer:
                rprint(f"\n{WARNING_ICON} [yellow]Operation cancelled by user[/]")
                return

            version_type = next(
                choice["value"]
                for choice in version_choices
                if choice["name"] == version_answer["version_type"]
            )

        if version_type == "major":
            version_number = f"{int(parts[0]) + 1}.0.0"
        elif version_type == "minor":
            version_number = f"{parts[0]}.{int(parts[1]) + 1}.0"
        else:  # patch
            version_number = f"{parts[0]}.{parts[1]}.{int(parts[2]) + 1}"

    # Prepare version data
    version_data = {
        "version": version_number,
        "commit_id": commit_id,  # Include the commit ID in the version payload
        "tools": mcp_info.get("tools", []),
        "prompts": mcp_info.get("prompts", []),
        "resources": mcp_info.get("resources", []),
        "environment_variables": [
            {
                "var_name": env["name"],
                "var_desc": env.get("description", ""),
                "default_value": env.get(
                    "default", ""
                ),  # Use original default value from manifest
            }
            for env in manifest.get("env", [])
            if isinstance(env, dict) and "name" in env
        ],
        "arguments": [
            {
                "arg_name": arg["name"],
                "arg_desc": arg.get("description", ""),
                "default_value": arg.get(
                    "default", ""
                ),  # Use original default value from manifest
            }
            for arg in manifest.get("args", [])
            if isinstance(arg, dict) and "name" in arg
        ],
    }

    # Create version
    try:
        with Progress(
            SpinnerColumn(),
            TextColumn(f"[bold blue]Creating version {version_number}..."),
            transient=True,
        ) as progress:
            progress.add_task("create_version", total=None)
            response = logger.make_api_call(
                "POST",
                f"{MCP_API_BASE_URL}/{mcp_id}/versions",
                headers=get_headers(),
                json_data=version_data,
            )

        if response.status_code != 200:
            rprint(f"{ERROR_ICON} [bold red]Error creating version: {response.text}[/]")
            return

        version_id = response.json().get("id")
        rprint(
            f"{SUCCESS_ICON} [bold green]Version created successfully with ID: {version_id}[/]"
        )

    except Exception as e:
        rprint(
            f"{ERROR_ICON} [bold red]Error creating or publishing version: {str(e)}[/]"
        )
        return

    rprint(
        f"\n{SUCCESS_ICON} [bold green]MCP '{name}' version {version_number} successfully released![/]"
    )
    if not existing_mcp:
        rprint(
            Panel.fit(
                f"Your verification token is: [bold cyan]{token}[/]\n\nSave this token for future releases to this MCP",
                title="[bold]Verification Token[/]",
                border_style="yellow",
            )
        )
