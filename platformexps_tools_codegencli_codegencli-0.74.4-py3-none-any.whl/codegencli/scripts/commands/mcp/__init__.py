# MCP Command Module
"""
MCP (Model Context Protocol) command module with modular organization
"""

from .main import mcp

__all__ = ["mcp"]
