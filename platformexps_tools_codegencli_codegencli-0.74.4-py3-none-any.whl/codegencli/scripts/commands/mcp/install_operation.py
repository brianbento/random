# mypy: ignore-errors
"""
MCP install operation
"""

import json
import os
import shutil
import subprocess
import typing
from typing import Any, Dict, Optional

import inquirer
import requests
import yaml
from git import Repo
from inquirer import Checkbox, Text
from rich import print as rprint
from rich.panel import Panel
from rich.progress import Progress, SpinnerColumn, TextColumn

from codegencli.scripts.services.secure_storage import (
    store_arg,
    store_env_var,
    store_mcp_metadata,
    store_mcp_v2_metadata,
)

from .analytics import send_analytics_event, send_mcp_install_analytics
from .constants import (
    ERROR_ICON,
    IDE_ICON,
    IDE_SETTINGS,
    INFO_ICON,
    INSTALL_ICON,
    MCP_API_BASE_URL,
    NODE_ICON,
    PYTHON_ICON,
    SUCCESS_ICON,
    VERSION_ICON,
    WARNING_ICON,
    EventType,
)
from .git_helpers import clone_git_repository_with_fallback
from .ide_config import (
    find_jetbrains_settings_files,
    update_jetbrains_settings_xml,
    update_settings_json,
    update_settings_json_remote,
)
from .logging_helper import get_mcp_logger
from .runtime_helpers import (
    create_or_reuse_venv,
    get_node_package_manager,
    install_in_venv,
    select_runtime,
)
from .utils import (
    display_manual_installation_configs,
    find_mcp_in_both_versions,
    get_headers,
    get_latest_version,
    get_mcp_by_name,
    get_mcp_versions_v2,
    get_venv_path,
    verify_docker_runtime,
)


def install_mcp(name_with_version: str):
    """Install an MCP service

    NAME_WITH_VERSION can be in format name:version to install a specific version.
    Using name:latest will install the latest version.
    """
    logger = get_mcp_logger()
    logger.info(f"Starting MCP installation: {name_with_version}")

    # Parse name and optional version
    name_parts = name_with_version.split(":", 1)
    name = name_parts[0]
    specified_version = name_parts[1] if len(name_parts) > 1 else None

    logger.info(f"Parsed MCP name: {name}, version: {specified_version or 'latest'}")

    # Display a nice header
    version_display = f" (version: {specified_version})" if specified_version else ""
    rprint(f"{INSTALL_ICON} [bold]Installing MCP service: {name}{version_display}[/]\n")

    # 1. Check if MCP exists in both v1 and v2
    with Progress(
        SpinnerColumn(),
        TextColumn(f"[bold blue]Looking up MCP '{name}'..."),
        transient=True,
    ) as progress:
        progress.add_task("lookup", total=None)
        v1_mcp, v2_mcp = find_mcp_in_both_versions(name)

    if not v1_mcp and not v2_mcp:
        rprint(f"{ERROR_ICON} [bold red]Error: MCP '{name}' not found[/]")
        return

    # Prioritize v2 if found
    if v2_mcp:
        return install_mcp_v2(name, specified_version, v2_mcp)
    else:
        mcp = v1_mcp

    mcp_id = mcp.get("id")
    if mcp_id is None:
        rprint(
            f"{ERROR_ICON} [bold red]Error: Failed to get MCP ID from the retrieved MCP[/]"
        )
        return

    language = mcp.get("language", "").lower()
    language_icon = PYTHON_ICON if language == "python" else NODE_ICON

    # 2. Get version information
    with Progress(
        SpinnerColumn(),
        TextColumn("[bold blue]Fetching version information..."),
        transient=True,
    ) as progress:
        progress.add_task("fetch", total=None)

        # If no version is specified or version is "latest", get the latest version
        if not specified_version or specified_version.lower() == "latest":
            latest_version = get_latest_version(mcp_id, published_only=True)
            if not latest_version:
                rprint(
                    f"{ERROR_ICON} [bold red]Error: No versions found for MCP '{name}'[/]"
                )
                return
        else:
            # Get all versions and find the specified one
            try:
                response = logger.make_api_call(
                    "GET",
                    f"{MCP_API_BASE_URL}/{mcp_id}/versions",
                    headers=get_headers(),
                )
                if response.status_code != 200:
                    rprint(
                        f"{ERROR_ICON} [bold red]Error fetching versions: {response.text}[/]"
                    )
                    return

                versions = response.json().get("items", [])
                if not versions:
                    rprint(
                        f"{ERROR_ICON} [bold red]Error: No versions found for MCP '{name}'[/]"
                    )
                    return

                # Find the version that matches the specified version string
                latest_version = None
                for version in versions:
                    if version.get("version") == specified_version:
                        latest_version = version
                        break

                if not latest_version:
                    rprint(
                        f"{ERROR_ICON} [bold red]Error: Version '{specified_version}' not found for MCP '{name}'[/]"
                    )
                    available_versions = ", ".join(
                        [v.get("version", "unknown") for v in versions]
                    )
                    rprint(
                        f"{INFO_ICON} Available versions: [bold cyan]{available_versions}[/]"
                    )
                    return
            except Exception as e:
                rprint(f"{ERROR_ICON} [bold red]Error fetching versions: {str(e)}[/]")
                return

    version = latest_version.get("version", "unknown")
    state = latest_version.get("state", "unknown")

    # Show warning for DRAFT or DEPRECATED state
    state_display = (
        f"[bold green]{state}[/]"
        if state == "PUBLISHED"
        else f"[bold yellow]{state}[/]"
    )
    rprint(f"{VERSION_ICON} Using version [bold cyan]{version}[/] ({state_display})")

    if state == "DRAFT":
        rprint(
            f"{WARNING_ICON} [yellow]Warning: Installing a DRAFT version which may not be fully tested[/]"
        )
    elif state == "DEPRECATED":
        rprint(
            f"{WARNING_ICON} [yellow]Warning: Installing a DEPRECATED version which may not be supported[/]"
        )

    # 3. Clone repository
    git_repo_url = mcp.get("git_repository_url")
    if not git_repo_url:
        rprint(
            f"{ERROR_ICON} [bold red]Error: No repository URL found for MCP '{name}'[/]"
        )
        return

    # Setup centralized MCP marketplace directory structure under user's home
    marketplace_base_dir = os.path.join(
        os.path.expanduser("~"), ".intuit-mcp-marketplace"
    )
    mcp_dir = os.path.join(marketplace_base_dir, name)
    version_dir = os.path.join(mcp_dir, version)

    # Create the directory structure
    rprint(f"{INFO_ICON} Setting up MCP in [cyan]{version_dir}[/]")

    # Create parent directories if they don't exist
    os.makedirs(marketplace_base_dir, exist_ok=True)
    os.makedirs(mcp_dir, exist_ok=True)

    # If version directory exists, remove it to ensure clean installation
    if os.path.exists(version_dir):
        rprint(f"{INFO_ICON} Removing existing installation...")
        shutil.rmtree(version_dir)

    os.makedirs(version_dir, exist_ok=True)

    # Clone repository to target directory (version-specific)
    repo = None

    def progress_callback():
        with Progress(
            SpinnerColumn(),
            TextColumn(f"[bold blue]Cloning repository..."),
            transient=True,
        ) as progress:
            progress.add_task("clone", total=None)

    # Use the new fallback logic
    success = clone_git_repository_with_fallback(
        git_repo_url, version_dir, progress_callback
    )

    if success:
        rprint(f"{SUCCESS_ICON} Successfully cloned repository")
        try:
            repo = Repo(version_dir)
        except Exception as e:
            rprint(
                f"{ERROR_ICON} [bold red]Error accessing cloned repository: {str(e)}[/]"
            )
            return
    else:
        rprint(f"{ERROR_ICON} [bold red]Error cloning repository[/]")
        return

    # Checkout specific commit if available
    commit_id = latest_version.get("commit_id")
    if commit_id and repo:
        try:
            repo.git.checkout(commit_id)
            rprint(
                f"{SUCCESS_ICON} Successfully checked out commit: [bold cyan]{commit_id[:8]}[/]"
            )
        except Exception as checkout_err:
            rprint(
                f"{WARNING_ICON} [yellow]Could not checkout commit {commit_id[:8]}: {str(checkout_err)}[/]"
            )
            rprint(f"{INFO_ICON} Using latest commit from the default branch")

    # Read manifest from cloned repo
    manifest_path = os.path.join(version_dir, "manifest.yaml")

    try:
        with open(manifest_path, "r") as f:
            manifest = yaml.safe_load(f)
    except Exception as e:
        rprint(f"{ERROR_ICON} [bold red]Error reading manifest.yaml: {str(e)}[/]")
        return

    # 4-7. Setup MCP configuration
    command_path = select_runtime(language)

    if not command_path:
        rprint(
            f"{ERROR_ICON} [bold red]Error: Could not find a suitable {language} runtime on your system[/]"
        )
        return

    rprint(f"{language_icon} Using {language} runtime: [bold cyan]{command_path}[/]")

    # Install dependencies based on project language
    if language == "python":
        requirements_file = os.path.join(version_dir, "requirements.txt")
        if os.path.exists(requirements_file):
            # Get or create virtual environment
            venv_path = get_venv_path(marketplace_base_dir, command_path, name)
            venv_bin_dir = create_or_reuse_venv(venv_path, command_path)

            if venv_bin_dir:
                # Install requirements in the virtual environment
                install_success = install_in_venv(venv_bin_dir, requirements_file)

                # Update command_path to use the venv's Python
                if install_success:
                    venv_python = os.path.join(venv_bin_dir, "python")
                    rprint(
                        f"{INFO_ICON} Using Python from virtual environment: [bold cyan]{venv_python}[/]"
                    )
                    command_path = venv_python
            else:
                # Fallback to installing globally if venv creation fails
                rprint(
                    f"{WARNING_ICON} [yellow]Falling back to global Python installation[/]"
                )

                # Show manual venv setup instructions
                rprint(
                    Panel.fit(
                        f"To manually set up a virtual environment:\n\n"
                        f"1. Create a virtual environment:\n"
                        f"   [bold cyan]python3 -m venv {venv_path}[/]\n\n"
                        f"2. Activate the virtual environment:\n"
                        f"   [bold cyan]source {venv_path}/bin/activate[/]\n\n"
                        f"3. Install dependencies:\n"
                        f"   [bold cyan]pip3 install -r {requirements_file}[/]\n\n"
                        f"4. Run the MCP with the virtual environment's Python:\n"
                        f"   [bold cyan]{venv_path}/bin/python <script.py> <args>[/]",
                        title="[bold yellow]Manual Virtual Environment Setup[/]",
                        border_style="yellow",
                    )
                )

                try:
                    with Progress(
                        SpinnerColumn(),
                        TextColumn("[bold blue]Installing Python dependencies..."),
                        transient=True,
                    ) as progress:
                        progress.add_task("install", total=None)
                        subprocess.run(
                            [
                                command_path,
                                "-m",
                                "pip",
                                "install",
                                "-r",
                                requirements_file,
                            ],
                            check=True,
                            capture_output=True,
                        )
                    rprint(
                        f"{SUCCESS_ICON} [bold green]Dependencies installed successfully[/]"
                    )
                except subprocess.CalledProcessError as e:
                    rprint(
                        f"{WARNING_ICON} [yellow]Error installing dependencies: {e}[/]"
                    )
                    rprint(
                        f"{INFO_ICON} Continuing with installation, but some dependencies may be missing"
                    )
        else:
            rprint(
                f"{WARNING_ICON} [yellow]No requirements.txt found, skipping dependency installation[/]"
            )

    elif language == "node":
        package_file = os.path.join(version_dir, "package.json")
        if os.path.exists(package_file):
            rprint(f"{INFO_ICON} Found package.json, installing dependencies...")
            try:
                # Determine which package manager to use
                package_manager, package_manager_path = get_node_package_manager(
                    version_dir
                )
                if package_manager and package_manager_path:
                    # Change to the version directory for package manager install
                    current_dir = os.getcwd()
                    os.chdir(version_dir)

                    with Progress(
                        SpinnerColumn(),
                        TextColumn(
                            f"[bold blue]Installing Node.js dependencies with {package_manager}..."
                        ),
                        transient=True,
                    ) as progress:
                        progress.add_task("install", total=None)
                        # Set PATH to include the selected node path only for yarn install
                        if package_manager == "yarn" and command_path:
                            env = os.environ.copy()
                            node_dir = os.path.dirname(command_path)
                            env["PATH"] = f"{node_dir}:{env.get('PATH', '')}"
                            try:
                                subprocess.run(
                                    [package_manager_path, "install"],
                                    check=True,
                                    capture_output=True,
                                    env=env,
                                )
                            except FileNotFoundError:
                                rprint(
                                    f"{ERROR_ICON} [bold red]Error: yarn is not installed on your system. Please install yarn to use this project.[/]"
                                )
                                # Change back to original directory before returning
                                os.chdir(current_dir)
                                return
                            except subprocess.CalledProcessError as e:
                                rprint(
                                    f"{ERROR_ICON} [bold red]Error: yarn install failed with exit status {e.returncode}. Please check your dependencies and try again.[/]"
                                )
                                # Change back to original directory before returning
                                os.chdir(current_dir)
                                return
                        else:
                            try:
                                subprocess.run(
                                    [package_manager_path, "install"],
                                    check=True,
                                    capture_output=True,
                                )
                            except FileNotFoundError:
                                rprint(
                                    f"{ERROR_ICON} [bold red]Error: {package_manager} is not installed on your system. Please install {package_manager} to use this project.[/]"
                                )
                                # Change back to original directory before returning
                                os.chdir(current_dir)
                                return
                            except subprocess.CalledProcessError as e:
                                rprint(
                                    f"{ERROR_ICON} [bold red]Error: {package_manager} install failed with exit status {e.returncode}. Please check your dependencies and try again.[/]"
                                )
                                # Change back to original directory before returning
                                os.chdir(current_dir)
                                return

                    # Change back to original directory
                    os.chdir(current_dir)

                    rprint(
                        f"{SUCCESS_ICON} [bold green]Dependencies installed successfully with {package_manager}[/]"
                    )
                else:
                    rprint(
                        f"{WARNING_ICON} [yellow]No package manager (npm/yarn) found in PATH, skipping dependency installation[/]"
                    )
            except subprocess.CalledProcessError as e:
                rprint(f"{WARNING_ICON} [yellow]Error installing dependencies: {e}[/]")
                rprint(
                    f"{INFO_ICON} Continuing with installation, but some dependencies may be missing"
                )

                # Ensure we change back to original directory if an error occurred
                if os.getcwd() != current_dir:
                    os.chdir(current_dir)
        else:
            rprint(
                f"{WARNING_ICON} [yellow]No package.json found, skipping dependency installation[/]"
            )

    # Process manifest for args and env vars
    args = []
    env_vars = {}

    # Main entry point from manifest
    if "index" in manifest:
        args.append(os.path.abspath(os.path.join(version_dir, manifest["index"])))

    # Environment variables
    if (
        "env" in manifest
        and hasattr(manifest["env"], "__iter__")
        and not isinstance(manifest["env"], str)
    ):
        if manifest["env"]:
            rprint("\n[bold]Configure Environment Variables:[/]")
        for env in manifest["env"]:
            if isinstance(env, dict) and "name" in env:
                default = env.get("default", "")
                desc = env.get("description", "")

                # Print highlighted description and default value before the prompt
                if desc:
                    rprint(f"  [bold cyan]Description:[/] [italic]{desc}[/]")
                if default:
                    rprint(f"  [bold yellow]Default:[/] {default}")

                env_question = [
                    Text(
                        "value",
                        message=f"Environment variable '{env['name']}'",
                        default=default,
                    )
                ]
                env_answer = inquirer.prompt(env_question)
                if not env_answer:
                    rprint(f"\n{WARNING_ICON} [yellow]Operation cancelled by user[/]")
                    return
                env_vars[env["name"]] = env_answer["value"]
                rprint("")  # Add empty line for better readability

    # Arguments
    if (
        "args" in manifest
        and hasattr(manifest["args"], "__iter__")
        and not isinstance(manifest["args"], str)
    ):
        if manifest["args"]:
            rprint("\n[bold]Configure Command Arguments:[/]")
        for arg in manifest["args"]:
            if isinstance(arg, dict) and "name" in arg:
                default = arg.get("default", "")
                desc = arg.get("description", "")

                # Print highlighted description and default value before the prompt
                if desc:
                    rprint(f"  [bold cyan]Description:[/] [italic]{desc}[/]")
                if default:
                    rprint(f"  [bold yellow]Default:[/] {default}")

                arg_question = [
                    Text(
                        "value",
                        message=f"Argument '{arg['name']}'",
                        default=default,
                    )
                ]
                arg_answer = inquirer.prompt(arg_question)
                if not arg_answer:
                    rprint(f"\n{WARNING_ICON} [yellow]Operation cancelled by user[/]")
                    return
                args.append(f"--{arg['name']}={arg_answer['value']}")
                rprint("")  # Add empty line for better readability

    # 8. Select IDEs with checkboxes
    ide_choices = [
        {
            "name": f"{IDE_ICON} {IDE_SETTINGS[ide]['name']}",
            "value": ide,
        }
        for ide in IDE_SETTINGS.keys()
    ]

    # Add manual installation option
    manual_installation_choice = {
        "name": f"📋 Manual Installation",
        "value": "manual_installation",
    }
    ide_choices.append(manual_installation_choice)

    ide_question = [
        Checkbox(
            "ides",
            message="Select IDEs to install MCP for",
            choices=[choice["name"] for choice in ide_choices],
            default=[choice["name"] for choice in ide_choices],  # Select all by default
        )
    ]

    ide_answer = inquirer.prompt(ide_question)
    if not ide_answer:
        rprint(f"\n{WARNING_ICON} [yellow]Operation cancelled by user[/]")
        return

    # Check if manual installation was selected
    manual_installation_selected = "📋 Manual Installation" in ide_answer["ides"]

    # Filter out manual installation from regular IDE processing
    selected_ides = [
        next(choice["value"] for choice in ide_choices if choice["name"] == ide_name)
        for ide_name in ide_answer["ides"]
        if ide_name != "📋 Manual Installation"
    ]

    if not selected_ides and not manual_installation_selected:
        rprint(f"{WARNING_ICON} [yellow]No IDEs selected[/]")
        return

    # 9. Store credentials in keychain
    with Progress(
        SpinnerColumn(),
        TextColumn("[bold blue]Storing credentials securely..."),
        transient=True,
    ) as progress:
        progress.add_task("store", total=None)

        # Store the script path (the first argument)
        script_path = args[0] if args else None

        # Store MCP metadata
        store_mcp_metadata(
            mcp_name=name,
            command_path=command_path,
            script_path=script_path,
            env_vars=env_vars,
            args=args[1:] if len(args) > 1 else [],  # Skip the script path in args
            version=version,
        )

        # Store environment variables
        for env_name, env_value in env_vars.items():
            store_env_var(name, env_name, env_value, version)

        # Store arguments (extract name and value from --name=value format)
        for arg in args[1:] if len(args) > 1 else []:  # Skip the script path
            if arg.startswith("--") and "=" in arg:
                arg_parts = arg[2:].split("=", 1)  # Remove -- and split on first =
                if len(arg_parts) == 2:
                    arg_name, arg_value = arg_parts
                    store_arg(name, arg_name, arg_value, version)

    # 10-12. Update settings files with proxy command
    success_count = 0
    failed_ides = []

    # Create proxy command and args
    proxy_command = "codegen"  # Use simple command name for portability
    proxy_args = ["mcp", "run", name, "--version", version]
    proxy_env_vars = {}  # No environment variables in IDE config

    # If only manual installation was selected, skip IDE updates
    if not selected_ides:
        if manual_installation_selected:
            display_manual_installation_configs(
                name, proxy_command, proxy_args, proxy_env_vars
            )
            rprint(
                f"\n{SUCCESS_ICON} [bold green]Manual installation configurations displayed for MCP '{name}'[/]"
            )
            # Log installation event for manual installation
            send_analytics_event(
                EventType.INSTALL_MCP, mcp_id, latest_version.get("id")
            )
            send_mcp_install_analytics(
                name, version, 0
            )  # 0 IDEs configured automatically
        return

    with Progress(
        SpinnerColumn(),
        TextColumn("[bold blue]Updating IDE settings..."),
        transient=False,
    ) as progress:
        for ide in selected_ides:
            task = progress.add_task(
                f"Updating {IDE_ICON} {IDE_SETTINGS[ide]['name']}...", total=1
            )

            # Special handling for JetBrains IDEs to show more detailed progress
            if ide.lower() == "qodo_jetbrains":
                settings_files = find_jetbrains_settings_files()
                if settings_files:
                    jetbrains_success, jetbrains_failed = update_jetbrains_settings_xml(
                        name, proxy_command, proxy_env_vars, proxy_args
                    )

                    if jetbrains_success > 0:
                        success_count += 1
                        progress.update(
                            task,
                            completed=1,
                            description=f"[green]✓[/] {IDE_ICON} {IDE_SETTINGS[ide]['name']} ({jetbrains_success} IDEs)",
                        )
                    else:
                        failed_ides.append(IDE_SETTINGS[ide]["name"])
                        progress.update(
                            task,
                            completed=1,
                            description=f"[red]✗[/] {IDE_ICON} {IDE_SETTINGS[ide]['name']}",
                        )
                else:
                    # No JetBrains settings files found
                    failed_ides.append(IDE_SETTINGS[ide]["name"])
                    progress.update(
                        task,
                        completed=1,
                        description=f"[red]✗[/] {IDE_ICON} {IDE_SETTINGS[ide]['name']} (No IDEs found)",
                    )
            else:
                # Regular IDE handling
                if update_settings_json(
                    ide, name, proxy_command, proxy_env_vars, proxy_args
                ):
                    success_count += 1
                    progress.update(
                        task,
                        completed=1,
                        description=f"[green]✓[/] {IDE_ICON} {IDE_SETTINGS[ide]['name']}",
                    )
                else:
                    failed_ides.append(IDE_SETTINGS[ide]["name"])
                    progress.update(
                        task,
                        completed=1,
                        description=f"[red]✗[/] {IDE_ICON} {IDE_SETTINGS[ide]['name']}",
                    )

    # Display manual installation configurations after IDE updates if selected
    if manual_installation_selected:
        display_manual_installation_configs(
            name, proxy_command, proxy_args, proxy_env_vars
        )

    if success_count > 0 or manual_installation_selected:
        # Build success message
        success_message = f"\n{SUCCESS_ICON} [bold green]MCP '{name}' successfully installed for {success_count} IDE(s)[/]"
        rprint(success_message)

        if failed_ides:
            rprint(
                f"{WARNING_ICON} [yellow]Failed to install for: {', '.join(failed_ides)}[/]"
            )

        # Log installation event
        send_analytics_event(EventType.INSTALL_MCP, mcp_id, latest_version.get("id"))

        # Send MCP install analytics to script.sh API endpoint
        send_mcp_install_analytics(name, version, success_count)

        # Only show restart message if IDEs were automatically configured
        if success_count > 0:
            rprint(
                Panel.fit(
                    "Please restart your IDE(s) to apply the changes",
                    title="[bold]Next Steps[/]",
                    border_style="cyan",
                )
            )
    else:
        rprint(f"{ERROR_ICON} [bold red]Failed to install MCP for any IDEs[/]")


def install_mcp_v2(name: str, specified_version: Optional[str], v2_mcp: Dict[str, Any]):
    """Install a v2 MCP service using Docker/Podman or Remote"""
    from .utils import verify_container_runtime

    mcp_id = v2_mcp.get("id")
    language = v2_mcp.get("language", "").lower()

    # Handle remote MCPs differently
    if language == "remote":
        return install_remote_mcp_v2(name, specified_version, v2_mcp)

    # Check for available container runtime
    success, runtime = verify_container_runtime()
    if not success or not runtime:
        return

    logger = get_mcp_logger()
    logger.info(f"Starting v2 MCP installation: {name}")

    # 1. Verify container runtime is available
    rprint(f"{INFO_ICON} Verifying container runtime ({runtime})...")
    success, runtime = verify_container_runtime()
    if not success or not runtime:
        rprint(
            f"{ERROR_ICON} [bold red]Container runtime (Docker or Podman) is required for this MCP but is not available[/]"
        )
        return

    mcp_id = v2_mcp.get("id")
    if not mcp_id:
        rprint(f"{ERROR_ICON} [bold red]Error: Failed to get MCP ID[/]")
        return

    # 2. Get version details from v2 API
    with Progress(
        SpinnerColumn(),
        TextColumn("[bold blue]Fetching version details..."),
        transient=True,
    ) as progress:
        progress.add_task("fetch", total=None)
        mcp_details = get_mcp_versions_v2(mcp_id)

    if not mcp_details:
        rprint(
            f"{ERROR_ICON} [bold red]Error: Could not fetch version details for MCP '{name}'[/]"
        )
        return

    versions = mcp_details.get("versions", [])
    if not versions:
        rprint(f"{ERROR_ICON} [bold red]Error: No versions found for MCP '{name}'[/]")
        return

    # 3. Determine version to use
    selected_version = None
    if not specified_version or specified_version.lower() == "latest":
        # Find version with "is_latest": true
        for version in versions:
            if version.get("is_latest", False):
                selected_version = version
                break
        if not selected_version:
            rprint(
                f"{ERROR_ICON} [bold red]Error: No latest version found for MCP '{name}'[/]"
            )
            return
    else:
        # Find specific version
        for version in versions:
            if version.get("version") == specified_version:
                selected_version = version
                break
        if not selected_version:
            rprint(
                f"{ERROR_ICON} [bold red]Error: Version '{specified_version}' not found for MCP '{name}'[/]"
            )
            available_versions = ", ".join(
                [v.get("version", "unknown") for v in versions]
            )
            rprint(
                f"{INFO_ICON} Available versions: [bold cyan]{available_versions}[/]"
            )
            return

    version_str = selected_version.get("version", "latest")
    image_name = selected_version.get("image_name")
    commit_id = selected_version.get("commit_id")
    environment_variables = selected_version.get("environment_variables", [])

    if not image_name:
        rprint(
            f"{ERROR_ICON} [bold red]Error: No image_name found for version '{version_str}'[/]"
        )
        return

    rprint(
        f"{VERSION_ICON} Using version [bold cyan]{version_str}[/] with image [bold cyan]{image_name}[/]"
    )

    # 4. Collect environment variables from user
    env_vars = {}
    if environment_variables:
        rprint("\n[bold]Configure Environment Variables:[/]")
        logger.debug(f"Environment variables structure: {environment_variables}")
        for env_var in environment_variables:
            logger.debug(f"Processing env_var: {env_var}")
            if isinstance(env_var, dict):
                # v2 API uses different field names
                env_name = env_var.get("var_name", env_var.get("name", ""))
                env_description = env_var.get(
                    "var_desc", env_var.get("description", "")
                )
                env_default = env_var.get("default_value", env_var.get("default", ""))
                logger.debug(
                    f"Extracted - name: '{env_name}', description: '{env_description}', default: '{env_default}'"
                )

                # Skip environment variables with empty names
                if not env_name:
                    logger.warning(
                        f"Skipping environment variable with empty name: {env_var}"
                    )
                    continue

                if env_description:
                    rprint(f"  [bold cyan]Description:[/] [italic]{env_description}[/]")
                if env_default:
                    rprint(f"  [bold yellow]Default:[/] {env_default}")

                env_question = [
                    Text(
                        "value",
                        message=f"Environment variable '{env_name}'",
                        default=env_default,
                    )
                ]
                env_answer = inquirer.prompt(env_question)
                if not env_answer:
                    rprint(f"\n{WARNING_ICON} [yellow]Operation cancelled by user[/]")
                    return
                env_vars[env_name] = env_answer["value"]
                rprint("")  # Add empty line for better readability

    # 5. Store v2 MCP metadata in keychain
    version_key = (
        "latest"
        if not specified_version or specified_version.lower() == "latest"
        else version_str
    )

    with Progress(
        SpinnerColumn(),
        TextColumn("[bold blue]Storing MCP configuration securely..."),
        transient=True,
    ) as progress:
        progress.add_task("store", total=None)

        # For 'latest', don't persist commit_id yet. We only want to record a commit_id
        # after we've actually pulled that image locally (handled in run_mcp_v2_proxy).
        # Otherwise, reinstalling after a new release would update the stored commit_id
        # without pulling the image, causing run-docker to incorrectly assume the cached
        # image is up to date and skip a needed pull.
        stored_commit_id = None if version_key == "latest" else commit_id

        success = store_mcp_v2_metadata(
            mcp_name=name,
            image_name=image_name,
            env_vars=env_vars,
            version=version_key,
            mcp_id=mcp_id,
            commit_id=stored_commit_id,
        )

        if not success:
            rprint(
                f"{ERROR_ICON} [bold red]Error: Failed to store MCP configuration[/]"
            )
            return

    # 6. Select IDEs for configuration
    ide_choices = [
        {
            "name": f"{IDE_ICON} {IDE_SETTINGS[ide]['name']}",
            "value": ide,
        }
        for ide in IDE_SETTINGS.keys()
    ]

    # Add manual installation option
    manual_installation_choice = {
        "name": f"📋 Manual Installation",
        "value": "manual_installation",
    }
    ide_choices.append(manual_installation_choice)

    ide_question = [
        Checkbox(
            "ides",
            message="Select IDEs to install MCP for",
            choices=[choice["name"] for choice in ide_choices],
            default=[choice["name"] for choice in ide_choices],  # Select all by default
        )
    ]

    ide_answer = inquirer.prompt(ide_question)
    if not ide_answer:
        rprint(f"\n{WARNING_ICON} [yellow]Operation cancelled by user[/]")
        return

    # Check if manual installation was selected
    manual_installation_selected = "📋 Manual Installation" in ide_answer["ides"]

    # Filter out manual installation from regular IDE processing
    selected_ides = [
        next(choice["value"] for choice in ide_choices if choice["name"] == ide_name)
        for ide_name in ide_answer["ides"]
        if ide_name != "📋 Manual Installation"
    ]

    if not selected_ides and not manual_installation_selected:
        rprint(f"{WARNING_ICON} [yellow]No IDEs selected[/]")
        return

    # 7. Update IDE settings with run-docker command
    success_count = 0
    failed_ides = []

    # Create proxy command and args for v2
    proxy_command = "codegen"
    proxy_args = ["mcp", "run-docker", name, "--version", version_key]
    proxy_env_vars = {}  # No environment variables in IDE config for v2

    # If only manual installation was selected, skip IDE updates
    if not selected_ides:
        if manual_installation_selected:
            display_manual_installation_configs_v2(
                name, proxy_command, proxy_args, proxy_env_vars
            )
            rprint(
                f"\n{SUCCESS_ICON} [bold green]Manual installation configurations displayed for MCP '{name}'[/]"
            )
        return

    with Progress(
        SpinnerColumn(),
        TextColumn("[bold blue]Updating IDE settings..."),
        transient=False,
    ) as progress:
        for ide in selected_ides:
            task = progress.add_task(
                f"Updating {IDE_ICON} {IDE_SETTINGS[ide]['name']}...", total=1
            )

            # Special handling for JetBrains IDEs
            if ide.lower() == "qodo_jetbrains":
                settings_files = find_jetbrains_settings_files()
                if settings_files:
                    jetbrains_success, jetbrains_failed = update_jetbrains_settings_xml(
                        name, proxy_command, proxy_env_vars, proxy_args
                    )

                    if jetbrains_success > 0:
                        success_count += 1
                        progress.update(
                            task,
                            completed=1,
                            description=f"[green]✓[/] {IDE_ICON} {IDE_SETTINGS[ide]['name']} ({jetbrains_success} IDEs)",
                        )
                    else:
                        failed_ides.append(IDE_SETTINGS[ide]["name"])
                        progress.update(
                            task,
                            completed=1,
                            description=f"[red]✗[/] {IDE_ICON} {IDE_SETTINGS[ide]['name']}",
                        )
                else:
                    failed_ides.append(IDE_SETTINGS[ide]["name"])
                    progress.update(
                        task,
                        completed=1,
                        description=f"[red]✗[/] {IDE_ICON} {IDE_SETTINGS[ide]['name']} (No IDEs found)",
                    )
            else:
                # Regular IDE handling
                if update_settings_json(
                    ide, name, proxy_command, proxy_env_vars, proxy_args
                ):
                    success_count += 1
                    progress.update(
                        task,
                        completed=1,
                        description=f"[green]✓[/] {IDE_ICON} {IDE_SETTINGS[ide]['name']}",
                    )
                else:
                    failed_ides.append(IDE_SETTINGS[ide]["name"])
                    progress.update(
                        task,
                        completed=1,
                        description=f"[red]✗[/] {IDE_ICON} {IDE_SETTINGS[ide]['name']}",
                    )

    # Display manual installation configurations after IDE updates if selected
    if manual_installation_selected:
        display_manual_installation_configs_v2(
            name, proxy_command, proxy_args, proxy_env_vars
        )

    if success_count > 0 or manual_installation_selected:
        success_message = f"\n{SUCCESS_ICON} [bold green]MCP '{name}' successfully installed for {success_count} IDE(s)[/]"
        rprint(success_message)

        if failed_ides:
            rprint(
                f"{WARNING_ICON} [yellow]Failed to install for: {', '.join(failed_ides)}[/]"
            )

        # Log installation event
        send_analytics_event(EventType.INSTALL_MCP, mcp_id, selected_version.get("id"))
        send_mcp_install_analytics(name, version_str, success_count)

        # Only show restart message if IDEs were automatically configured
        if success_count > 0:
            rprint(
                Panel.fit(
                    "Please restart your IDE(s) to apply the changes",
                    title="[bold]Next Steps[/]",
                    border_style="cyan",
                )
            )
    else:
        rprint(f"{ERROR_ICON} [bold red]Failed to install MCP for any IDEs[/]")


def display_manual_installation_configs_v2(
    mcp_name: str,
    proxy_command: str,
    proxy_args: typing.List[str],
    proxy_env_vars: Dict[str, str],
):
    """Display manual installation configurations for v2 MCPs (Docker/Podman)"""
    rprint(f"\n{INFO_ICON} [bold cyan]Manual Installation Configurations[/]")
    rprint("Use the following configuration in your IDE's MCP settings:")
    rprint("[yellow](Note: Requires Docker or Podman container runtime)[/]")

    # v2 MCP JSON format uses run-docker command (works with both Docker and Podman)
    v2_config = {
        mcp_name: {"command": proxy_command, "args": proxy_args, "env": proxy_env_vars}
    }

    rprint(f"[green]{json.dumps(v2_config, indent=2)}[/]")


def install_remote_mcp_v2(
    name: str, specified_version: Optional[str], v2_mcp: Dict[str, Any]
):
    """Install a remote v2 MCP service"""
    logger = get_mcp_logger()
    logger.info(f"Installing remote MCP: {name}")

    mcp_id = v2_mcp.get("id")

    # Get version details from v2 API
    with Progress(
        SpinnerColumn(),
        TextColumn(f"[bold blue]Fetching version details for '{name}'..."),
        transient=True,
    ) as progress:
        progress.add_task("fetch", total=None)
        mcp_details = get_mcp_versions_v2(mcp_id)

    if not mcp_details or "versions" not in mcp_details:
        rprint(
            f"{ERROR_ICON} [bold red]Error: Could not fetch version details for MCP '{name}'[/]"
        )
        return

    # Determine version to use
    versions = mcp_details["versions"]
    if not versions:
        rprint(
            f"{ERROR_ICON} [bold red]Error: No versions available for MCP '{name}'[/]"
        )
        return

    # Find the version to install
    version_to_install = None
    if specified_version and specified_version.lower() != "latest":
        version_to_install = next(
            (v for v in versions if v.get("version") == specified_version), None
        )
        if not version_to_install:
            rprint(
                f"{ERROR_ICON} [bold red]Error: Version '{specified_version}' not found for MCP '{name}'[/]"
            )
            return
    else:
        version_to_install = next(
            (v for v in versions if v.get("is_latest")), versions[0]
        )

    # For remote MCPs, service_url is at the top level of mcp_details, not in version
    service_url = mcp_details.get("service_url")
    if not service_url:
        rprint(
            f"{ERROR_ICON} [bold red]Error: No service URL found for MCP '{name}'[/]"
        )
        return

    version_str = version_to_install.get("version", "latest")

    # Update remote.csv file
    with Progress(
        SpinnerColumn(),
        TextColumn("[bold blue]Updating remote MCP registry..."),
        transient=True,
    ) as progress:
        progress.add_task("update", total=None)
        update_remote_csv(name, service_url)

    # Select IDEs for configuration
    ide_choices = [
        {
            "name": f"{IDE_ICON} {IDE_SETTINGS[ide]['name']}",
            "value": ide,
        }
        for ide in IDE_SETTINGS.keys()
    ]

    ide_choices.append(
        {"name": "📋 Manual Installation", "value": "manual_installation"}
    )

    ide_question = [
        Checkbox(
            "ides",
            message="Select IDEs to install MCP for",
            choices=[choice["name"] for choice in ide_choices],
            default=[choice["name"] for choice in ide_choices],  # Select all by default
        )
    ]

    ide_answer = inquirer.prompt(ide_question)
    if not ide_answer:
        rprint(f"\n{WARNING_ICON} [yellow]Operation cancelled by user[/]")
        return

    # Check if manual installation was selected
    manual_installation_selected = "📋 Manual Installation" in ide_answer["ides"]

    # Filter out manual installation from regular IDE processing
    selected_ides = [
        next(choice["value"] for choice in ide_choices if choice["name"] == ide_name)
        for ide_name in ide_answer["ides"]
        if ide_name != "📋 Manual Installation"
    ]

    if not selected_ides and not manual_installation_selected:
        rprint(f"{WARNING_ICON} [yellow]No IDEs selected[/]")
        return

    # Update IDE settings with remote configuration
    success_count = 0
    failed_ides = []

    # If only manual installation was selected, skip IDE updates
    if not selected_ides:
        if manual_installation_selected:
            display_manual_installation_configs_remote(name)
            rprint(
                f"\n{SUCCESS_ICON} [bold green]Manual installation configurations displayed for remote MCP '{name}'[/]"
            )
        return

    with Progress(
        SpinnerColumn(),
        TextColumn("[bold blue]Updating IDE settings..."),
        transient=False,
    ) as progress:
        for ide in selected_ides:
            task = progress.add_task(
                f"Updating {IDE_ICON} {IDE_SETTINGS[ide]['name']}...", total=1
            )

            if update_settings_json_remote(ide, name):
                success_count += 1
                progress.update(
                    task,
                    completed=1,
                    description=f"[green]✓[/] {IDE_ICON} {IDE_SETTINGS[ide]['name']}",
                )
            else:
                failed_ides.append(IDE_SETTINGS[ide]["name"])
                progress.update(
                    task,
                    completed=1,
                    description=f"[red]✗[/] {IDE_ICON} {IDE_SETTINGS[ide]['name']}",
                )

    # Display manual installation configurations if selected
    if manual_installation_selected:
        display_manual_installation_configs_remote(name)

    # Show results
    if success_count > 0 or manual_installation_selected:
        if success_count > 0:
            rprint(
                f"\n{SUCCESS_ICON} [bold green]Successfully installed remote MCP '{name}' for {success_count} IDE(s)[/]"
            )
        if failed_ides:
            rprint(f"{WARNING_ICON} [yellow]Failed for: {', '.join(failed_ides)}[/]")

        # Kill any existing process on port 8098 and start remote proxy
        rprint(f"{INFO_ICON} Starting remote MCP proxy server...")

        # Kill existing process on port 8098 (without sudo)
        try:
            result = subprocess.run(
                ["lsof", "-ti", ":8098"], capture_output=True, text=True, timeout=5
            )
            if result.returncode == 0 and result.stdout.strip():
                pids = result.stdout.strip().split("\n")
                for pid in pids:
                    if pid.strip():
                        try:
                            subprocess.run(
                                ["kill", pid.strip()], capture_output=True, timeout=5
                            )
                            rprint(f"{INFO_ICON} Stopped existing process on port 8098")
                        except Exception:
                            pass  # Ignore kill failures
        except Exception:
            pass  # Ignore lsof failures

        # Start remote proxy as background task
        try:
            subprocess.Popen(
                ["codegen", "mcp", "remote-proxy", "--port", "8098"],
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                stdin=subprocess.DEVNULL,
                start_new_session=True,
            )
            rprint(f"{SUCCESS_ICON} Remote MCP proxy server started in background")
        except Exception as e:
            rprint(f"{WARNING_ICON} [yellow]Failed to start remote proxy: {e}[/]")

        # Log installation event
        send_analytics_event(
            EventType.INSTALL_MCP, mcp_id, version_to_install.get("id")
        )
        send_mcp_install_analytics(name, version_str, success_count)

        # Only show restart message if IDEs were automatically configured
        if success_count > 0:
            rprint(
                Panel.fit(
                    "Please restart your IDE(s) to apply the changes",
                    title="[bold]Next Steps[/]",
                    border_style="cyan",
                )
            )
    else:
        rprint(f"{ERROR_ICON} [bold red]Failed to install remote MCP for any IDEs[/]")


def update_remote_csv(mcp_name: str, service_url: str):
    """Update or create the remote.csv file with MCP information"""
    import csv

    marketplace_dir = os.path.expanduser("~/.intuit-mcp-marketplace")
    os.makedirs(marketplace_dir, exist_ok=True)

    csv_path = os.path.join(marketplace_dir, "remote.csv")

    # Read existing entries
    existing_entries = {}
    if os.path.exists(csv_path):
        try:
            with open(csv_path, "r", newline="") as csvfile:
                reader = csv.DictReader(csvfile)
                for row in reader:
                    existing_entries[row["mcp_name"]] = row["service_url"]
        except Exception:
            pass  # If file is corrupted, start fresh

    # Update or add the entry
    existing_entries[mcp_name] = service_url

    # Write back to CSV
    with open(csv_path, "w", newline="") as csvfile:
        fieldnames = ["mcp_name", "service_url"]
        writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
        writer.writeheader()
        for name, url in existing_entries.items():
            writer.writerow({"mcp_name": name, "service_url": url})


def display_manual_installation_configs_remote(mcp_name: str):
    """Display manual installation configurations for remote MCPs"""
    rprint(f"\n{INFO_ICON} [bold cyan]Manual Installation Configurations[/]")
    rprint("Use the following configuration in your IDE's MCP settings:")

    # Remote MCP configuration
    remote_config = {
        mcp_name: {"url": f"http://localhost:8098/{mcp_name}"},
        "intuit-remote-mcp-proxy": {
            "command": "codegen",
            "env": {},
            "args": ["mcp", "remote-init"],
        },
    }

    rprint(f"[green]{json.dumps(remote_config, indent=2)}[/]")
