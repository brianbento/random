# mypy: ignore-errors
"""
Logging helper for MCP commands with unique execution IDs
"""

import logging
import os
import uuid
from datetime import datetime
from typing import Optional

from rich import print as rprint

from .utils import get_cli_version


class MCPLogger:
    """Logger for MCP commands with unique execution IDs"""

    _instance: Optional["MCPLogger"] = None
    _execution_id: Optional[str] = None
    _logger: Optional[logging.Logger] = None

    def __new__(cls) -> "MCPLogger":
        if cls._instance is None:
            cls._instance = super().__new__(cls)
        return cls._instance

    def __init__(self):
        if self._logger is None:
            self._setup_logger()

    def _setup_logger(self):
        """Setup the logger with unique execution ID"""
        # Generate unique execution ID
        self._execution_id = str(uuid.uuid4())[:8]

        # Create logs directory
        logs_dir = os.path.join(
            os.path.expanduser("~"), ".intuit-mcp-marketplace", "logs"
        )
        os.makedirs(logs_dir, exist_ok=True)

        # Create log file path
        log_file = os.path.join(logs_dir, f"{self._execution_id}.log")

        # Setup logger
        self._logger = logging.getLogger(f"mcp_command_{self._execution_id}")
        self._logger.setLevel(logging.DEBUG)

        # Remove any existing handlers
        self._logger.handlers.clear()

        # Create file handler
        file_handler = logging.FileHandler(log_file, mode="w", encoding="utf-8")
        file_handler.setLevel(logging.DEBUG)

        # Create formatter
        formatter = logging.Formatter(
            "%(asctime)s - %(levelname)s - %(funcName)s:%(lineno)d - %(message)s",
            datefmt="%Y-%m-%d %H:%M:%S",
        )
        file_handler.setFormatter(formatter)

        # Add handler to logger
        self._logger.addHandler(file_handler)

        # Log initial information with CLI version as the first line
        cli_version = get_cli_version()
        self._logger.info(f"CLI Version: {cli_version}")
        self._logger.info(f"Execution ID: {self._execution_id}")
        self._logger.info(f"MCP Command Execution Started")
        self._logger.info(f"Log File: {log_file}")
        self._logger.info(f"Timestamp: {datetime.now().isoformat()}")

    @property
    def execution_id(self) -> str:
        """Get the current execution ID"""
        return self._execution_id or "unknown"

    @property
    def logger(self) -> logging.Logger:
        """Get the logger instance"""
        if self._logger is None:
            self._setup_logger()
        return self._logger

    def display_execution_info(self, command_name: str = ""):
        """Display CLI version and execution ID in terminal"""
        cli_version = get_cli_version()
        execution_id = self.execution_id

        # Display only CLI version and execution ID (no command)
        rprint(f"[dim]CLI version: {cli_version} (execution id: {execution_id})[/]")

        # Log the command execution in the log file
        if command_name:
            self.logger.info(f"Command: {command_name}")

    def debug(self, message: str):
        """Log debug message"""
        self.logger.debug(message)

    def info(self, message: str):
        """Log info message"""
        self.logger.info(message)

    def warning(self, message: str):
        """Log warning message"""
        self.logger.warning(message)

    def error(self, message: str):
        """Log error message"""
        self.logger.error(message)

    def exception(self, message: str):
        """Log exception with traceback"""
        self.logger.exception(message)

    def log_function_entry(self, func_name: str, **kwargs):
        """Log function entry with parameters"""
        params = ", ".join([f"{k}={v}" for k, v in kwargs.items()])
        self.logger.debug(f"Entering {func_name}({params})")

    def log_function_exit(self, func_name: str, result=None):
        """Log function exit with result"""
        if result is not None:
            self.logger.debug(f"Exiting {func_name} with result: {result}")
        else:
            self.logger.debug(f"Exiting {func_name}")

    def log_api_call(
        self,
        method: str,
        url: str,
        status_code: int = None,
        response_time: float = None,
        headers: dict = None,
        payload: dict = None,
        response_data: dict = None,
    ):
        """Log API call details with full request/response information"""
        log_msg = f"API Call: {method} {url}"
        if status_code is not None:
            log_msg += f" - Status: {status_code}"
        if response_time is not None:
            log_msg += f" - Time: {response_time:.2f}s"
        log_msg += f" - intuit_tid: {self.execution_id}"
        self.logger.info(log_msg)

        # Log detailed request information
        if headers:
            sanitized_headers = self._sanitize_sensitive_data(headers)
            self.logger.debug(f"Request Headers: {sanitized_headers}")

        if payload:
            sanitized_payload = self._sanitize_sensitive_data(payload)
            self.logger.debug(f"Request Payload: {sanitized_payload}")

        if response_data:
            sanitized_response = self._sanitize_sensitive_data(response_data)
            self.logger.debug(f"Response Data: {sanitized_response}")

    def _sanitize_sensitive_data(self, data):
        """Remove or mask sensitive data from logs"""
        import json
        import re

        if isinstance(data, dict):
            sanitized = {}
            for key, value in data.items():
                key_lower = key.lower()
                if any(
                    sensitive in key_lower
                    for sensitive in [
                        "secret",
                        "password",
                        "token",
                        "key",
                        "auth",
                        "credential",
                    ]
                ):
                    if isinstance(value, str) and len(value) > 8:
                        # Show first 4 and last 4 characters, mask the middle
                        sanitized[key] = f"{value[:4]}***{value[-4:]}"
                    else:
                        sanitized[key] = "***HIDDEN***"
                elif isinstance(value, (dict, list)):
                    sanitized[key] = self._sanitize_sensitive_data(value)
                else:
                    sanitized[key] = value
            return sanitized
        elif isinstance(data, list):
            return [self._sanitize_sensitive_data(item) for item in data]
        elif isinstance(data, str):
            # Sanitize any potential secrets in string format
            # Look for patterns like app_secret=value or Authorization: Bearer token
            sanitized = re.sub(
                r"(app_secret|intuit_app_secret|Authorization|Bearer|token|secret|password)([=:]\s*)([^\s,&]+)",
                r"\1\2***HIDDEN***",
                data,
                flags=re.IGNORECASE,
            )
            return sanitized
        else:
            return data

    def log_file_operation(self, operation: str, file_path: str, success: bool = True):
        """Log file operations"""
        status = "SUCCESS" if success else "FAILED"
        self.logger.info(f"File Operation [{status}]: {operation} - {file_path}")

    def log_command_execution(
        self, command: list, exit_code: int = None, execution_time: float = None
    ):
        """Log command execution details"""
        cmd_str = " ".join(command) if isinstance(command, list) else str(command)
        log_msg = f"Command Execution: {cmd_str}"
        if exit_code is not None:
            log_msg += f" - Exit Code: {exit_code}"
        if execution_time is not None:
            log_msg += f" - Time: {execution_time:.2f}s"
        self.logger.info(log_msg)

    def make_api_call(
        self,
        method: str,
        url: str,
        headers: dict = None,
        json_data: dict = None,
        **kwargs,
    ):
        """Make an API call with enhanced logging"""
        import time

        import requests

        start_time = time.time()

        try:
            # Log the request
            self.logger.info(f"Making API call: {method} {url}")

            # Make the actual API call
            response = requests.request(
                method=method, url=url, headers=headers, json=json_data, **kwargs
            )

            end_time = time.time()
            response_time = end_time - start_time

            # Try to parse response as JSON
            try:
                response_data = response.json() if response.content else {}
            except:
                response_data = {
                    "raw_content": (
                        response.text[:500] + "..."
                        if len(response.text) > 500
                        else response.text
                    )
                }

            # Log the complete API call details
            self.log_api_call(
                method=method,
                url=url,
                status_code=response.status_code,
                response_time=response_time,
                headers=headers,
                payload=json_data,
                response_data=response_data,
            )

            return response

        except Exception as e:
            end_time = time.time()
            response_time = end_time - start_time

            self.logger.error(
                f"API call failed: {method} {url} - Error: {str(e)} - Time: {response_time:.2f}s"
            )
            self.log_api_call(
                method=method,
                url=url,
                status_code=None,
                response_time=response_time,
                headers=headers,
                payload=json_data,
                response_data={"error": str(e)},
            )
            raise


# Global logger instance
mcp_logger = MCPLogger()


def get_mcp_logger() -> MCPLogger:
    """Get the global MCP logger instance"""
    return mcp_logger


def log_mcp_command_start(command_name: str):
    """Log the start of an MCP command and display execution info"""
    logger = get_mcp_logger()
    logger.display_execution_info()  # Display only CLI version and execution ID
    logger.info(f"Command: {command_name}")  # Log command in file
    logger.info(f"Starting MCP command: {command_name}")


def log_mcp_command_end(command_name: str, success: bool = True):
    """Log the end of an MCP command"""
    logger = get_mcp_logger()
    status = "SUCCESS" if success else "FAILED"
    logger.info(f"MCP command completed [{status}]: {command_name}")


# Decorator for logging function calls
def log_function_calls(func):
    """Decorator to automatically log function entry and exit"""

    def wrapper(*args, **kwargs):
        logger = get_mcp_logger()
        func_name = func.__name__

        # Log function entry
        logger.log_function_entry(func_name, **kwargs)

        try:
            result = func(*args, **kwargs)
            logger.log_function_exit(func_name, result)
            return result
        except Exception as e:
            logger.exception(f"Exception in {func_name}: {str(e)}")
            raise

    return wrapper
