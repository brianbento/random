# mypy: ignore-errors
"""
Constants and configuration for MCP commands
"""

import os

# Repository URLs
PYTHON_TEMPLATE_REPO = (
    "git@github.intuit.com:platformexps-tools/mcp-starter-template-python.git"
)
NODE_TEMPLATE_REPO = (
    "git@github.intuit.com:platformexps-tools/mcp-starter-template-node.git"
)

AUTH_ENV = os.environ.get("AUTH_ENV", "prod")

# API URLs
MCP_BASE_URL = os.environ.get(
    "MCP_BASE_URL", "https://codeassist-essentials.api.intuit.com"
)
MCP_API_BASE_URL = f"{MCP_BASE_URL}/v1/mcp-servers"
MCP_API_V2_BASE_URL = f"{MCP_BASE_URL}/v2/mcp-servers/"
ANALYTICS_API_URL = f"{MCP_BASE_URL}/v1/analytics/events"

EVENTBUS_BASE_URL = os.environ.get(
    "EVENTBUS_BASE_URL", "https://eventbus.api.intuit.com"
)
EVENTBUS_MCP_DATA_USAGE_URL = f"{EVENTBUS_BASE_URL}/v2/mcp-data-usage"

# Remote MCP API Key
# Jenkins will replace prdakyresokiG4uaejOiNS2FYumiejhdzMlpe0Yx during build
# Local developers: this can be empty for development, or set via environment variable
REMOTE_MCP_API_KEY = os.environ.get(
    "REMOTE_MCP_API_KEY", "prdakyresokiG4uaejOiNS2FYumiejhdzMlpe0Yx"
)

# Marketplace API Key
# Jenkins will replace prdakyres3d97ohEsBpGOB8CPujMxESUfPJCRZVr during build
# Local developers: this can be empty for development, or set via environment variable
MARKETPLACE_API_KEY = os.environ.get(
    "MARKETPLACE_API_KEY", "prdakyres3d97ohEsBpGOB8CPujMxESUfPJCRZVr"
)

# Eventbus API Key
# Jenkins will replace prdakyreshr8oHeDZOa3kx6JIMxWcFvGO5E0Nu79 during build
# Local developers: this can be empty for development, or set via environment variable
EVENTBUS_API_KEY = os.environ.get("EVENTBUS_API_KEY", "prdakyreshr8oHeDZOa3kx6JIMxWcFvGO5E0Nu79")

# Language commands
LANGUAGE_COMMANDS = {"python": ["python", "python3"], "node": ["node"]}

# Environment variable prefixes for headless operation
ENV_PREFIX = "MCP_RELEASE_"
ENV_TOKEN = f"{ENV_PREFIX}TOKEN"
ENV_VERSION_TYPE = f"{ENV_PREFIX}VERSION_TYPE"
ENV_RUNTIME_PATH = f"{ENV_PREFIX}RUNTIME_PATH"
ENV_ENV_VARS = f"{ENV_PREFIX}ENV_VARS"  # JSON string of environment variables
ENV_ARGS = f"{ENV_PREFIX}ARGS"  # JSON string of arguments


# Event types for analytics
class EventType:
    INSTALL_MCP = "INSTALL_MCP"


# IDE settings paths
IDE_SETTINGS = {
    "cursor": {
        "path": os.path.expanduser("~/.cursor/mcp.json"),
        "json_path": "$.mcpServers",
        "name": "Cursor",
    },
    "qodo": {
        "path": os.path.expanduser(
            "~/Library/Application Support/Code/User/settings.json"
        ),
        "json_path": "$.mcpServers",
        "name": "Qodo (VSCode)",
    },
    "qodo_jetbrains": {
        "path": None,  # Will be dynamically determined during install/uninstall
        "xml_path": ".//application/component/option[@name='mcpServers']/map/entry[@value]",
        "name": "Qodo (JetBrains)",
    },
    "windsurf": {
        "path": os.path.expanduser("~/.codeium/windsurf/mcp_config.json"),
        "json_path": "$.mcpServers",
        "name": "Windsurf",
    },
    "augment": {
        "path": os.path.expanduser(
            "~/Library/Application Support/Code/User/globalStorage/augment.vscode-augment/augment-global-state/mcpServers.json"
        ),
        "json_path": "$",
        "name": "Augment (VSCode)",
        "array_format": True,  # Special flag to indicate this uses array format
    },
    "cline": {
        "path": os.path.expanduser(
            "~/Library/Application Support/Code/User/globalStorage/saoudrizwan.claude-dev/settings/cline_mcp_settings.json"
        ),
        "json_path": "$.mcpServers",
        "name": "Cline",
    },
}

# Icons
PYTHON_ICON = "🐍"
NODE_ICON = "📦"
SUCCESS_ICON = "✅"
ERROR_ICON = "❌"
INFO_ICON = "ℹ️"
WARNING_ICON = "⚠️"
TOOLS_ICON = "🛠️"
PROMPTS_ICON = "💬"
RESOURCES_ICON = "📚"
VERSION_ICON = "🏷️"
INIT_ICON = "✨"
RELEASE_ICON = "🚀"
INSTALL_ICON = "📥"
UNINSTALL_ICON = "🗑️"
IDE_ICON = "🖥️"
