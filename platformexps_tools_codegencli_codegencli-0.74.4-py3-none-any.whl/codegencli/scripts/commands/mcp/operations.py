# mypy: ignore-errors
"""
Core MCP operations: init, release, install, uninstall, run
"""

import os
import re
import subprocess
import sys
import threading

import click
import inquirer
from inquirer import Checkbox, List, Text
from rich import print as rprint
from rich.panel import Panel
from rich.progress import Progress, SpinnerColumn, TextColumn
from ruamel.yaml import YAML

from codegencli.scripts.services.secure_storage import (
    delete_mcp_credentials,
    get_all_args,
    get_all_env_vars,
    get_mcp_metadata,
    get_mcp_v2_metadata,
    list_installed_mcps,
)

from .constants import (
    ERROR_ICON,
    IDE_ICON,
    IDE_SETTINGS,
    INFO_ICON,
    INIT_ICON,
    NODE_ICON,
    PYTHON_ICON,
    SUCCESS_ICON,
    UNINSTALL_ICON,
    WARNING_ICON,
)
from .git_helpers import clone_template
from .ide_config import (
    find_jetbrains_settings_files,
    remove_jetbrains_settings_xml,
    remove_settings_json,
)
from .logging_helper import get_mcp_logger
from .utils import generate_nano_id, get_mcp_by_name, get_mcp_versions_v2, validate_name


def _log_subprocess_output(pipe, logger, log_level, prefix="", output_stream=None):
    """
    Helper function to read from subprocess pipe and log output in real-time

    Args:
        pipe: subprocess stdout or stderr pipe
        logger: MCPLogger instance
        log_level: logging level (info, error, etc.)
        prefix: prefix for log messages (e.g., "STDOUT", "STDERR")
        output_stream: sys.stdout or sys.stderr for terminal output
    """
    try:
        for line in iter(pipe.readline, b""):
            if line:
                decoded_line = line.decode("utf-8", errors="replace").rstrip()
                if decoded_line:  # Only log non-empty lines
                    # Log to file with prefix
                    log_message = (
                        f"{prefix}: {decoded_line}" if prefix else decoded_line
                    )
                    getattr(logger, log_level)(log_message)

                    # Also print to terminal for real-time feedback using the correct stream
                    if output_stream:
                        print(decoded_line, file=output_stream, flush=True)
    except Exception as e:
        logger.error(f"Error reading {prefix} pipe: {str(e)}")
    finally:
        pipe.close()


def _log_mcp_stderr_output(pipe, logger, prefix="", client_output_stream=None):
    """
    Helper function to handle MCP server stderr output.
    Logs stderr messages but never forwards them to the client.

    Args:
        pipe: subprocess stderr pipe
        logger: MCPLogger instance
        prefix: prefix for log messages (e.g., "DOCKER_STDERR")
        client_output_stream: Ignored - stderr is never forwarded to client
    """
    import json

    try:
        for line in iter(pipe.readline, b""):
            if line:
                decoded_line = line.decode("utf-8", errors="replace").rstrip()
                if decoded_line:
                    # Try to parse as JSON to detect structured logs
                    try:
                        json_msg = json.loads(decoded_line)
                        log_level = json_msg.get("level", "").upper()

                        # Log based on the level but never forward to client
                        if log_level in ["ERROR", "WARN"]:
                            logger.error(f"{prefix}: {decoded_line}")
                        else:
                            logger.info(f"{prefix}: {decoded_line}")

                    except json.JSONDecodeError:
                        # Not JSON, treat as regular stderr
                        # Check if it looks like a Docker pull message or other non-error output
                        lower_line = decoded_line.lower()
                        if any(
                            keyword in lower_line
                            for keyword in [
                                "pulling",
                                "download",
                                "pull complete",
                                "digest:",
                                "status:",
                                "warning: the requested image's platform",
                            ]
                        ):
                            # Docker pull messages - log as info
                            logger.info(f"{prefix}: {decoded_line}")
                        else:
                            # Actual error - log as error
                            logger.error(f"{prefix}: {decoded_line}")

    except Exception as e:
        logger.error(f"Error reading {prefix} pipe: {str(e)}")
    finally:
        pipe.close()


def update_manifest(name: str, description: str, language: str) -> bool:
    """Update the manifest.yaml file with the provided information"""
    manifest_path = "manifest.yaml"

    try:
        # Use ruamel.yaml instead of PyYAML to preserve comments
        yaml_parser = YAML()
        yaml_parser.preserve_quotes = True
        yaml_parser.indent(mapping=2, sequence=4, offset=2)

        if os.path.exists(manifest_path):
            with open(manifest_path, "r") as f:
                manifest = yaml_parser.load(f) or {}
        else:
            manifest = {}

        # Update the manifest
        manifest["name"] = name
        manifest["description"] = description
        manifest["language"] = language.lower()

        # Write updated manifest
        with open(manifest_path, "w") as f:
            yaml_parser.dump(manifest, f)

        return True
    except Exception as e:
        click.echo(f"Error updating manifest: {str(e)}")
        return False


def init_mcp():
    """Initialize an MCP service with boilerplate code"""
    logger = get_mcp_logger()
    logger.info("Starting MCP initialization")

    # Display a nice header
    rprint(f"{INIT_ICON} [bold]Initializing MCP service[/]\n")

    # 1. Choose language with inquirer
    language_choices = [
        {"name": f"{PYTHON_ICON} Python", "value": "python"},
        {"name": f"{NODE_ICON} NodeJs", "value": "node"},
    ]

    language_question = [
        List(
            "language",
            message="Select language",
            choices=[choice["name"] for choice in language_choices],
        ),
    ]

    language_answer = inquirer.prompt(language_question)
    # Handle if user cancels with Ctrl+C
    if not language_answer:
        logger.warning("MCP initialization cancelled by user during language selection")
        rprint(f"\n{WARNING_ICON} [yellow]Operation cancelled by user[/]")
        return

    selected_language = next(
        choice["value"]
        for choice in language_choices
        if choice["name"] == language_answer["language"]
    )
    logger.info(f"Selected language: {selected_language}")

    # 2. Enter and validate MCP name
    while True:
        name_question = [Text("name", message="Enter MCP service name")]
        name_answer = inquirer.prompt(name_question)
        # Handle if user cancels with Ctrl+C
        if not name_answer:
            rprint(f"\n{WARNING_ICON} [yellow]Operation cancelled by user[/]")
            return

        name = name_answer["name"]
        if validate_name(name):
            break

    # 3. Enter description
    description_question = [
        Text("description", message="Enter MCP service description")
    ]
    description_answer = inquirer.prompt(description_question)
    # Handle if user cancels with Ctrl+C
    if not description_answer:
        rprint(f"\n{WARNING_ICON} [yellow]Operation cancelled by user[/]")
        return

    description = description_answer["description"]

    # 4-6. Clone template and copy contents
    with Progress(
        SpinnerColumn(),
        TextColumn(f"[bold blue]Cloning {selected_language} template..."),
        transient=True,
    ) as progress:
        progress.add_task("clone", total=None)
        clone_success = clone_template(selected_language, os.getcwd())

    if not clone_success:
        rprint(f"{ERROR_ICON} [bold red]Failed to clone template repository[/]")
        return

    # 7. Update manifest.yaml
    with Progress(
        SpinnerColumn(),
        TextColumn("[bold blue]Updating manifest.yaml..."),
        transient=True,
    ) as progress:
        progress.add_task("update", total=None)
        manifest_success = update_manifest(name, description, selected_language)

    if not manifest_success:
        rprint(f"{ERROR_ICON} [bold red]Failed to update manifest.yaml[/]")
        return

    logger.info(
        f"MCP service '{name}' successfully initialized with language: {selected_language}"
    )

    rprint(
        f"\n{SUCCESS_ICON} [bold green]MCP service '{name}' successfully initialized![/]"
    )

    rprint(
        Panel.fit(
            "1. Customize your MCP implementation\n2. Commit and Push the changes.\n3. Run 'codegen mcp release' to release your MCP",
            title="[bold]Next Steps[/]",
            border_style="cyan",
        )
    )


def run_mcp_proxy(name: str, version: str = "latest"):
    """
    Run an MCP as a proxy.

    This function retrieves MCP configuration from secure storage and starts the MCP process
    with the stored credentials. It acts as a transparent proxy between the IDE and the actual MCP.

    Args:
        name: Name of the MCP
        version: Version of the MCP to run (default: "latest")
    """
    logger = get_mcp_logger()
    logger.info(f"Starting MCP proxy for: {name} version: {version}")

    # Get MCP metadata from secure storage
    metadata = get_mcp_metadata(name, version)
    if not metadata:
        logger.error(f"MCP '{name}' not found in secure storage")
        return

    # Extract paths from metadata
    command_path = metadata.get("command_path")
    script_path = metadata.get("script_path")

    if not command_path or not script_path:
        logger.error("Invalid MCP metadata")
        return

    # Update script path to use version-specific directory if needed
    if version != "latest" and script_path:
        # Construct version-specific path: ~/.intuit-mcp-marketplace/{name}/{version}/...
        marketplace_base_dir = os.path.join(
            os.path.expanduser("~"), ".intuit-mcp-marketplace"
        )
        # Extract relative path after the MCP name directory
        mcp_name_dir = os.path.join(marketplace_base_dir, name)
        if script_path.startswith(mcp_name_dir):
            # Replace with version-specific path
            relative_path = os.path.relpath(script_path, mcp_name_dir)
            if not relative_path.startswith(version):
                version_dir = os.path.join(marketplace_base_dir, name, version)
                script_path = os.path.join(version_dir, relative_path)

    # Verify paths exist
    if not os.path.exists(command_path):
        rprint(
            f"{ERROR_ICON} [bold red]Error: Runtime path not found: {command_path}[/]"
        )
        return

    if not os.path.exists(script_path):
        rprint(f"{ERROR_ICON} [bold red]Error: Script path not found: {script_path}[/]")
        return

    # Get environment variables and arguments from secure storage
    env_vars = get_all_env_vars(name, version)
    args = get_all_args(name, version)

    # Prepare command
    command = [command_path, script_path] + args

    # Prepare environment
    env = os.environ.copy()
    env.update(env_vars)

    try:
        # Start MCP process (no stdout messages for proxy mode)
        logger.info(f"Starting MCP process with command: {' '.join(command)}")
        logger.info(f"Environment variables: {list(env_vars.keys())}")
        logger.info(f"Arguments: {args}")

        # Use subprocess.Popen with pipes to capture output for logging
        # while still maintaining stdin for bidirectional communication
        process = subprocess.Popen(
            command,
            env=env,
            stdin=sys.stdin,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            bufsize=0,  # Unbuffered
        )

        # Start threads to handle stdout and stderr logging
        stdout_thread = threading.Thread(
            target=_log_subprocess_output,
            args=(process.stdout, logger, "info", "STDOUT", sys.stdout),
            daemon=True,
        )
        stderr_thread = threading.Thread(
            target=_log_subprocess_output,
            args=(process.stderr, logger, "error", "STDERR", sys.stderr),
            daemon=True,
        )

        stdout_thread.start()
        stderr_thread.start()

        # Wait for process to complete
        exit_code = process.wait()

        # Wait for logging threads to finish processing remaining output
        stdout_thread.join(timeout=1.0)
        stderr_thread.join(timeout=1.0)

        logger.info(f"MCP process completed with exit code: {exit_code}")

        if exit_code != 0:
            logger.error(f"MCP process failed with exit code: {exit_code}")
            return exit_code

        logger.info("MCP process completed successfully")
        return 0

    except Exception as e:
        logger.exception(f"Error running MCP: {str(e)}")
        return 1


def uninstall_mcp(name: str):
    """Uninstall an MCP service from selected IDEs"""
    # Display a nice header
    rprint(f"{UNINSTALL_ICON} [bold]Uninstalling MCP service: {name}[/]\n")

    # Lookup the MCP to get its ID for analytics
    mcp = get_mcp_by_name(name)
    mcp_id = mcp.get("id") if mcp else None

    # Select IDEs with checkboxes
    ide_choices = [
        {
            "name": f"{IDE_ICON} {IDE_SETTINGS[ide]['name']}",
            "value": ide,
        }
        for ide in IDE_SETTINGS.keys()
    ]

    ide_question = [
        Checkbox(
            "ides",
            message="Select IDEs to uninstall MCP from",
            choices=[choice["name"] for choice in ide_choices],
            default=[choice["name"] for choice in ide_choices],  # Select all by default
        )
    ]

    ide_answer = inquirer.prompt(ide_question)
    if not ide_answer:
        rprint(f"\n{WARNING_ICON} [yellow]Operation cancelled by user[/]")
        return

    selected_ides = [
        next(choice["value"] for choice in ide_choices if choice["name"] == ide_name)
        for ide_name in ide_answer["ides"]
    ]

    if not selected_ides:
        rprint(f"{WARNING_ICON} [yellow]No IDEs selected[/]")
        return

    # Remove MCP from settings files
    success_count = 0
    failed_ides = []

    with Progress(
        SpinnerColumn(),
        TextColumn("[bold blue]Removing MCP from IDE settings..."),
        transient=False,
    ) as progress:
        for ide in selected_ides:
            task = progress.add_task(
                f"Removing from {IDE_ICON} {IDE_SETTINGS[ide]['name']}...", total=1
            )

            # Special handling for JetBrains IDEs to show more detailed progress
            if ide.lower() == "qodo_jetbrains":
                settings_files = find_jetbrains_settings_files()
                if settings_files:
                    jetbrains_success, jetbrains_failed = remove_jetbrains_settings_xml(
                        name
                    )

                    if jetbrains_success > 0:
                        success_count += 1
                        progress.update(
                            task,
                            completed=1,
                            description=f"[green]✓[/] {IDE_ICON} {IDE_SETTINGS[ide]['name']} ({jetbrains_success} IDEs)",
                        )
                    else:
                        failed_ides.append(IDE_SETTINGS[ide]["name"])
                        progress.update(
                            task,
                            completed=1,
                            description=f"[red]✗[/] {IDE_ICON} {IDE_SETTINGS[ide]['name']}",
                        )
                else:
                    # No JetBrains settings files found
                    # Count as success since there's nothing to remove
                    success_count += 1
                    progress.update(
                        task,
                        completed=1,
                        description=f"[green]✓[/] {IDE_ICON} {IDE_SETTINGS[ide]['name']} (No IDEs found)",
                    )
            else:
                # Regular IDE handling
                if remove_settings_json(ide, name):
                    success_count += 1
                    progress.update(
                        task,
                        completed=1,
                        description=f"[green]✓[/] {IDE_ICON} {IDE_SETTINGS[ide]['name']}",
                    )
                else:
                    failed_ides.append(IDE_SETTINGS[ide]["name"])
                    progress.update(
                        task,
                        completed=1,
                        description=f"[red]✗[/] {IDE_ICON} {IDE_SETTINGS[ide]['name']}",
                    )

    # Clean up credentials from keychain
    with Progress(
        SpinnerColumn(),
        TextColumn(
            f"[bold blue]Removing credentials for '{name}' from secure storage..."
        ),
        transient=True,
    ) as progress:
        progress.add_task("cleanup", total=None)
        delete_result = delete_mcp_credentials(name)

    if delete_result:
        rprint(f"{SUCCESS_ICON} Credentials removed from secure storage")
    else:
        rprint(
            f"{WARNING_ICON} [yellow]Could not remove all credentials from secure storage[/]"
        )

    if success_count > 0:
        rprint(
            f"\n{SUCCESS_ICON} [bold green]MCP '{name}' successfully uninstalled from {success_count} IDE(s)[/]"
        )

        if failed_ides:
            rprint(
                f"{WARNING_ICON} [yellow]Failed to uninstall from: {', '.join(failed_ides)}[/]"
            )

        rprint(
            Panel.fit(
                "Please restart your IDE(s) to apply the changes",
                title="[bold]Next Steps[/]",
                border_style="cyan",
            )
        )
    else:
        rprint(f"{ERROR_ICON} [bold red]Failed to uninstall MCP from any IDEs[/]")


def list_mcps():
    """📋 List installed MCP services"""
    # Get all MCPs with their metadata
    mcps = list_installed_mcps()

    if not mcps:
        rprint(f"{INFO_ICON} No MCPs installed")
        return

    rprint(f"\n[bold]Installed MCP Services:[/]")

    for mcp_name in mcps:
        metadata = get_mcp_metadata(mcp_name)
        if metadata:
            command_path = metadata.get("command_path", "unknown")
            script_path = metadata.get("script_path", "unknown")

            # Display MCP info
            rprint(f"\n[bold cyan]{mcp_name}[/]")
            rprint(f"  Runtime: [green]{command_path}[/]")
            rprint(f"  Script: [green]{script_path}[/]")

            # Display environment variables (names only, not values)
            env_vars = metadata.get("env_var_names", [])
            if env_vars:
                rprint(f"  Environment Variables: [yellow]{', '.join(env_vars)}[/]")

            # Display argument names
            arg_names = metadata.get("arg_names", [])
            if arg_names:
                rprint(f"  Arguments: [yellow]{', '.join(arg_names)}[/]")


def run_mcp_v2_proxy(name: str, version: str = "latest"):
    """
    Run a v2 MCP using Docker or Podman (container runtime abstraction).

    This function retrieves v2 MCP configuration from secure storage and starts the MCP process
    using the available container runtime (Docker or Podman) with the stored credentials and
    environment variables.

    Args:
        name: Name of the MCP
        version: Version of the MCP to run (default: "latest")
    """
    from .utils import verify_container_runtime

    logger = get_mcp_logger()
    logger.info(f"Starting MCP proxy for: {name} version: {version}")

    # Verify container runtime (silent mode for proxy)
    success, runtime = verify_container_runtime(silent=True)
    if not success or not runtime:
        logger.error(
            "Container runtime (Docker or Podman) is required for this MCP but is not available"
        )
        return 1

    logger.info(f"Using container runtime: {runtime}")

    # Get v2 MCP metadata from secure storage
    metadata = get_mcp_v2_metadata(name, version)
    if not metadata:
        logger.error(f"MCP '{name}' not found in secure storage")
        return 1

    # Extract configuration from metadata
    image_name = metadata.get("image_name")
    env_vars = metadata.get("env", {})

    if not image_name:
        logger.error("No image found in MCP metadata")
        return 1

    is_databricks_mcp = name == "databricks-mcp"

    # Generate container name (static for databricks-mcp, random for others)
    if is_databricks_mcp:
        container_name = "databricks-mcp"
        port_args = ["-p", "8020:8020"]
    else:
        nano_id = generate_nano_id()
        container_name = f"{name}-{nano_id}"
        port_args = []

    # Prepare container command (using the detected runtime)
    container_cmd = [
        runtime,
        "run",
        "--rm",
        "-i",
    ]
    container_cmd.extend(port_args)

    container_cmd.extend(
        [
            "--name",
            container_name,
            "-v",
            f"{os.path.expanduser('~')}:/host-home",
            "-v",
            "/private/tmp:/host-tmp",
        ]
    )

    # For latest version, check if we need to pull updates
    if version == "latest":
        logger.info(f"Checking for updates for latest version of {name}")
        mcp_id = metadata.get("mcp_id")
        stored_commit_id = metadata.get("commit_id")
        logger.info(
            f"Stored metadata - mcp_id: {mcp_id}, commit_id: {stored_commit_id}"
        )

        mcp_details = get_mcp_versions_v2(mcp_id)
        if mcp_details:
            logger.info("Successfully fetched v2 MCP details")
            versions = mcp_details.get("versions", [])
            logger.info(f"Found {len(versions)} versions")

            # Find the current latest version
            latest_version = None
            for v in versions:
                if v.get("is_latest", False):
                    latest_version = v
                    logger.info(
                        f"Found latest version: {v.get('version')} with commit_id: {v.get('commit_id')}"
                    )
                    break

            if latest_version:
                latest_commit_id = latest_version.get("commit_id")
                logger.info(
                    f"Comparing commit IDs - stored: {stored_commit_id}, latest: {latest_commit_id}"
                )

                # If latest version commit differs from stored commit, force pull
                if latest_commit_id != stored_commit_id:
                    logger.info(f"Commit ID mismatch detected - forcing {runtime} pull")
                    container_cmd = [
                        runtime,
                        "run",
                        "--rm",
                        "-i",
                    ]
                    container_cmd.extend(port_args)

                    container_cmd.extend(
                        [
                            "--pull=always",
                            "--name",
                            container_name,
                            "-v",
                            f"{os.path.expanduser('~')}:/host-home",
                            "-v",
                            "/private/tmp:/host-tmp",
                        ]
                    )

                    # Update stored metadata with new commit ID
                    from codegencli.scripts.services.secure_storage import (
                        store_mcp_v2_metadata,
                    )

                    # Extract image name without tag for storage
                    image_name_without_tag = (
                        image_name.split(":")[0] if ":" in image_name else image_name
                    )

                    store_mcp_v2_metadata(
                        mcp_name=name,
                        image_name=image_name_without_tag,
                        env_vars=env_vars,
                        version=version,
                        mcp_id=mcp_id,
                        commit_id=latest_commit_id,
                    )
                    logger.info(f"Updated stored commit ID to: {latest_commit_id}")
                else:
                    logger.info("Commit IDs match - using cached image")
            else:
                logger.warning("No latest version found in API response")
        else:
            logger.warning(f"Failed to fetch v2 MCP details for mcp_id: {mcp_id}")

    # Add environment variables
    for env_name, env_value in env_vars.items():
        container_cmd.extend(["-e", f"{env_name}={env_value}"])

    # Add image name (assuming latest tag if no tag specified)
    if ":" not in image_name:
        image_name = f"{image_name}:latest"
    container_cmd.append(image_name)

    try:
        # For databricks-mcp, ensure any previously running (or exited) container with the same
        # name is removed so it can't block re-use of the name or host port 8020.
        if is_databricks_mcp:
            try:
                logger.info(f"Removing existing container '{container_name}'")
                subprocess.run(
                    [runtime, "rm", "-f", container_name],
                    stdout=subprocess.DEVNULL,
                    stderr=subprocess.DEVNULL,
                    timeout=30,
                )
            except subprocess.TimeoutExpired:
                logger.error(
                    f"Timed out removing existing container '{container_name}'. "
                    f"Please run manually: {runtime} rm -f {container_name}"
                )
                return 1
            except Exception as e:
                # Best-effort cleanup: ignore failures (container may not exist, runtime may deny, etc.)
                logger.info(f"Pre-start cleanup failed for {container_name}: {str(e)}")

        # Start MCP process (no stdout messages for proxy mode)
        logger.info(f"Starting MCP process with command: {' '.join(container_cmd)}")
        logger.info(f"Environment variables: {list(env_vars.keys())}")
        logger.info(f"Container name: {container_name}")
        logger.info(f"Container runtime: {runtime}")

        # Use subprocess.Popen with pipes to capture output for logging
        # while still maintaining stdin for bidirectional communication
        # For proxy mode, suppress container runtime's stderr to avoid interfering with MCP protocol
        with open(os.devnull, "w") as devnull:
            process = subprocess.Popen(
                container_cmd,
                stdin=sys.stdin,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                bufsize=0,  # Unbuffered
            )

            # Start threads to handle stdout and stderr logging
            # stdout goes to sys.stdout for MCP protocol, stderr is logged only
            runtime_label = runtime.upper()
            stdout_thread = threading.Thread(
                target=_log_subprocess_output,
                args=(
                    process.stdout,
                    logger,
                    "info",
                    f"{runtime_label}_STDOUT",
                    sys.stdout,
                ),
                daemon=True,
            )
            stderr_thread = threading.Thread(
                target=_log_mcp_stderr_output,
                args=(
                    process.stderr,
                    logger,
                    f"{runtime_label}_STDERR",
                    None,
                ),  # Don't forward stderr to client - only log it
                daemon=True,
            )

        stdout_thread.start()
        stderr_thread.start()

        # Wait for process to complete
        exit_code = process.wait()

        # Wait for logging threads to finish processing remaining output
        stdout_thread.join(timeout=1.0)
        stderr_thread.join(timeout=1.0)

        logger.info(f"MCP process completed with exit code: {exit_code}")

        if exit_code != 0:
            logger.error(f"MCP process failed with exit code: {exit_code}")
            return exit_code

        logger.info("MCP process completed successfully")
        return 0

    except KeyboardInterrupt:
        logger.info("MCP process interrupted by user")
        # Try to stop the container gracefully
        try:
            subprocess.run(
                [runtime, "stop", container_name], capture_output=True, timeout=10
            )
        except Exception:
            pass  # Container might already be stopped
        return 130  # Standard exit code for SIGINT
    except Exception as e:
        logger.exception(f"Error running MCP: {str(e)}")
        rprint(f"{ERROR_ICON} [bold red]Error running MCP: {str(e)}[/]")
        # Try to clean up container
        try:
            subprocess.run(
                [runtime, "stop", container_name], capture_output=True, timeout=5
            )
        except Exception:
            pass  # Container might not exist or already be stopped
        return 1
