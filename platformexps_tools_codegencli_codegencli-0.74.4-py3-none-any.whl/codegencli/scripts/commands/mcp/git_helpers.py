# mypy: ignore-errors
"""
Git-related helper functions for MCP operations
"""

import os
import shutil
import subprocess
import tempfile
import typing

import click
from git import Repo
from rich import print as rprint

from .constants import ERROR_ICON, SUCCESS_ICON


def convert_git_url_to_https(url: str) -> str:
    """Convert SSH Git URL to HTTPS format if needed"""
    if url.startswith("git@"):
        # SSH format: git@github.intuit.com:username/repo.git
        # Convert to: https://github.intuit.com/username/repo.git
        parts = url.split(":")
        if len(parts) == 2:
            domain = parts[0].replace("git@", "")
            repo_path = parts[1]
            return f"https://{domain}/{repo_path}"
    return url  # Return original URL if not SSH format or conversion failed


def convert_git_url_to_ssh(url: str) -> str:
    """Convert HTTPS Git URL to SSH format if needed"""
    if url.startswith("https://"):
        # HTTPS format: https://github.intuit.com/username/repo.git
        # Convert to: git@github.intuit.com:username/repo.git
        url_without_protocol = url.replace("https://", "")
        parts = url_without_protocol.split("/", 1)
        if len(parts) == 2:
            domain = parts[0]
            repo_path = parts[1]
            return f"git@{domain}:{repo_path}"
    return url  # Return original URL if not HTTPS format or conversion failed


def clone_git_repository_with_fallback(
    git_repo_url: str, target_dir: str, progress_callback=None
) -> bool:
    """
    Clone a git repository with fallback logic:
    1. If SSH format: try SSH first, then fallback to HTTPS
    2. If HTTPS format: convert to SSH and try SSH first, then fallback to HTTPS
    3. If SSH fails, try HTTPS as fallback

    Args:
        git_repo_url: The git repository URL (SSH or HTTPS format)
        target_dir: The target directory to clone into
        progress_callback: Optional callback function to show progress

    Returns:
        bool: True if clone was successful, False otherwise
    """
    try:
        if git_repo_url.startswith("git@"):
            # SSH format - proceed to clone directly
            try:
                Repo.clone_from(git_repo_url, target_dir)
                return True
            except Exception as ssh_e:
                error_str = str(ssh_e)
                # Check if the error is related to SSH authentication
                if "Permission denied (publickey)" in error_str:
                    # Try with HTTPS URL instead
                    https_url = convert_git_url_to_https(git_repo_url)
                    if https_url != git_repo_url:
                        if progress_callback:
                            progress_callback()
                        try:
                            Repo.clone_from(https_url, target_dir)
                            return True
                        except Exception:
                            # Both SSH and HTTPS failed
                            return False
                return False
        elif git_repo_url.startswith("https://"):
            # HTTPS format - convert to SSH and try SSH first
            ssh_url = convert_git_url_to_ssh(git_repo_url)
            try:
                Repo.clone_from(ssh_url, target_dir)
                return True
            except Exception:
                # SSH failed, proceed to clone with HTTPS
                if progress_callback:
                    progress_callback()
                try:
                    Repo.clone_from(git_repo_url, target_dir)
                    return True
                except Exception:
                    return False
        else:
            # Unknown format, try as-is
            try:
                Repo.clone_from(git_repo_url, target_dir)
                return True
            except Exception:
                return False
    except Exception:
        return False


def clone_template(language: str, target_dir: str) -> bool:
    """Clone the template repository based on the selected language"""
    from .constants import NODE_TEMPLATE_REPO, PYTHON_TEMPLATE_REPO

    repo_url = (
        PYTHON_TEMPLATE_REPO if language.lower() == "python" else NODE_TEMPLATE_REPO
    )

    try:
        with tempfile.TemporaryDirectory() as temp_dir:
            # Use the new fallback logic
            def progress_callback():
                click.echo(f"Cloning template...")

            success = clone_git_repository_with_fallback(
                repo_url, temp_dir, progress_callback
            )

            if success:
                click.echo(f"Successfully cloned template")

                # Copy all files except .git
                for item in os.listdir(temp_dir):
                    if item != ".git":
                        s = os.path.join(temp_dir, item)
                        d = os.path.join(target_dir, item)
                        if os.path.isdir(s):
                            shutil.copytree(s, d, dirs_exist_ok=True)
                        else:
                            shutil.copy2(s, d)

                return True
            else:
                click.echo(f"Error cloning template repository")
                return False

    except Exception as e:
        # Catch any other unexpected errors
        click.echo(f"Error cloning template: {str(e)}")
        return False


def is_git_repo(path: str) -> bool:
    """Check if the directory is a git repository"""
    try:
        Repo(path)
        return True
    except Exception:
        return False


def get_repo_url() -> typing.Optional[str]:
    """Get the git repository URL"""
    try:
        repo = Repo(".")
        remote_url = repo.remotes.origin.url
        return remote_url
    except Exception as e:
        click.echo(f"Error getting repository URL: {str(e)}")
        return None


def get_current_commit() -> typing.Optional[str]:
    """Get the current commit ID"""
    try:
        repo = Repo(".")
        return repo.head.commit.hexsha
    except Exception as e:
        click.echo(f"Error getting current commit: {str(e)}")
        return None
