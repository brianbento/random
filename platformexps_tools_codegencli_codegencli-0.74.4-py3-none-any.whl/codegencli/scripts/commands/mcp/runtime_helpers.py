# mypy: ignore-errors
"""
Runtime detection and management for MCP operations
"""

import os
import shutil
import subprocess
import typing
import venv
from typing import Dict, Optional, Tuple

import inquirer
from inquirer import List
from rich import print as rprint
from rich.progress import Progress, SpinnerColumn, TextColumn

from .constants import (
    ENV_RUNTIME_PATH,
    ERROR_ICON,
    INFO_ICON,
    LANGUAGE_COMMANDS,
    SUCCESS_ICON,
    WARNING_ICON,
)


def find_available_command(commands: typing.List[str]) -> Optional[str]:
    """Find the first available command from the list"""
    for cmd in commands:
        try:
            result = subprocess.run(["which", cmd], capture_output=True, text=True)
            if result.returncode == 0 and result.stdout.strip():
                return result.stdout.strip()
        except Exception:
            continue
    return None


def find_all_runtime_paths(language: str) -> typing.List[Dict[str, str]]:
    """Find all available runtime paths for a given language

    Args:
        language: The language to find runtimes for ('python' or 'node')

    Returns:
        A list of dictionaries with 'path' and 'version' information
    """
    runtimes = []
    language_cmds = LANGUAGE_COMMANDS.get(language.lower(), [])

    for cmd in language_cmds:
        try:
            # Find all instances of the command
            result = subprocess.run(
                ["which", "-a", cmd], capture_output=True, text=True
            )
            if result.returncode == 0 and result.stdout.strip():
                paths = result.stdout.strip().split("\n")

                # Get version info for each instance
                for path in paths:
                    try:
                        if language.lower() == "python":
                            version_result = subprocess.run(
                                [path, "--version"], capture_output=True, text=True
                            )
                            version = (
                                version_result.stdout.strip()
                                or version_result.stderr.strip()
                            )
                            # Test if runtime can be executed
                            test_result = subprocess.run(
                                [
                                    path,
                                    "-c",
                                    "print('test')",
                                ],
                                capture_output=True,
                                text=True,
                            )
                        else:  # Node.js
                            version_result = subprocess.run(
                                [path, "--version"], capture_output=True, text=True
                            )
                            version = version_result.stdout.strip()
                            # Test if runtime can be executed
                            test_result = subprocess.run(
                                [
                                    path,
                                    "-e",
                                    "console.log('test')",
                                ],
                                capture_output=True,
                                text=True,
                            )
                        is_working = test_result.returncode == 0

                        if is_working:
                            runtimes.append(
                                {
                                    "path": path,
                                    "version": version,
                                    "display": f"{os.path.basename(path)} ({version})",
                                }
                            )
                    except Exception:
                        # Skip this runtime if we can't get version or test it
                        continue
        except Exception:
            continue

    # For Node.js, also check for NVM and other version managers
    if language.lower() == "node":
        runtimes.extend(_find_nvm_node_versions())
        runtimes.extend(_find_n_node_versions())

    # Remove duplicates based on path
    seen_paths = set()
    unique_runtimes = []
    for runtime in runtimes:
        if runtime["path"] not in seen_paths:
            seen_paths.add(runtime["path"])
            unique_runtimes.append(runtime)

    # Sort by version (higher versions first)
    unique_runtimes.sort(key=lambda x: x["path"], reverse=True)
    return unique_runtimes


def _find_nvm_node_versions() -> typing.List[Dict[str, str]]:
    """Find all Node.js versions installed via NVM"""
    nvm_versions = []

    # Common NVM installation paths
    nvm_paths = [
        os.path.expanduser("~/.nvm/versions/node"),
        os.path.expanduser("~/.nvm/versions/node/*/bin/node"),
    ]

    # Check if NVM_DIR is set
    nvm_dir = os.environ.get("NVM_DIR")
    if nvm_dir:
        nvm_paths.append(os.path.join(nvm_dir, "versions/node"))

    for nvm_path in nvm_paths:
        if os.path.exists(nvm_path):
            try:
                # Find all version directories
                for version_dir in os.listdir(nvm_path):
                    version_path = os.path.join(nvm_path, version_dir)
                    if os.path.isdir(version_path):
                        node_path = os.path.join(version_path, "bin", "node")
                        if os.path.exists(node_path) and os.access(node_path, os.X_OK):
                            try:
                                # Get version info
                                version_result = subprocess.run(
                                    [node_path, "--version"],
                                    capture_output=True,
                                    text=True,
                                )
                                if version_result.returncode == 0:
                                    version = version_result.stdout.strip()
                                    # Test if runtime can be executed
                                    test_result = subprocess.run(
                                        [node_path, "-e", "console.log('test')"],
                                        capture_output=True,
                                        text=True,
                                    )
                                    if test_result.returncode == 0:
                                        nvm_versions.append(
                                            {
                                                "path": node_path,
                                                "version": version,
                                                "display": f"node ({version_dir}) - NVM",
                                            }
                                        )
                            except Exception:
                                continue
            except Exception:
                continue

    return nvm_versions


def _find_n_node_versions() -> typing.List[Dict[str, str]]:
    """Find all Node.js versions installed via 'n' version manager"""
    n_versions = []

    # Common 'n' installation paths
    n_paths = [
        "/usr/local/n/versions/node",
        "/opt/n/versions/node",
    ]

    for n_path in n_paths:
        if os.path.exists(n_path):
            try:
                # Find all version directories
                for version_dir in os.listdir(n_path):
                    version_path = os.path.join(n_path, version_dir)
                    if os.path.isdir(version_path):
                        node_path = os.path.join(version_path, "bin", "node")
                        if os.path.exists(node_path) and os.access(node_path, os.X_OK):
                            try:
                                # Get version info
                                version_result = subprocess.run(
                                    [node_path, "--version"],
                                    capture_output=True,
                                    text=True,
                                )
                                if version_result.returncode == 0:
                                    version = version_result.stdout.strip()
                                    # Test if runtime can be executed
                                    test_result = subprocess.run(
                                        [node_path, "-e", "console.log('test')"],
                                        capture_output=True,
                                        text=True,
                                    )
                                    if test_result.returncode == 0:
                                        n_versions.append(
                                            {
                                                "path": node_path,
                                                "version": version,
                                                "display": f"node ({version_dir}) - n",
                                            }
                                        )
                            except Exception:
                                continue
            except Exception:
                continue

    return n_versions


def select_runtime(language: str, headless: bool = False) -> Optional[str]:
    """Present available runtimes to user and let them select one

    Args:
        language: The language to find runtimes for ('python' or 'node')
        headless: If True, only check environment variables, don't prompt

    Returns:
        The selected runtime path or None if no runtime is available/selected
    """
    # Check environment variable first
    env_runtime_path = os.environ.get(ENV_RUNTIME_PATH)
    if env_runtime_path:
        # Validate that the runtime path exists and is executable
        if os.path.exists(env_runtime_path) and os.access(env_runtime_path, os.X_OK):
            rprint(
                f"{INFO_ICON} Using runtime path from environment: [bold cyan]{env_runtime_path}[/]"
            )
            return env_runtime_path
        else:
            rprint(
                f"{WARNING_ICON} [yellow]Runtime path from {ENV_RUNTIME_PATH} is not executable: {env_runtime_path}[/]"
            )
            if headless:
                rprint(
                    f"{ERROR_ICON} [bold red]Environment variable {ENV_RUNTIME_PATH} points to non-executable file[/]"
                )
                return None

    runtimes = find_all_runtime_paths(language)

    if not runtimes:
        rprint(
            f"{ERROR_ICON} [bold red]Error: No {language} runtimes found on your system[/]"
        )
        return None

    if len(runtimes) == 1:
        # If only one runtime is available, use it without asking
        runtime_path = runtimes[0]["path"]
        rprint(
            f"{INFO_ICON} Using {language} runtime: [bold cyan]{runtime_path}[/] ({runtimes[0]['version']})"
        )
        return runtime_path

    # If headless mode and no environment variable, fail
    if headless:
        rprint(
            f"{ERROR_ICON} [bold red]Environment variable {ENV_RUNTIME_PATH} is required for headless mode with multiple runtimes[/]"
        )
        rprint(f"{INFO_ICON} Available runtimes:")
        for runtime in runtimes:
            rprint(f"  [cyan]•[/] {runtime['display']} - {runtime['path']}")
        return None

    # Let user choose from multiple runtimes
    runtime_choices = [
        {"name": f"{r['display']} - {r['path']}", "value": r["path"]} for r in runtimes
    ]

    runtime_question = [
        List(
            "runtime",
            message=f"Select {language} runtime to use",
            choices=[choice["name"] for choice in runtime_choices],
        )
    ]

    runtime_answer = inquirer.prompt(runtime_question)
    if not runtime_answer:
        rprint(f"\n{WARNING_ICON} [yellow]Operation cancelled by user[/]")
        return None

    selected_runtime = next(
        choice["value"]
        for choice in runtime_choices
        if choice["name"] == runtime_answer["runtime"]
    )

    return selected_runtime


def create_or_reuse_venv(venv_path: str, python_path: str) -> Optional[str]:
    """
    Create a new virtual environment or reuse an existing one

    Args:
        venv_path: Path where the venv should be created
        python_path: Path to the Python executable to use for creating the venv

    Returns:
        Path to the venv's bin directory (containing python, pip, etc.) or None if failed
    """
    venv_bin_dir = os.path.join(venv_path, "bin")
    venv_python = os.path.join(venv_bin_dir, "python")

    # Check if venv already exists
    if os.path.exists(venv_python):
        rprint(
            f"{INFO_ICON} Using existing virtual environment at [cyan]{venv_path}[/]"
        )
        return venv_bin_dir

    # Create venv directory if it doesn't exist
    os.makedirs(os.path.dirname(venv_path), exist_ok=True)

    # Create a new venv
    try:
        rprint(f"{INFO_ICON} Creating new virtual environment at [cyan]{venv_path}[/]")
        venv.create(venv_path, with_pip=True, symlinks=True, clear=True)
        return venv_bin_dir
    except Exception as e:
        rprint(
            f"{ERROR_ICON} [bold red]Error creating virtual environment: {str(e)}[/]"
        )
        return None


def get_node_package_manager(project_dir: str) -> Tuple[str, str]:
    """
    Determine which Node.js package manager to use based on lock files present

    Args:
        project_dir: Directory containing the Node.js project

    Returns:
        Tuple[str, str]: (package_manager_name, package_manager_path)
    """
    yarn_lock_path = os.path.join(project_dir, "yarn.lock")
    package_lock_path = os.path.join(project_dir, "package-lock.json")

    # Check for yarn.lock first (yarn takes precedence)
    if os.path.exists(yarn_lock_path):
        # Use system default yarn, don't check PATH
        return "yarn", "yarn"

    # Fall back to npm
    npm_path = shutil.which("npm")
    if npm_path:
        return "npm", npm_path

    return None, None


def install_in_venv(venv_bin_dir: str, requirements_file: str) -> bool:
    """
    Install requirements in a virtual environment

    Args:
        venv_bin_dir: Path to the venv's bin directory
        requirements_file: Path to the requirements.txt file

    Returns:
        True if installation was successful, False otherwise
    """
    venv_pip = os.path.join(venv_bin_dir, "pip")

    try:
        with Progress(
            SpinnerColumn(),
            TextColumn(
                "[bold blue]Installing Python dependencies in virtual environment..."
            ),
            transient=True,
        ) as progress:
            progress.add_task("install", total=None)
            subprocess.run(
                [venv_pip, "install", "-r", requirements_file],
                check=True,
                capture_output=True,
            )
        rprint(
            f"{SUCCESS_ICON} [bold green]Dependencies installed successfully in virtual environment[/]"
        )
        return True
    except subprocess.CalledProcessError as e:
        rprint(
            f"{WARNING_ICON} [yellow]Error installing dependencies in virtual environment: {e}[/]"
        )
        rprint(
            f"{INFO_ICON} Continuing with installation, but some dependencies may be missing"
        )
        return False
