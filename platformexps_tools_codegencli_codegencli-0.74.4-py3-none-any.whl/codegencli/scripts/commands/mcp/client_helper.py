# mypy: ignore-errors
"""
MCP client helper for connecting to MCP servers
"""

import typing
from contextlib import AsyncExitStack
from typing import Dict, Optional

from rich import print as rprint
from rich.panel import Panel
from rich.progress import Progress, SpinnerColumn, TextColumn

from .constants import (
    ERROR_ICON,
    PROMPTS_ICON,
    RESOURCES_ICON,
    SUCCESS_ICON,
    TOOLS_ICON,
    WARNING_ICON,
)

# Import MCP only when needed to avoid issues with proxy commands
try:
    from mcp import ClientSession, StdioServerParameters
    from mcp.client.stdio import stdio_client

    MCP_AVAILABLE = True
except ImportError:
    MCP_AVAILABLE = False
    ClientSession = None
    StdioServerParameters = None
    stdio_client = None


# Helper class for MCP client connection
class MCPClientHelper:
    """Helper class to connect to an MCP server and extract tools, prompts, and resources"""

    def __init__(self):
        self.session = None
        self.exit_stack = None
        self.tools = []
        self.prompts = []
        self.resources = []

    async def connect_to_server(
        self,
        server_script_path: str,
        env_vars: Optional[Dict[str, str]] = None,
        cli_args: Optional[typing.List[str]] = None,
        command_path: Optional[str] = None,
    ):
        """Connect to an MCP server

        Args:
            server_script_path: Path to the server script (.py or .js)
            env_vars: Optional environment variables to pass to the server
            cli_args: Optional command line arguments with double hyphens (e.g. "--arg=value")
            command_path: Optional pre-selected runtime command path
        """
        try:
            is_python = server_script_path.endswith(".py")
            is_js = server_script_path.endswith(".js")

            if not (is_python or is_js):
                rprint(f"{ERROR_ICON} Invalid script type")
                raise ValueError("Server script must be a .py or .js file")

            # Find the appropriate runtime command path
            language = "python" if is_python else "node"

            # Use provided command_path or select a runtime
            if not command_path:
                from .runtime_helpers import select_runtime

                command_path = select_runtime(language)

            if not command_path:
                raise ValueError(
                    f"Could not find a suitable {language} runtime on your system"
                )

            # Prepare arguments list
            args = [server_script_path]
            if cli_args:
                args.extend(cli_args)

            # Construct server parameters
            server_params = StdioServerParameters(
                command=command_path, args=args, env=env_vars
            )

            with Progress(
                SpinnerColumn(),
                TextColumn("[bold blue]Connecting to MCP server..."),
                transient=True,
            ) as progress:
                progress.add_task("connect", total=None)

                self.exit_stack = AsyncExitStack()
                stdio_transport = await self.exit_stack.enter_async_context(
                    stdio_client(server_params)
                )
                stdio, write = stdio_transport
                self.session = await self.exit_stack.enter_async_context(
                    ClientSession(stdio, write)
                )

                # Ensure session is not None before using
                if self.session is None:
                    raise RuntimeError("Failed to initialize MCP client session")

                await self.session.initialize()

                # List available tools
                try:
                    tools_response = await self.session.list_tools()
                    self.tools = tools_response.tools
                except Exception as e:
                    tools_response = []
                    self.tools = []

                # List available prompts
                try:
                    prompts_response = await self.session.list_prompts()
                    self.prompts = prompts_response.prompts
                except Exception as e:
                    rprint(f"{WARNING_ICON} Failed to retrieve prompts list: {e}")
                    prompts_response = []
                    self.prompts = []

                # List available resources
                try:
                    resources_response = await self.session.list_resources()
                    self.resources = resources_response.resources
                except Exception as e:
                    rprint(f"{WARNING_ICON} Failed to retrieve resources list: {e}")
                    resources_response = []
                    self.resources = []

            rprint(
                Panel.fit(
                    f"{TOOLS_ICON} [bold cyan]Tools:[/] {len(self.tools)}  "
                    f"{PROMPTS_ICON} [bold magenta]Prompts:[/] {len(self.prompts)}  "
                    f"{RESOURCES_ICON} [bold green]Resources:[/] {len(self.resources)}",
                    title="[bold]MCP Server Connected[/]",
                    border_style="green",
                )
            )

        except ImportError as e:
            rprint(f"{ERROR_ICON} [bold red]Missing required libraries:[/] {e}")
            raise ImportError(f"Missing required libraries: {e}.") from e
        except Exception as e:
            rprint(f"{ERROR_ICON} [bold red]Error connecting to MCP server:[/] {e}")
            raise Exception(f"Error connecting to MCP server: {e}") from e

    async def disconnect(self):
        """Disconnect from the MCP server"""
        if self.exit_stack:
            await self.exit_stack.aclose()
            self.exit_stack = None
            self.session = None

    def get_info(self) -> Dict[str, typing.List[Dict[str, str]]]:
        """Get the tools, prompts, and resources information"""
        return {
            "tools": [
                {
                    "name": getattr(t, "name", ""),
                    "description": getattr(t, "description", ""),
                }
                for t in self.tools
            ],
            "prompts": [
                {
                    "name": getattr(p, "name", ""),
                    "description": getattr(p, "description", ""),
                }
                for p in self.prompts
            ],
            "resources": [
                {
                    "uri": str(getattr(r, "uri", "")),
                    "name": getattr(r, "name", ""),
                    "description": getattr(r, "description", ""),
                    "mime_type": getattr(r, "mime_type", ""),
                }
                for r in self.resources
            ],
        }
