# mypy: ignore-errors
"""
IDE configuration management for MCP installations
"""

import glob
import json
import os
import typing
import uuid
import xml.etree.ElementTree as ET
from typing import Dict, Tuple

import click
from rich import print as rprint

from .constants import ERROR_ICON, IDE_SETTINGS, WARNING_ICON


def update_augment_array_format(
    file_path: str,
    mcp_name: str,
    command: str,
    env_vars: Dict[str, str],
    args: typing.List[str],
) -> bool:
    """Update the Augment array format configuration file"""
    try:
        # Create parent directories if they don't exist
        os.makedirs(os.path.dirname(file_path), exist_ok=True)

        # Load existing settings or create new array
        if os.path.exists(file_path) and os.path.getsize(file_path) > 0:
            with open(file_path, "r") as f:
                try:
                    mcp_servers = json.load(f)
                    if not isinstance(mcp_servers, list):
                        mcp_servers = []
                except json.JSONDecodeError:
                    mcp_servers = []
        else:
            mcp_servers = []

        # Remove existing entry with the same name if it exists
        mcp_servers = [
            server for server in mcp_servers if server.get("name") != mcp_name
        ]

        # For Augment, concatenate ALL arguments to the command string with spaces
        # and set arguments to empty string
        if args and len(args) > 0:
            # Combine command with ALL arguments separated by spaces
            augment_command = f"{command} {' '.join(args)}"
        else:
            augment_command = command

        # For Augment, arguments should always be an empty string
        augment_arguments_string = ""

        # Create new MCP server configuration
        new_server = {
            "name": mcp_name,
            "command": augment_command,
            "arguments": augment_arguments_string,
            "useShellInterpolation": True,
            "id": str(uuid.uuid4()),
            "tools": [],
            "env": env_vars,
        }

        # Add the new server to the array
        mcp_servers.append(new_server)

        # Write updated settings
        with open(file_path, "w") as f:
            json.dump(mcp_servers, f, indent=2)

        return True
    except Exception as e:
        click.echo(f"Error updating Augment array format: {str(e)}")
        return False


def remove_augment_array_format(file_path: str, mcp_name: str) -> bool:
    """Remove an MCP server from the Augment array format configuration file"""
    try:
        # Check if file exists
        if not os.path.exists(file_path):
            rprint(f"{WARNING_ICON} [yellow]Settings file not found for Augment[/]")
            return True  # Return True as the MCP is effectively removed

        # Load existing settings
        with open(file_path, "r") as f:
            try:
                mcp_servers = json.load(f)
                if not isinstance(mcp_servers, list):
                    rprint(f"{WARNING_ICON} [yellow]Invalid file format for Augment[/]")
                    return True
            except json.JSONDecodeError:
                rprint(f"{WARNING_ICON} [yellow]Invalid JSON format for Augment[/]")
                return True

        # Remove the MCP server with the matching name
        original_count = len(mcp_servers)
        mcp_servers = [
            server for server in mcp_servers if server.get("name") != mcp_name
        ]

        if len(mcp_servers) == original_count:
            rprint(
                f"{WARNING_ICON} [yellow]MCP '{mcp_name}' not found in Augment settings[/]"
            )
            return True  # Return True as the MCP is effectively removed

        # Write updated settings
        with open(file_path, "w") as f:
            json.dump(mcp_servers, f, indent=2)

        return True
    except Exception as e:
        click.echo(f"Error removing from Augment array format: {str(e)}")
        return False


def update_settings_json(
    ide: str,
    mcp_name: str,
    command: str,
    env_vars: Dict[str, str],
    args: typing.List[str],
) -> bool:
    """Update the settings.json file for a specific IDE"""
    # Special case for JetBrains IDEs
    if ide.lower() == "qodo_jetbrains":
        success_count, failed_count = update_jetbrains_settings_xml(
            mcp_name, command, env_vars, args
        )
        # Return True if at least one file was updated successfully
        return success_count > 0

    ide_info = IDE_SETTINGS.get(ide.lower())
    if not ide_info:
        click.echo(f"Unknown IDE: {ide}")
        return False

    file_path = ide_info["path"]

    # Special case for Augment array format
    if ide_info.get("array_format"):
        return update_augment_array_format(file_path, mcp_name, command, env_vars, args)

    json_path = ide_info["json_path"]

    # Parse JSON path to determine nesting
    path_parts = json_path[2:].split(".")

    try:
        # Create parent directories if they don't exist
        os.makedirs(os.path.dirname(file_path), exist_ok=True)

        # Load existing settings or create new
        if os.path.exists(file_path):
            with open(file_path, "r") as f:
                settings = json.load(f)
        else:
            settings = {}

        # Navigate to the correct nesting level
        current = settings
        for i, part in enumerate(path_parts[:-1]):
            if part not in current:
                current[part] = {}
            current = current[part]

        # Add or update the MCP server
        last_part = path_parts[-1]
        if last_part not in current:
            current[last_part] = {}

        # Add or update the MCP configuration
        current[last_part][mcp_name] = {
            "command": command,
            "env": env_vars,
            "args": args,
        }

        # Write updated settings
        with open(file_path, "w") as f:
            json.dump(settings, f, indent=2)

        return True
    except Exception as e:
        click.echo(f"Error updating settings for {ide}: {str(e)}")
        return False


def remove_settings_json(
    ide: str,
    mcp_name: str,
) -> bool:
    """Remove the MCP entry from the settings.json file for a specific IDE"""
    # Special case for JetBrains IDEs
    if ide.lower() == "qodo_jetbrains":
        success_count, failed_count = remove_jetbrains_settings_xml(mcp_name)
        # Return True if at least one file was updated successfully
        return success_count > 0

    ide_info = IDE_SETTINGS.get(ide.lower())
    if not ide_info:
        click.echo(f"Unknown IDE: {ide}")
        return False

    file_path = ide_info["path"]

    # Special case for Augment array format
    if ide_info.get("array_format"):
        return remove_augment_array_format(file_path, mcp_name)

    json_path = ide_info["json_path"]

    # Parse JSON path to determine nesting
    path_parts = json_path[2:].split(".")

    try:
        # Check if file exists
        if not os.path.exists(file_path):
            rprint(
                f"{WARNING_ICON} [yellow]Settings file not found for {ide_info['name']}[/]"
            )
            return True  # Return True as the MCP is effectively removed

        # Load existing settings
        with open(file_path, "r") as f:
            settings = json.load(f)

        # Navigate to the correct nesting level
        current = settings
        for i, part in enumerate(path_parts[:-1]):
            if part not in current:
                rprint(
                    f"{WARNING_ICON} [yellow]Settings path not found for {ide_info['name']}[/]"
                )
                return True  # Return True as the MCP is effectively removed
            current = current[part]

        # Remove the MCP server
        last_part = path_parts[-1]
        if last_part not in current:
            rprint(
                f"{WARNING_ICON} [yellow]MCP settings not found for {ide_info['name']}[/]"
            )
            return True  # Return True as the MCP is effectively removed

        # Check if the MCP exists in the settings
        if mcp_name not in current[last_part]:
            rprint(
                f"{WARNING_ICON} [yellow]MCP '{mcp_name}' not found in {ide_info['name']} settings[/]"
            )
            return True  # Return True as the MCP is effectively removed

        # Remove the MCP configuration
        del current[last_part][mcp_name]

        # Write updated settings
        with open(file_path, "w") as f:
            json.dump(settings, f, indent=2)

        return True
    except Exception as e:
        click.echo(f"Error removing settings for {ide}: {str(e)}")
        return False


# JetBrains IDEs settings location
def find_jetbrains_settings_files() -> typing.List[str]:
    """Find all JetBrains IDEs codiumai.settings.xml files"""
    user_dir = os.path.expanduser("~")
    jetbrains_base_dir = os.path.join(
        user_dir, "Library", "Application Support", "JetBrains"
    )

    if not os.path.exists(jetbrains_base_dir):
        rprint(
            f"{WARNING_ICON} [yellow]JetBrains settings directory not found at {jetbrains_base_dir}[/]"
        )
        return []

    settings_files = []
    # Search for all IDEs under JetBrains directory
    for ide_dir in glob.glob(f"{jetbrains_base_dir}/*"):
        if os.path.isdir(ide_dir):
            options_dir = os.path.join(ide_dir, "options")
            if os.path.isdir(options_dir):
                settings_file = os.path.join(options_dir, "codiumai.settings.xml")
                if os.path.exists(settings_file):
                    settings_files.append(settings_file)

    return settings_files


def update_jetbrains_settings_xml(
    mcp_name: str,
    command: str,
    env_vars: Dict[str, str],
    args: typing.List[str],
) -> Tuple[int, int]:
    """Update JetBrains XML settings files with MCP configuration

    Returns:
        Tuple[int, int]: (number of files updated, number of files failed)
    """
    settings_files = find_jetbrains_settings_files()
    if not settings_files:
        rprint(f"{WARNING_ICON} [yellow]No JetBrains settings files found[/]")
        return 0, 0

    # Prepare MCP entry for JetBrains
    mcp_config = {"type": "CUSTOM", "command": command, "args": args, "env": env_vars}

    # Create JSON string
    mcp_config_str = json.dumps(mcp_config)
    # XML already handles the escaping, so we don't need to manually replace quotes

    success_count = 0
    failed_count = 0

    for settings_file in settings_files:
        try:
            # Parse XML file
            tree = ET.parse(settings_file)
            root = tree.getroot()

            # Find component node
            component = root.find(".//component[@name='CodiumSettings']")
            if component is None:
                # Create component if it doesn't exist
                component = ET.SubElement(root, "component", {"name": "CodiumSettings"})

            # Find mcpServers option
            mcp_servers = component.find("./option[@name='mcpServers']")
            if mcp_servers is None:
                # Create mcpServers option if it doesn't exist
                mcp_servers = ET.SubElement(component, "option", {"name": "mcpServers"})

            # Find map node
            map_node = mcp_servers.find("./map")
            if map_node is None:
                # Create map node if it doesn't exist
                map_node = ET.SubElement(mcp_servers, "map")

            # Find existing entry for this MCP
            entry = map_node.find(f"./entry[@key='{mcp_name}']")
            if entry is not None:
                # Update existing entry
                entry.set("value", mcp_config_str)
            else:
                # Create new entry
                ET.SubElement(
                    map_node, "entry", {"key": mcp_name, "value": mcp_config_str}
                )

            # Write the updated XML
            tree.write(settings_file, encoding="utf-8", xml_declaration=True)
            success_count += 1

        except Exception as e:
            rprint(f"{ERROR_ICON} [red]Error updating {settings_file}: {str(e)}[/]")
            failed_count += 1

    return success_count, failed_count


def remove_jetbrains_settings_xml(mcp_name: str) -> Tuple[int, int]:
    """Remove MCP from JetBrains XML settings files

    Returns:
        Tuple[int, int]: (number of files updated, number of files failed)
    """
    settings_files = find_jetbrains_settings_files()
    if not settings_files:
        rprint(f"{WARNING_ICON} [yellow]No JetBrains settings files found[/]")
        return 0, 0

    success_count = 0
    failed_count = 0

    for settings_file in settings_files:
        try:
            # Check if file exists
            if not os.path.exists(settings_file):
                continue

            # Parse XML file
            tree = ET.parse(settings_file)
            root = tree.getroot()

            # Look for the map node and the entry for this MCP
            xpath_map = (
                ".//component[@name='CodiumSettings']/option[@name='mcpServers']/map"
            )
            map_node = root.find(xpath_map)

            if map_node is not None:
                # Find entry for this MCP within the map node
                entry = map_node.find(f"./entry[@key='{mcp_name}']")

                if entry is not None:
                    # Remove the entry
                    map_node.remove(entry)

                    # Write the updated XML
                    tree.write(settings_file, encoding="utf-8", xml_declaration=True)
                    success_count += 1
                else:
                    # Entry doesn't exist, count as success
                    success_count += 1
            else:
                # Map node doesn't exist, count as success
                success_count += 1

        except Exception as e:
            rprint(
                f"{ERROR_ICON} [red]Error removing MCP from {settings_file}: {str(e)}[/]"
            )
            failed_count += 1

    return success_count, failed_count


def update_settings_json_remote(ide: str, mcp_name: str) -> bool:
    """Update the settings.json file for a remote MCP"""
    # Special case for JetBrains IDEs
    if ide.lower() == "qodo_jetbrains":
        success_count, failed_count = update_jetbrains_settings_xml_remote(mcp_name)
        return success_count > 0

    ide_info = IDE_SETTINGS.get(ide.lower())
    if not ide_info:
        return False

    file_path = ide_info["path"]

    # Special case for Augment array format
    if ide_info.get("array_format"):
        return update_augment_array_format_remote(file_path, mcp_name)

    try:
        # Create parent directories if they don't exist
        os.makedirs(os.path.dirname(file_path), exist_ok=True)

        # Load existing settings or create new
        if os.path.exists(file_path):
            with open(file_path, "r") as f:
                settings = json.load(f)
        else:
            settings = {}

        # Navigate to mcpServers
        if "mcpServers" not in settings:
            settings["mcpServers"] = {}

        # Add remote MCP configuration
        settings["mcpServers"][mcp_name] = {"url": f"http://localhost:8098/{mcp_name}"}

        # Add proxy configuration
        settings["mcpServers"]["intuit-remote-mcp-proxy"] = {
            "command": "codegen",
            "env": {},
            "args": ["mcp", "remote-init"],
        }

        # Write updated settings
        with open(file_path, "w") as f:
            json.dump(settings, f, indent=2)

        return True

    except Exception as e:
        return False


def update_augment_array_format_remote(file_path: str, mcp_name: str) -> bool:
    """Update Augment's array format settings for remote MCP"""
    try:
        # Create parent directories if they don't exist
        os.makedirs(os.path.dirname(file_path), exist_ok=True)

        # Load existing settings or create new array
        if os.path.exists(file_path):
            with open(file_path, "r") as f:
                mcp_servers = json.load(f)
        else:
            mcp_servers = []

        # Remove existing entries with same name
        mcp_servers = [
            server
            for server in mcp_servers
            if server.get("name") != mcp_name
            and server.get("name") != "intuit-remote-mcp-proxy"
        ]

        # Add remote MCP server
        remote_server = {
            "name": mcp_name,
            "url": f"http://localhost:8098/{mcp_name}",
            "id": str(uuid.uuid4()),
            "tools": [],
        }

        # Add proxy server
        proxy_server = {
            "name": "intuit-remote-mcp-proxy",
            "command": "codegen mcp remote-proxy",
            "arguments": "",
            "useShellInterpolation": True,
            "id": str(uuid.uuid4()),
            "tools": [],
            "env": {},
        }

        mcp_servers.extend([remote_server, proxy_server])

        # Write updated settings
        with open(file_path, "w") as f:
            json.dump(mcp_servers, f, indent=2)

        return True

    except Exception as e:
        return False


def update_jetbrains_settings_xml_remote(mcp_name: str) -> Tuple[int, int]:
    """Update JetBrains XML settings files with remote MCP configuration"""
    settings_files = find_jetbrains_settings_files()
    if not settings_files:
        return 0, 0

    success_count = 0
    failed_count = 0

    for settings_file in settings_files:
        try:
            # Parse XML
            tree = ET.parse(settings_file)
            root = tree.getroot()

            # Find or create the mcpServers option
            component = root.find(".//component[@name='QodoMcpSettings']")
            if component is None:
                component = ET.SubElement(root.find("application"), "component")
                component.set("name", "QodoMcpSettings")

            option = component.find("option[@name='mcpServers']")
            if option is None:
                option = ET.SubElement(component, "option")
                option.set("name", "mcpServers")

            map_elem = option.find("map")
            if map_elem is None:
                map_elem = ET.SubElement(option, "map")

            # Remove existing entries
            for entry in map_elem.findall("entry"):
                if entry.get("key") in [mcp_name, "intuit-remote-mcp-proxy"]:
                    map_elem.remove(entry)

            # Add remote MCP entry
            remote_entry = ET.SubElement(map_elem, "entry")
            remote_entry.set("key", mcp_name)
            remote_config = {"url": f"http://localhost:8098/{mcp_name}"}
            remote_entry.set("value", json.dumps(remote_config))

            # Add proxy entry
            proxy_entry = ET.SubElement(map_elem, "entry")
            proxy_entry.set("key", "intuit-remote-mcp-proxy")
            proxy_config = {
                "command": "codegen",
                "args": ["mcp", "remote-init"],
                "env": {},
            }
            proxy_entry.set("value", json.dumps(proxy_config))

            # Write back to file
            tree.write(settings_file, encoding="utf-8", xml_declaration=True)
            success_count += 1

        except Exception as e:
            failed_count += 1

    return success_count, failed_count
