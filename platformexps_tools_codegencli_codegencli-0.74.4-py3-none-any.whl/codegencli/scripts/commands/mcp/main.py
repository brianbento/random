# mypy: ignore-errors
"""
Main MCP command module that imports from modular components
"""

import click

from .install_operation import install_mcp
from .logging_helper import log_mcp_command_end, log_mcp_command_start
from .operations import (
    init_mcp,
    list_mcps,
    run_mcp_proxy,
    run_mcp_v2_proxy,
    uninstall_mcp,
)
from .release_operation import release_mcp
from .remote_mcp_proxy import run_remote_mcp_proxy, start_remote_proxy_background


@click.group()
def mcp():
    """
    Manage MCP (Model Context Protocol) services.

    This command group provides functionality for initializing,
    releasing, and installing MCP services.
    """
    pass


@mcp.command()
def init():
    """✨ Initialize a new MCP service with boilerplate code"""
    log_mcp_command_start("init")
    try:
        init_mcp()
        log_mcp_command_end("init", success=True)
    except Exception as e:
        log_mcp_command_end("init", success=False)
        raise


@mcp.command()
@click.option(
    "--headless", is_flag=True, help="Run in headless mode using environment variables"
)
def release(headless):
    """🚀 Release an MCP service to the registry

    When using --headless mode, the following environment variables can be set:

    - MCP_RELEASE_TOKEN: Verification token for existing MCPs
    - MCP_RELEASE_VERSION_TYPE: Version type ('major', 'minor', 'patch')
    - MCP_RELEASE_RUNTIME_PATH: Path to the runtime executable (python/node)
    - MCP_RELEASE_ENV_VARS: JSON string of environment variables (e.g., '{"API_KEY": "value"}')
    - MCP_RELEASE_ARGS: JSON string of arguments (e.g., '{"config": "prod"}')

    Example:
        MCP_RELEASE_TOKEN=abc123 MCP_RELEASE_VERSION_TYPE=patch codegen mcp release --headless
    """
    command_name = f"release{'--headless' if headless else ''}"
    log_mcp_command_start(command_name)
    try:
        release_mcp(headless=headless)
        log_mcp_command_end(command_name, success=True)
    except Exception as e:
        log_mcp_command_end(command_name, success=False)
        raise


@mcp.command()
@click.argument("name_with_version")
def install(name_with_version):
    """📥 Install an MCP service

    NAME_WITH_VERSION can be in format name:version to install a specific version.
    Using name:latest will install the latest version.
    """
    log_mcp_command_start(f"install {name_with_version}")
    try:
        install_mcp(name_with_version)
        log_mcp_command_end(f"install {name_with_version}", success=True)
    except Exception as e:
        log_mcp_command_end(f"install {name_with_version}", success=False)
        raise


@mcp.command()
@click.argument("name")
def uninstall(name):
    """🗑️ Uninstall an MCP service from selected IDEs"""
    log_mcp_command_start(f"uninstall {name}")
    try:
        uninstall_mcp(name)
        log_mcp_command_end(f"uninstall {name}", success=True)
    except Exception as e:
        log_mcp_command_end(f"uninstall {name}", success=False)
        raise


@mcp.command()
@click.argument("name")
@click.option(
    "--version", default="latest", help="Version of the MCP to run (default: latest)"
)
def run(name, version):
    """▶️ Run an MCP service as a proxy"""
    # Skip CLI version display for run command (used by IDEs)
    from .logging_helper import get_mcp_logger

    logger = get_mcp_logger()
    logger.info(f"Command: run {name} --version {version}")
    logger.info(f"Starting MCP command: run {name} --version {version}")

    try:
        result = run_mcp_proxy(name, version)
        logger.info(
            f"MCP command completed [{'SUCCESS' if (result == 0 if result is not None else True) else 'FAILED'}]: run {name} --version {version}"
        )
        return result
    except Exception as e:
        logger.error(
            f"MCP command failed [EXCEPTION]: run {name} --version {version} - {str(e)}"
        )
        raise


@mcp.command(name="run-docker")
@click.argument("name")
@click.option(
    "--version", default="latest", help="Version of the MCP to run (default: latest)"
)
def run_docker(name, version):
    """▶️ Run an MCP service using Docker/Podman container runtime"""
    # Skip CLI version display for run-docker command (used by IDEs)
    from .logging_helper import get_mcp_logger

    logger = get_mcp_logger()
    logger.info(f"Command: run-docker {name} --version {version}")
    logger.info(f"Starting MCP command: run-docker {name} --version {version}")

    try:
        result = run_mcp_v2_proxy(name, version)
        logger.info(
            f"MCP command completed [{'SUCCESS' if (result == 0 if result is not None else True) else 'FAILED'}]: run-docker {name} --version {version}"
        )
        return result
    except Exception as e:
        logger.error(
            f"MCP command failed [EXCEPTION]: run-docker {name} --version {version} - {str(e)}"
        )
        raise


@mcp.command(name="remote-proxy")
@click.option("--port", default=8098, help="Port to listen on (default: 8098)")
def remote_proxy(port):
    """🌐 Start remote MCP proxy server"""
    log_mcp_command_start("remote-proxy")

    try:
        result = run_remote_mcp_proxy(port)
        log_mcp_command_end("remote-proxy", result == 0 if result is not None else True)
        return result
    except Exception as e:
        log_mcp_command_end("remote-proxy", False)
        raise


@mcp.command(name="remote-init")
@click.option("--port", default=8098, help="Port to listen on (default: 8098)")
def remote_init(port):
    """🚀 Initialize and start remote MCP proxy server in background"""
    # Skip the standard MCP command logging for remote-init to avoid CLI version display
    from .logging_helper import get_mcp_logger

    logger = get_mcp_logger()
    logger.info(f"Command: remote-init")
    logger.info(f"Starting MCP command: remote-init")

    try:
        result = start_remote_proxy_background(port)
        logger.info(
            f"MCP command completed [{'SUCCESS' if result == 0 else 'FAILED'}]: remote-init"
        )
        return result
    except Exception as e:
        logger.info(f"MCP command completed [FAILED]: remote-init")
        raise
