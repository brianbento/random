import base64
import os
import uuid
from concurrent.futures import ThreadPoolExecutor

import requests

SUPPORTED_EXTENSIONS = {
    ".java": "java",
    ".py": "python",
    ".jsx": "jsx",
    ".tsx": "tsx",
    ".js": "js",
    ".ts": "ts",
    ".go": "go",
}


def enrich_local_dir():
    code_examples_path = os.path.join(os.getcwd(), "code_examples")
    print(f"Scanning directory: {code_examples_path}")

    if not os.path.exists(code_examples_path):
        print("Error: The 'code_examples' directory does not exist.")
        raise FileNotFoundError("The 'code_examples' directory does not exist.")

    files_to_enrich = []

    for root, _, files in os.walk(code_examples_path):
        for file in files:
            file_ext = os.path.splitext(file)[1]
            if file_ext in SUPPORTED_EXTENSIONS:
                file_path = os.path.join(root, file)
                files_to_enrich.append((file_path, SUPPORTED_EXTENSIONS[file_ext]))
                print(
                    f"Found file: {file_path} with language: {SUPPORTED_EXTENSIONS[file_ext]}"
                )

    def enrich_file(file_path, language):
        print(f"Processing file: {file_path}")
        with open(file_path, "rb") as f:
            file_content = f.read()

        encoded_content = base64.b64encode(file_content).decode("utf-8")

        # Call through Lambda which handles authentication
        lambda_endpoint = "https://tgmu28tvmh.execute-api.us-east-1.amazonaws.com"

        response = requests.post(
            f"{lambda_endpoint}/v1/code/enrich",
            headers={
                "x-target-service": "code-enrichment",
                "X-Forwarded-Port": "8090",
                "x-corp-id": os.getenv("USER", "cli-user"),
                "intuit_tid": str(uuid.uuid4()),
                "Content-Type": "application/json",
            },
            json={"language": language, "code": encoded_content},
        )

        if response.status_code == 200:
            enriched_content = base64.b64decode(
                response.json().get("enriched_code")
            ).decode("utf-8")
            with open(file_path, "w") as f:
                f.write(enriched_content)
            print(f"Successfully enriched file: {file_path}")
        else:
            print(
                f"Failed to enrich {file_path}: {response.status_code} {response.text}"
            )

    print("Starting enrichment process with multithreading...")
    with ThreadPoolExecutor(max_workers=10) as executor:
        for file_path, language in files_to_enrich:
            executor.submit(enrich_file, file_path, language)

    print("Enrichment process completed.")


def main():
    enrich_local_dir()


if __name__ == "__main__":
    main()
