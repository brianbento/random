import glob
import importlib.metadata
import os
import shutil
import subprocess
import sys

import click

from codegencli.scripts.commands.mcp import mcp


# Import other modules conditionally to avoid dependency issues with MCP proxy
def get_enrich_command():
    from codegencli.scripts.commands.enrich import enrich_local_dir

    return enrich_local_dir


def get_credentials_command():
    from codegencli.scripts.commands.get_credentials import get_and_store_credentials

    return get_and_store_credentials


def get_validation_commands():
    from codegencli.scripts.commands.validation import (
        add_missing_validations,
        refresh_existing_validations,
        run_validation_tests,
    )

    return add_missing_validations, refresh_existing_validations, run_validation_tests


def set_git_post_buffer():
    """
    Set the Git http.postBuffer configuration globally.
    see https://stackoverflow.com/questions/39938153/how-to-increase-git-post-size
    """
    try:
        subprocess.run(
            ["git", "config", "--global", "http.postBuffer", "524288000"], check=True
        )
    except subprocess.CalledProcessError as e:
        click.echo(f"An error occurred while setting http.postBuffer: {e}")


@click.group()
def cli():
    """
    A CLI tool for validation and enrichment tasks.

    This function sets up the CLI group, allowing for the addition of multiple commands.
    """
    set_git_post_buffer()  # Ensure the Git configuration is set before any command


@click.command()
@click.option("--add-missing", is_flag=True, help="Add missing expected responses.")
@click.option("--refresh", is_flag=True, help="Refresh existing expected responses.")
@click.option("--run-tests", is_flag=True, help="Run validation tests.")
def validation(add_missing, refresh, run_tests):
    """
    Perform validation tasks based on the provided options.

    This command allows users to either add missing expected responses or refresh existing ones.

    Args:
        add_missing (bool): Flag to add missing expected responses.
        refresh (bool): Flag to refresh existing expected responses.
        run_tests (bool): Flag to run validation tests.

    Returns:
        None
    """
    if add_missing or refresh or run_tests:
        add_missing_validations, refresh_existing_validations, run_validation_tests = (
            get_validation_commands()
        )
        if add_missing:
            click.echo("Adding missing expected responses...")
            add_missing_validations()
        if refresh:
            click.echo("Refreshing existing expected responses...")
            refresh_existing_validations()
        if run_tests:
            click.echo("Running validation tests...")
            run_validation_tests()
    else:
        click.echo("No options provided for validation.")


@click.command()
def enrich():
    """
    Perform enrichment tasks.

    This command is a placeholder for future enrichment features.

    Returns:
        None
    """
    click.echo("Enriching the code examples")
    enrich_local_dir = get_enrich_command()
    enrich_local_dir()


@click.command()
@click.option(
    "--force",
    is_flag=True,
    help="Force requesting new credentials even if they already exist.",
)
def login(force):
    """
    Request and store authentication credentials.

    This command authenticates the user through a browser flow and stores the credentials
    locally for use by other commands. If credentials already exist, they will be used
    unless the --force flag is provided.

    Args:
        force (bool): Force requesting new credentials even if they already exist.

    Returns:
        None
    """
    click.echo("Getting authentication credentials...")
    get_and_store_credentials = get_credentials_command()
    get_and_store_credentials(force=force)


@click.command()
def version():
    """
    Display the current version of the CLI.
    """
    try:
        version = importlib.metadata.version("platformexps-tools.codegencli.codegencli")
        click.echo(f"Codegen CLI version: {version}")
    except importlib.metadata.PackageNotFoundError:
        click.echo("Could not determine version. Package is not installed correctly.")


@click.command()
def upgrade():
    """
    Upgrade the CLI to the latest version.

    This command creates a temporary environment and upgrades the CLI
    using the specific sequence required for the Intuit environment.
    """
    codegen_dir = "/tmp/codegen"

    try:
        # Check if /tmp/codegen exists and remove it if it does
        if os.path.exists(codegen_dir):
            click.echo("Removing existing /tmp/codegen directory...")
            shutil.rmtree(codegen_dir)

        # Create the codegen directory
        click.echo("Creating /tmp/codegen directory...")
        os.makedirs(codegen_dir, exist_ok=True)

        # Change to the codegen directory
        original_cwd = os.getcwd()
        os.chdir(codegen_dir)

        try:
            # Create virtual environment
            click.echo("Creating Python 3.11 virtual environment...")
            subprocess.run(["python3.11", "-m", "venv", "venv"], check=True)

            # Determine which pip command to use (pip or pip3)
            venv_pip_candidates = [
                os.path.join(codegen_dir, "venv", "bin", "pip"),
                os.path.join(codegen_dir, "venv", "bin", "pip3"),
            ]

            venv_pip = None
            for pip_path in venv_pip_candidates:
                if os.path.exists(pip_path):
                    venv_pip = pip_path
                    break

            if not venv_pip:
                raise RuntimeError("Could not find pip or pip3 in virtual environment")

            click.echo(f"Using pip at: {venv_pip}")

            # Configure pip to use Intuit's artifactory
            click.echo("Configuring pip to use Intuit's artifactory...")
            subprocess.run(
                [
                    venv_pip,
                    "config",
                    "--user",
                    "set",
                    "global.index-url",
                    "https://artifact.intuit.com/artifactory/api/pypi/pypi-intuit/simple",
                ],
                check=True,
            )

            # Download the package
            click.echo("Downloading platformexps-tools-codegencli-codegencli...")
            subprocess.run(
                [venv_pip, "download", "platformexps-tools-codegencli-codegencli"],
                check=True,
            )

            # Find the downloaded wheel file
            wheel_files = glob.glob("platformexps_tools_codegencli_codegencli-*")
            if not wheel_files:
                raise RuntimeError("No wheel file found after download")

            wheel_file = wheel_files[0]  # Use the first (and likely only) wheel file

            # Check if pipx is installed, install if not
            click.echo("Checking if pipx is installed...")
            try:
                subprocess.run(["pipx", "--version"], check=True, capture_output=True)
                click.echo("pipx is already installed")
            except (subprocess.CalledProcessError, FileNotFoundError):
                click.echo("pipx not found, installing pipx...")
                # Try to install pipx using the system pip/pip3
                system_pip_candidates = ["pip3", "pip"]
                pipx_installed = False

                for pip_cmd in system_pip_candidates:
                    try:
                        subprocess.run(
                            [pip_cmd, "install", "--user", "pipx"], check=True
                        )
                        # Add pipx to PATH if needed
                        subprocess.run(["pipx", "ensurepath"], check=True)
                        pipx_installed = True
                        click.echo(f"pipx installed successfully using {pip_cmd}")
                        break
                    except (subprocess.CalledProcessError, FileNotFoundError):
                        continue

                if not pipx_installed:
                    raise RuntimeError(
                        "Failed to install pipx. Please install pipx manually and try again."
                    )

            # Install using pipx with force flag
            click.echo(f"Installing {wheel_file} using pipx...")
            subprocess.run(["pipx", "install", "--force", wheel_file], check=True)

            # Check the version
            click.echo("Checking installed version...")
            result = subprocess.run(
                ["codegen", "version"], capture_output=True, text=True
            )
            if result.returncode == 0:
                click.echo("Version check result:")
                click.echo(result.stdout)
            else:
                click.echo(
                    "Warning: Version check failed, but installation may have succeeded"
                )
                click.echo(result.stderr)

            click.echo("✅ Upgrade completed successfully!")

        finally:
            # Always change back to original directory
            os.chdir(original_cwd)

    except subprocess.CalledProcessError as e:
        click.echo(f"❌ Error during upgrade: {e}")
        if hasattr(e, "stderr") and e.stderr:
            click.echo(f"Error details: {e.stderr}")
        sys.exit(1)
    except Exception as e:
        click.echo(f"❌ Unexpected error during upgrade: {e}")
        sys.exit(1)


# Add commands to the CLI group
cli.add_command(validation)
cli.add_command(enrich)
cli.add_command(mcp)
cli.add_command(login)
cli.add_command(version)
cli.add_command(upgrade)

if __name__ == "__main__":
    cli()  # Execute the CLI
